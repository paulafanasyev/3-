# CREDITS

Сторонние данные, ассеты и заимствованный код игры «Купол». Код самого форка — MIT (см. `LICENSE`).
Каждый новый ассет или набор данных добавляется сюда: файл, автор, источник, лицензия, изменения.

## Данные о настоящей Земле

| Что | Где в репо | Автор / источник | Лицензия | Изменения |
|---|---|---|---|---|
| Контуры суши 1:50m | вход `scripts/build-game-map.mjs` (сам файл не коммитится) | [Natural Earth](https://www.naturalearthdata.com/) 1:50m. Локальная сборка: контуры admin-0 1:50m, слитые в одну сушу (границы стёрты). Эталон для пересборки — `ne_50m_land` | Public domain | Растеризуются в маску суши/океана 4096×2048, затем сводятся к ячейкам сетки |
| Снимок Земли «Blue Marble» | вход `scripts/build-game-map.mjs` (не коммитится) | Файл `earth-blue-marble.jpg` из примеров npm-пакета [three-globe](https://github.com/vasturiano/three-globe) (MIT, автор Vasco Asturiano); изображение по описанию основано на NASA Blue Marble (public domain). **Blue Marble: источник требует подтверждения**: перед релизом пересобрать карту на оригинальном файле NASA с [visibleearth.nasa.gov](https://visibleearth.nasa.gov/collection/1484/blue-marble) | NASA: public domain. Лицензия именно этой копии не подтверждена: в репо снимок не входит, перед релизом карту пересобрать на оригинале NASA | По цвету снимка определяется тип местности ячейки |
| Карта местности | `data/game/map.json` | Производные от двух источников выше | Public domain (производные) | Тип местности на 10 242 ячейки |
| Поправки суши | `src/game/data/geoOverrides.js` | этот проект (координаты Великих озёр и Панамского перешейка) | MIT | 8 ячеек: озёра стали водой, перешеек — сушей |
| Стоп-лист реальных названий | `data/game/real-names-stoplist.json` | Русские названия стран из Natural Earth, крупные города, регионы, реки и горы, распространённые личные имена (составлено вручную) | Public domain / факты | Используется только чтобы игровые имена НЕ совпадали с реальными |

Реальные государственные границы и списки городов в игре не используются: вся политическая карта
(провинции, народы, города, названия) выдумана детерминированно в `src/game/worldgen.js`.

## Земля в клиенте

Клиент (`/kupol`) показывает ту же Землю, что и God's Eye View: Google Photorealistic 3D Tiles
через CesiumJS (условия Google Maps Platform, атрибуция выводится на экран). Без ключа Google
клиент показывает глобус Cesium (`src/game/client/imagery.js`): снизу всегда лежит снимок
**Natural Earth II**, который поставляется внутри npm-пакета CesiumJS (`Assets/Textures/NaturalEarthII`,
пакет под Apache-2.0; сам снимок Natural Earth — public domain) и работает без ключей и без интернета;
поверх него — спутниковая подложка Cesium ion, а если она недоступна — OpenStreetMap (ODbL).
Собственных снимков в репо нет.

## «Живая Земля» (слои GEV в игре)

Самолёты, спутники, запуски и сейсмика берутся из уже существующих в God's Eye View лент
(OpenSky, CelesTrak, USGS и другие, см. исходники `src/data/`). В репо эти данные не хранятся,
действуют условия соответствующих сервисов. На правила игры они не влияют, только на картинку.
Все игровые эффекты (ядерные удары, осадки, разведка) рисуются кодом проекта (MIT), сторонних
ассетов для них нет.

## 3D-модели

Модели юнитов — уже имеющиеся в репо файлы `public/models/*.glb` под **CC BY 4.0**. Авторы,
ссылки и изменения перечислены в [`public/models/README.md`](public/models/README.md); в игре
они используются так (`src/game/data/units.js`):

| Модель | Юнит |
|---|---|
| `ship.glb` | Галера, Броненосец |
| `c172.glb` | Биплан-разведчик |
| `jet.glb` | Истребитель |
| `mq9.glb` | Ударный беспилотник |
| `bell206.glb` | Вертолёт |
| `citation2.glb` | Самолёт-разведчик |
| `atr72.glb`, `b789.glb` | Транспортники (этап клиента) |
| `airplane.glb` | Торговые рейсы (этап клиента) |

## Портреты лидеров

| Файл | Автор | Лицензия | Как сделано |
|---|---|---|---|
| `src/game/faces/avatar-svg.js` | Pavel Afanasev, единственный автор и владелец (репо [paulafanasyev/ai-english-teacher](https://github.com/paulafanasyev/ai-english-teacher), `apps/web/src/avatar/svg.js`, blob `ba68462d70476ca48b665b61ec9fa97209113172`) | © 2026 Pavel Afanasev, включён в этот репо самим автором. Не входит в MIT-лицензию форка без отдельного решения автора | Скопирован без изменений |
| `src/game/faces/leaderFaces.js` | этот проект | MIT | Токены внешности лидеров, борода, седина, значок, рамка, мимика по настроению |
| `public/game/leaders/<нация>[-<настроение>].svg/.png` (генерируются, в `.gitignore`) | этот проект (на основе отрисовщика выше) | как у `avatar-svg.js` | `node scripts/game-portraits.mjs` |
| `public/game/leaders/custom.png` | этот проект | MIT | Силуэт-заглушка для своей нации, тот же скрипт |

## Шрифты и иконки интерфейса

Шрифты подключаются в `index.html` с Google Fonts; в production это внешняя загрузка,
если браузер имеет доступ к Google Fonts. Встроенные в репозиторий копии отсутствуют.

| Семейство | Использование | Лицензия / условия |
|---|---|---|
| JetBrains Mono | технические подписи, значения и HUD | SIL Open Font License 1.1 (OFL) |
| Inter | основной интерфейсный текст | SIL Open Font License 1.1 (OFL) |
| Material Symbols Outlined | иконки интерфейса | Apache License 2.0 |
| Material Icons Round | иконки интерфейса | Apache License 2.0 |

Названия семейств и параметры подключения сверены с Google Fonts-ссылками в `index.html`.
При упаковке локальных копий нужно сохранить соответствующие файлы лицензий OFL/Apache 2.0.

## Cesium, Natural Earth и OpenStreetMap

- В клиенте используется CesiumJS (Apache-2.0) и входящие в npm-пакет ассеты
  `Assets/Textures/NaturalEarthII`; Natural Earth II — public domain. Встроенный
  Natural Earth II является офлайн-запасным глобусом и не требует Google API key.
- `CESIUM_ION_TOKEN` — стандартный default token Cesium ion, если он передан через
  окружение сборки. Токен и условия конкретных ion-ассетов нужно подтвердить у владельца
  аккаунта перед публичным релизом; секреты в репозиторий не записываются.
- Запасная подложка OpenStreetMap — данные © OpenStreetMap contributors, ODbL.
  Использование тайлов должно соблюдать [политику тайлов OSM](https://operations.osmfoundation.org/policies/tiles/):
  обязательны видимая атрибуция, корректный User-Agent/Referer для клиентов и кэширование;
  массовое скачивание, обход ограничений и использование публичного tile-сервера как CDN
  запрещены. Для production следует использовать разрешённый провайдер тайлов либо собственную
  инфраструктуру, сохраняя атрибуцию OSM и условия ODbL.


## Заимствованный код

| Файл | Откуда | Изменения |
|---|---|---|
| `src/game/geo.js` | `src/nuclear/geo.js` из PR #2 (этот же репо) | `toVector`/`fromVector` экспортируются |
| `src/game/rng.js` | `src/nuclear/rng.js` из PR #2 | Добавлены `randomInt`, `pick`, `shuffle`, `seedToInt` |
| `src/game/session.js` | `src/nuclear/session.js` из PR #2 | Таймер тиков заменён на пошаговый `game:endTurn` |

## Тактический бой

- **three.js** (MIT, © 2010–2026 three.js authors), https://threejs.org — рендер поля боя.
- Юниты боя сделаны с нуля в коде, без сторонних ассетов: «кузница» `src/game/client/battle/forge.js` (скелет, скиннинг, анимации; 21 модель по четырём эпохам) и запасные фигуры `src/game/client/battle/models.js`. Деревья и дома собраны в `src/game/client/battle/view.js`. Автор — Pavel Afanasev. Выгрузка в `.glb` для Blender — `npm run game:units` (`public/game/units/forge/`), лицензия та же, что у кода репозитория.
- Источники моделей для замены (лицензия проверена по страницам паков, в репозиторий ещё не добавлены):
  - Quaternius, Ultimate Modular Men Pack, RPG Character Pack, Toon Shooter Game Kit, Animated Tank Pack, Universal Animation Library — CC0, https://quaternius.com
  - Kenney, City Kit и другие 3D-киты — CC0, https://kenney.nl
  - Legendary Warriors Kit: Samurai Commander — CC0, https://3dassets.dev (автор пометил, что модель сделана с ИИ)
  - Grab3D, Samurai (rigged) — CC0, https://grab3d.com (тяжёлая модель, 400–800 тыс. треугольников, нужна LOD)
  - metaworldos, WWII Tank Pack — CC0, https://metaworldos.itch.io
