import { createRequire as __kupolCreateRequire } from 'node:module'; const require = __kupolCreateRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports, module) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports, module) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = __require("bufferutil");
        module.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports, module) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports, module) {
    "use strict";
    var zlib = __require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key2) => {
            let value = params[key2];
            if (value.length > 1) {
              throw new Error(`Parameter "${key2}" must have only a single value`);
            }
            value = value[0];
            if (key2 === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key2}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key2}": ${value}`
                );
              }
            } else if (key2 === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key2}": ${value}`
                );
              }
              value = num;
            } else if (key2 === "client_no_context_takeover" || key2 === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key2}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key2}"`);
            }
            params[key2] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key2 = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key2] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key2];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key2 = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key2] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key2];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports, module) {
    "use strict";
    var { isUtf8 } = __require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = __require("utf-8-validate");
        module.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports, module) {
    "use strict";
    var { Writable } = __require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
            const error = this.createError(
              RangeError,
              "Too many message fragments",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            );
            cb(error);
            return;
          }
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
              const error = this.createError(
                RangeError,
                "Too many message fragments",
                false,
                1008,
                "WS_ERR_TOO_MANY_BUFFERED_PARTS"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module.exports = Receiver2;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports, module) {
    "use strict";
    var { Duplex } = __require("stream");
    var { randomFillSync } = __require("crypto");
    var {
      types: { isUint8Array }
    } = __require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports, module) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var https = __require("https");
    var http = __require("http");
    var net = __require("net");
    var tls = __require("tls");
    var { randomBytes: randomBytes2, createHash } = __require("crypto");
    var { Duplex, Readable } = __require("stream");
    var { URL: URL2 } = __require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 1024 * 1024,
        maxFragments: 128 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key2 = randomBytes2(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key2,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key3, value] of Object.entries(headers)) {
              options.headers[key3.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key2 + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports, module) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = __require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module.exports = createWebSocketStream2;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var http = __require("http");
    var { Duplex } = __require("stream");
    var { createHash } = __require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=1048576] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=131072] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 1024 * 1024,
          maxFragments: 128 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server2 = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server2.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key2 = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key2 === void 0 || !keyRegex.test(key2)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key2,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key2, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key2, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key2 + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module.exports = WebSocketServer2;
    function addListeners(server2, map) {
      for (const event of Object.keys(map)) server2.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server2.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server2) {
      server2._state = CLOSED;
      server2.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server2, req, socket, code, message, headers) {
      if (server2.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server2.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// server.js
import fs from "node:fs";
import { createServer } from "node:http";
import path from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";

// node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);

// src/game/sessions.js
import { randomBytes } from "node:crypto";

// src/game/map.js
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

// src/game/geo.js
var EARTH_RADIUS_KM = 6371;
var toRad = (deg) => deg * Math.PI / 180;
var toDeg = (rad) => rad * 180 / Math.PI;
function haversineKm(a, b) {
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}
function fromVector([x, y, z]) {
  return { lat: toDeg(Math.atan2(z, Math.hypot(x, y))), lon: toDeg(Math.atan2(y, x)) };
}

// src/game/grid.js
var GRID_LEVEL = 5;
function normalize([x, y, z]) {
  const l = Math.hypot(x, y, z);
  return [x / l, y / l, z / l];
}
function icosahedron() {
  const t = (1 + Math.sqrt(5)) / 2;
  const vertices = [
    [-1, t, 0],
    [1, t, 0],
    [-1, -t, 0],
    [1, -t, 0],
    [0, -1, t],
    [0, 1, t],
    [0, -1, -t],
    [0, 1, -t],
    [t, 0, -1],
    [t, 0, 1],
    [-t, 0, -1],
    [-t, 0, 1]
  ].map(normalize);
  const faces = [
    [0, 11, 5],
    [0, 5, 1],
    [0, 1, 7],
    [0, 7, 10],
    [0, 10, 11],
    [1, 5, 9],
    [5, 11, 4],
    [11, 10, 2],
    [10, 7, 6],
    [7, 1, 8],
    [3, 9, 4],
    [3, 4, 2],
    [3, 2, 6],
    [3, 6, 8],
    [3, 8, 9],
    [4, 9, 5],
    [2, 4, 11],
    [6, 2, 10],
    [8, 6, 7],
    [9, 8, 1]
  ];
  return { vertices, faces };
}
function buildGrid(level = GRID_LEVEL) {
  let { vertices, faces } = icosahedron();
  for (let step = 0; step < level; step += 1) {
    const cache = /* @__PURE__ */ new Map();
    const midpoint = (a, b) => {
      const key2 = a < b ? `${a}_${b}` : `${b}_${a}`;
      let index = cache.get(key2);
      if (index === void 0) {
        const va = vertices[a];
        const vb = vertices[b];
        index = vertices.length;
        vertices.push(normalize([va[0] + vb[0], va[1] + vb[1], va[2] + vb[2]]));
        cache.set(key2, index);
      }
      return index;
    };
    const next = [];
    for (const [a, b, c] of faces) {
      const ab = midpoint(a, b);
      const bc = midpoint(b, c);
      const ca = midpoint(c, a);
      next.push([a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]);
    }
    faces = next;
  }
  const neighbors = vertices.map(() => /* @__PURE__ */ new Set());
  for (const [a, b, c] of faces) {
    neighbors[a].add(b).add(c);
    neighbors[b].add(a).add(c);
    neighbors[c].add(a).add(b);
  }
  const cells = vertices.map((v) => {
    const { lat, lon } = fromVector(v);
    return { lat: Math.round(lat * 1e4) / 1e4, lon: Math.round(lon * 1e4) / 1e4 };
  });
  return {
    level,
    cells,
    vectors: vertices,
    neighbors: neighbors.map((set) => [...set].sort((x, y) => x - y)),
    faces
  };
}
function nearestCell(grid, point) {
  const la = point.lat * Math.PI / 180;
  const lo = point.lon * Math.PI / 180;
  const p = [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)];
  let best = 0;
  let bestDot = -2;
  for (let i = 0; i < grid.vectors.length; i += 1) {
    const v = grid.vectors[i];
    const dot = v[0] * p[0] + v[1] * p[1] + v[2] * p[2];
    if (dot > bestDot) {
      bestDot = dot;
      best = i;
    }
  }
  return best;
}

// src/game/data/terrain.js
var TERRAIN = Object.freeze({
  O: { id: "ocean", name: "\u041E\u043A\u0435\u0430\u043D", water: true, food: 1, prod: 0, gold: 0, move: 1, defense: 1 },
  S: { id: "shelf", name: "\u0428\u0435\u043B\u044C\u0444", water: true, food: 1, prod: 0, gold: 1, move: 1, defense: 1 },
  P: { id: "plain", name: "\u0420\u0430\u0432\u043D\u0438\u043D\u0430", water: false, food: 2, prod: 1, gold: 0, move: 1, defense: 1 },
  F: { id: "forest", name: "\u041B\u0435\u0441", water: false, food: 1, prod: 2, gold: 0, move: 2, defense: 1.25 },
  D: { id: "desert", name: "\u0421\u0442\u0435\u043F\u044C \u0438 \u043F\u0443\u0441\u0442\u044B\u043D\u044F", water: false, food: 0, prod: 1, gold: 0, move: 1, defense: 1 },
  T: { id: "tundra", name: "\u0422\u0443\u043D\u0434\u0440\u0430", water: false, food: 1, prod: 0, gold: 0, move: 1, defense: 1 },
  I: { id: "ice", name: "\u041B\u0435\u0434\u043D\u0438\u043A", water: false, food: 0, prod: 0, gold: 0, move: 3, defense: 1 },
  M: { id: "mountain", name: "\u0413\u043E\u0440\u044B", water: false, food: 0, prod: 2, gold: 0, move: 3, defense: 1.5 }
});
var LAND_CODES = Object.freeze(["P", "F", "D", "T", "I", "M"]);
var isWater = (code) => code === "O" || code === "S";
var COAST_FOOD_BONUS = 1;
var STRATEGIC = Object.freeze({
  iron: { name: "\u0416\u0435\u043B\u0435\u0437\u043E", era: 0, weights: { M: 0.12, F: 0.05, P: 0.04, T: 0.03 } },
  oil: { name: "\u041D\u0435\u0444\u0442\u044C", era: 1, weights: { D: 0.1, S: 0.03, T: 0.05, P: 0.015 } },
  silicon: { name: "\u041A\u0440\u0435\u043C\u043D\u0438\u0439", era: 2, weights: { D: 0.07, P: 0.03, M: 0.03 } },
  rare: { name: "\u0420\u0435\u0434\u043A\u043E\u0437\u0435\u043C\u0435\u043B\u044C\u043D\u044B\u0435 \u043C\u0435\u0442\u0430\u043B\u043B\u044B", era: 3, weights: { T: 0.05, M: 0.05, D: 0.02 } }
});
var RARE_IN_NORTH_AMERICA = 0.2;

// src/game/rng.js
function nextRandom(state) {
  state.rng = state.rng + 1831565813 | 0;
  let t = Math.imul(state.rng ^ state.rng >>> 15, 1 | state.rng);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function randomInt(state, n) {
  return Math.floor(nextRandom(state) * n);
}
function seedToInt(seed) {
  if (Number.isInteger(seed)) return seed | 0;
  let h = 2166136261;
  for (const ch of String(seed)) h = Math.imul(h ^ ch.codePointAt(0), 16777619);
  return h | 0;
}

// src/game/names.js
var CULTURES = Object.freeze({
  northern: {
    start: ["\u0412\u0435\u043B\u044C", "\u0422\u043E\u0440", "\u0421\u043A\u0430", "\u0425\u0435\u043B\u044C", "\u0418\u0440", "\u0421\u0432\u0430", "\u041E\u043B\u044C\u043C", "\u0411\u0440\u0435\u043D", "\u0423\u0440", "\u041A\u044C\u044F\u0440", "\u041B\u043E\u0434", "\u0424\u0435\u0440\u043D"],
    middle: ["\u0433\u0435", "\u0432\u0430", "\u0440\u0438", "\u043C\u043E", "\u043B\u0430", "\u0434\u0435", "\u043D\u0430", "\u0441\u0435"],
    end: ["\u0445\u0435\u0439\u043C", "\u0432\u0438\u043A", "\u0433\u0430\u0440\u0434", "\u043C\u0430\u0440", "\u0434\u0430\u043B", "\u0441\u0442\u0430\u0434", "\u0443\u043D", "\u043E\u043B\u044C\u0434"]
  },
  coastal: {
    start: ["\u041C\u0430\u0440", "\u041B\u0430", "\u041E\u0440\u0438", "\u0421\u0430\u043B", "\u0412\u0435", "\u041F\u0435\u043B", "\u0410\u043C\u0438", "\u041A\u043E\u0440", "\u0422\u0430\u0440\u0430", "\u042D\u043B\u043E", "\u041C\u0435\u043D", "\u0421\u0438\u0440\u0430"],
    middle: ["\u0440\u0435", "\u043B\u0438", "\u0432\u0430", "\u043D\u043E", "\u0442\u0438", "\u0441\u0430", "\u043B\u0435", "\u043C\u0438"],
    end: ["\u0435\u043D\u0442\u0430", "\u0440\u0438\u0441", "\u043E\u043B\u0430", "\u0435\u043D\u043E", "\u0438\u044F", "\u0430\u0440\u0430", "\u0435\u043B\u044C", "\u0438\u0441"]
  },
  steppe: {
    start: ["\u041A\u0430\u0440", "\u0422\u0443", "\u0410\u0441", "\u0411\u0430\u0439", "\u0415\u0440", "\u041E\u043A", "\u0416\u0430\u043D", "\u0421\u0430\u0440", "\u0422\u0435\u043C", "\u0423\u043B", "\u041A\u0435\u0448", "\u0410\u044F\u043D"],
    middle: ["\u0431\u0430", "\u0442\u044B", "\u043A\u0435", "\u0440\u044B", "\u043C\u044B", "\u0441\u0430", "\u0434\u0443", "\u043B\u0430"],
    end: ["\u0442\u0430\u0443", "\u043A\u0435\u043D\u0442", "\u0431\u0435\u043A", "\u0433\u0443\u0437", "\u0430\u0440", "\u0442\u044B\u043C", "\u0430\u043D", "\u0443\u043B"]
  },
  desert: {
    start: ["\u0417\u0430\u0444", "\u041A\u0435", "\u0410\u043C", "\u0421\u0430\u0445", "\u041D\u0443", "\u0418\u0448", "\u0422\u0430\u043B", "\u0425\u0430\u0440", "\u041C\u0435", "\u0414\u0436\u0435", "\u0420\u0430", "\u0423\u0441"],
    middle: ["\u0440\u0430", "\u0448\u0438", "\u0434\u0430", "\u0444\u0438", "\u043D\u0443", "\u0445\u0430", "\u0437\u0438", "\u043C\u0430"],
    end: ["\u0438\u0440", "\u0430\u0445", "\u0443\u043C", "\u0435\u0442", "\u0430\u0434", "\u0438\u043D\u0430", "\u0430\u0440", "\u0443\u0441"]
  },
  island: {
    start: ["\u041A\u0430", "\u041C\u043E", "\u041B\u043E", "\u0412\u0430", "\u0422\u0443", "\u0425\u0438", "\u041F\u0435", "\u041D\u0430", "\u0410\u043A\u043E", "\u0423\u043B\u0435", "\u0420\u0438", "\u041E\u043B\u0438"],
    middle: ["\u043B\u0430", "\u043D\u0443", "\u043A\u0435", "\u043F\u043E", "\u043C\u0430", "\u0445\u0438", "\u0432\u0430", "\u0442\u043E"],
    end: ["\u0430\u043D\u0438", "\u0443\u0440\u0430", "\u0438\u043A\u0438", "\u043E\u0434\u0430", "\u0435\u043C\u0430", "\u0430\u0443", "\u0438\u043B\u043E", "\u0435\u043D\u0435"]
  },
  highland: {
    start: ["\u0410\u043D", "\u041A\u0435\u0447", "\u0418\u043B", "\u0422\u043E\u043C", "\u041F\u0430\u043A", "\u0423\u0440\u0438", "\u041A\u0430\u043D", "\u0419\u0430\u043D", "\u041C\u0430", "\u0422\u0438", "\u0425\u0443\u0430", "\u041A\u043E\u0441"],
    middle: ["\u0440\u0438", "\u043A\u0430", "\u0442\u0430", "\u043B\u0443", "\u043F\u0443", "\u043A\u0438", "\u043D\u0443", "\u0447\u0430"],
    end: ["\u043A\u043E", "\u044F\u043C\u043E", "\u043F\u0430\u043A", "\u0443\u043A\u0430", "\u0430\u043D", "\u0438\u043D\u0430", "\u0430\u043B\u044C", "\u0442\u0435"]
  }
});
var VOWELS = "\u0430\u0435\u0451\u0438\u043E\u0443\u044B\u044D\u044E\u044F";
function awkwardName(name) {
  const s = name.toLowerCase();
  if (s.length > 11) return true;
  if (/сваст|лох|хуй|хуе|пизд|бля|жоп|срак|говн|сран|дерьм|нацис|квебек/.test(s)) return true;
  if (new RegExp(`[${VOWELS}]{3}`).test(s)) return true;
  if (new RegExp(`^[${VOWELS}]{2}`).test(s)) return true;
  if (/(..+)\1/.test(s)) return true;
  if (/([аеоуыэи])\1/.test(s)) return true;
  if (new RegExp(`[^${VOWELS}\u044C\u0439]{4}`).test(s)) return true;
  if (new RegExp(`\u043B\u044C[^${VOWELS}]`).test(s.slice(1, -1))) return true;
  return false;
}
function normalizeName(s) {
  return s.toLowerCase().replace(/ё/g, "\u0435").replace(/й/g, "\u0438").replace(/[\s\-']/g, "");
}
function levenshtein(a, b) {
  const prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i += 1) {
    let diag = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      const tmp = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return prev[b.length];
}
function createRealNameGuard(stopList2 = []) {
  const real = stopList2.map(normalizeName).filter((r) => /[а-я]/.test(r) && r.length >= 4);
  const exact = new Set(real);
  return (name) => {
    const x = normalizeName(name);
    if (exact.has(x)) return true;
    if (x.length < 5) return false;
    return real.some((r) => Math.abs(r.length - x.length) <= 1 && levenshtein(x, r) <= 1);
  };
}
var PROVINCE_SUFFIX = ["\u0438\u044F", "\u0430\u043D", "\u0438\u044F", "\u0435\u044F", "\u0430\u043D\u0438\u044F", "\u0430\u0440"];
function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
}
function makeName(state, culture, { syllables } = {}) {
  const set = CULTURES[culture] ?? CULTURES.coastal;
  const count = syllables ?? (nextRandom(state) < 0.55 ? 0 : 1);
  let word = set.start[randomInt(state, set.start.length)];
  for (let i = 0; i < count; i += 1) word += set.middle[randomInt(state, set.middle.length)];
  word += set.end[randomInt(state, set.end.length)];
  return capitalize(word);
}
function makeRegionName(state, culture) {
  const base = makeName(state, culture);
  if (nextRandom(state) < 0.35) {
    const suffix = PROVINCE_SUFFIX[randomInt(state, PROVINCE_SUFFIX.length)];
    const stem = base.replace(/[аеёиоуыэюяь]+$/u, "");
    if (stem.length >= 3) return capitalize(stem + suffix);
  }
  return base;
}
function createNamer(state, { forbidden = /* @__PURE__ */ new Set(), tooReal = () => false } = {}) {
  const used = /* @__PURE__ */ new Set();
  const lower = (s) => s.toLowerCase();
  const take = (generate) => {
    for (let attempt = 0; attempt < 400; attempt += 1) {
      const name = generate();
      const key2 = lower(name);
      if (name.length < 3 || awkwardName(name) || used.has(key2) || forbidden.has(key2) || tooReal(name)) continue;
      used.add(key2);
      return name;
    }
    throw new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u043E\u0431\u0440\u0430\u0442\u044C \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0438\u043C\u044F");
  };
  return {
    city: (culture) => take(() => makeName(state, culture)),
    region: (culture) => take(() => makeRegionName(state, culture)),
    used
  };
}

// src/game/data/regions.js
function isNorthAmerica({ lat, lon }) {
  if (lon < -170 || lon > -52) return false;
  if (lat < 7 || lat > 75) return false;
  if (lat > 59 && lon > -75) return false;
  if (lat < 10 && lon > -78) return false;
  return true;
}
var START_ZONES = Object.freeze([
  { id: "north", name: "\u0421\u0435\u0432\u0435\u0440\u043D\u0430\u044F", anchor: { lat: 54, lon: -98 } },
  { id: "atlantic", name: "\u0410\u0442\u043B\u0430\u043D\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F", anchor: { lat: 38, lon: -79 } },
  { id: "pacific", name: "\u0422\u0438\u0445\u043E\u043E\u043A\u0435\u0430\u043D\u0441\u043A\u0430\u044F", anchor: { lat: 44, lon: -121 } },
  { id: "south", name: "\u042E\u0436\u043D\u0430\u044F", anchor: { lat: 19, lon: -98 } }
]);

// src/game/worldgen.js
var WORLD_SEED = "kupol-world-1";
function dijkstraAssign(seeds, neighbors, allowed, cost) {
  const owner = new Int32Array(neighbors.length).fill(-1);
  const dist3 = new Float64Array(neighbors.length).fill(Infinity);
  const heap = [];
  const push = (d, cell, who) => {
    heap.push([d, cell, who]);
    let i = heap.length - 1;
    while (i > 0) {
      const p = i - 1 >> 1;
      if (heap[p][0] <= heap[i][0]) break;
      [heap[p], heap[i]] = [heap[i], heap[p]];
      i = p;
    }
  };
  const pop = () => {
    const top = heap[0];
    const last = heap.pop();
    if (heap.length) {
      heap[0] = last;
      let i = 0;
      for (; ; ) {
        const l = i * 2 + 1;
        const r = l + 1;
        let m = i;
        if (l < heap.length && heap[l][0] < heap[m][0]) m = l;
        if (r < heap.length && heap[r][0] < heap[m][0]) m = r;
        if (m === i) break;
        [heap[m], heap[i]] = [heap[i], heap[m]];
        i = m;
      }
    }
    return top;
  };
  seeds.forEach((cell, who) => push(0, cell, who));
  while (heap.length) {
    const [d, cell, who] = pop();
    if (d >= dist3[cell]) continue;
    dist3[cell] = d;
    owner[cell] = who;
    for (const n of neighbors[cell]) {
      if (!allowed(n) || dist3[n] <= d) continue;
      push(d + cost(cell, n), n, who);
    }
  }
  return owner;
}
function components(cells, neighbors) {
  const set = new Set(cells);
  const comp = /* @__PURE__ */ new Map();
  let id = 0;
  for (const start of cells) {
    if (comp.has(start)) continue;
    const stack = [start];
    comp.set(start, id);
    while (stack.length) {
      const c = stack.pop();
      for (const n of neighbors[c]) if (set.has(n) && !comp.has(n)) {
        comp.set(n, id);
        stack.push(n);
      }
    }
    id += 1;
  }
  return { comp, count: id };
}
function farthestPointSeeds(candidates, count, cells, rngState, existing = []) {
  const seeds = [...existing];
  const minDist = new Map(candidates.map((c) => [c, Infinity]));
  const update = (s) => {
    for (const c of candidates) minDist.set(c, Math.min(minDist.get(c), haversineKm(cells[c], cells[s])));
  };
  seeds.forEach(update);
  if (!seeds.length && candidates.length) {
    const first = candidates[Math.floor(nextRandom(rngState) * candidates.length)];
    seeds.push(first);
    update(first);
  }
  while (seeds.length < count) {
    let best = -1;
    let bestD = -1;
    for (const c of candidates) {
      const d = minDist.get(c) * (0.85 + nextRandom(rngState) * 0.3);
      if (d > bestD) {
        bestD = d;
        best = c;
      }
    }
    if (best < 0 || bestD <= 0) break;
    seeds.push(best);
    update(best);
  }
  return seeds;
}
function buildWorld(terrainString, { grid = buildGrid(5), stopList: stopList2 = [], provinceTarget = 500, peopleTarget = 40 } = {}) {
  const { cells, neighbors } = grid;
  const terrain = terrainString.split("");
  const rngState = { rng: seedToInt(WORLD_SEED) };
  const landCells = [];
  for (let i = 0; i < cells.length; i += 1) if (!isWater(terrain[i])) landCells.push(i);
  const habitable = landCells.filter((c) => terrain[c] !== "I");
  const { comp, count: compCount } = components(habitable, neighbors);
  const byComp = Array.from({ length: compCount }, () => []);
  for (const c of habitable) byComp[comp.get(c)].push(c);
  const islandSeeds = byComp.map((list) => list[Math.floor(list.length / 2)]);
  const seeds = farthestPointSeeds(habitable, Math.max(provinceTarget, islandSeeds.length), cells, rngState, islandSeeds);
  const habitableSet = new Set(habitable);
  const provinceOf = dijkstraAssign(seeds, neighbors, (c) => habitableSet.has(c), (a, b) => {
    let c = 1;
    if (terrain[a] !== terrain[b]) c += 0.8;
    if (terrain[a] === "M" !== (terrain[b] === "M")) c += 1.5;
    const coastA = neighbors[a].some((x) => isWater(terrain[x]));
    const coastB = neighbors[b].some((x) => isWater(terrain[x]));
    if (coastA !== coastB) c += 0.2;
    return c;
  });
  const provinces = seeds.map((seed, id) => ({ id, seed, cells: [] }));
  for (const c of habitable) if (provinceOf[c] >= 0) provinces[provinceOf[c]].cells.push(c);
  const liveProvinces = provinces.filter((p) => p.cells.length > 0);
  const remap = new Map(liveProvinces.map((p, i) => [p.id, i]));
  const province = new Int32Array(cells.length).fill(-1);
  for (const c of habitable) province[c] = remap.get(provinceOf[c]);
  const provs = liveProvinces.map((p, i) => {
    const center = p.cells.reduce((best, c) => haversineKm(cells[c], cells[p.seed]) < haversineKm(cells[best], cells[p.seed]) ? c : best, p.cells[0]);
    const counts = {};
    for (const c of p.cells) counts[terrain[c]] = (counts[terrain[c]] ?? 0) + 1;
    return { id: i, cells: p.cells, center, na: isNorthAmerica(cells[center]), touchesNA: p.cells.some((c) => isNorthAmerica(cells[c])), counts };
  });
  const provNeighbors = provs.map(() => /* @__PURE__ */ new Set());
  for (const c of habitable) for (const n of neighbors[c]) {
    if (province[n] >= 0 && province[n] !== province[c]) provNeighbors[province[c]].add(province[n]);
  }
  const overseas = provs.filter((p) => !p.na && !p.touchesNA && p.cells.length >= 2);
  const peopleSeedsProv = farthestPointSeeds(overseas.map((p) => p.id), peopleTarget, provs.map((p) => cells[p.center]), rngState);
  const peopleOf = new Int32Array(provs.length).fill(-1);
  const sizes = new Array(peopleSeedsProv.length).fill(0);
  const MAX_PROVINCES = 9;
  const frontier = peopleSeedsProv.map((p, who) => {
    peopleOf[p] = who;
    sizes[who] = 1;
    return [p];
  });
  let grew = true;
  while (grew) {
    grew = false;
    for (let who = 0; who < frontier.length; who += 1) {
      if (sizes[who] >= MAX_PROVINCES) continue;
      const next = [];
      for (const p of frontier[who]) for (const q of provNeighbors[p]) {
        if (peopleOf[q] < 0 && !provs[q].na && !provs[q].touchesNA && sizes[who] < MAX_PROVINCES && nextRandom(rngState) < 0.7) {
          peopleOf[q] = who;
          sizes[who] += 1;
          next.push(q);
          grew = true;
        }
      }
      frontier[who] = next.length ? next : frontier[who].filter((p) => [...provNeighbors[p]].some((q) => peopleOf[q] < 0 && !provs[q].na));
    }
  }
  const cultureFor = (provList) => {
    const counts = {};
    let lat = 0;
    for (const p of provList) {
      for (const [k, v] of Object.entries(p.counts)) counts[k] = (counts[k] ?? 0) + v;
      lat += cells[p.center].lat;
    }
    lat /= provList.length;
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const share = (k) => (counts[k] ?? 0) / total;
    if (Math.abs(lat) > 52 || share("T") > 0.3) return "northern";
    if (share("D") > 0.4) return Math.abs(lat) < 32 ? "desert" : "steppe";
    if (share("M") > 0.25) return "highland";
    if (total <= 6) return "island";
    if (Math.abs(lat) > 38 && share("P") > 0.5) return "steppe";
    return "coastal";
  };
  const namer = createNamer(rngState, { tooReal: createRealNameGuard(stopList2) });
  const PEOPLE_COLORS = ["#8a7f6a", "#6f8a7a", "#7a6f8a", "#8a6f6f", "#6f7f8a", "#8a866f", "#7d8a6f", "#6f8a86"];
  const peoples = peopleSeedsProv.map((seedProv, id) => {
    const list = provs.filter((p) => peopleOf[p.id] === id);
    const culture = cultureFor(list);
    return { id, name: namer.region(culture), culture, color: PEOPLE_COLORS[id % PEOPLE_COLORS.length], provinces: list.map((p) => p.id), capital: -1 };
  });
  const zoneCulture = (p) => {
    if (peopleOf[p.id] >= 0) return peoples[peopleOf[p.id]].culture;
    return cultureFor([p]);
  };
  const provinceOut = provs.map((p) => ({
    id: p.id,
    name: namer.region(zoneCulture(p)),
    center: p.center,
    size: p.cells.length,
    na: p.na,
    people: peopleOf[p.id] >= 0 ? peopleOf[p.id] : null
  }));
  const cellScore = (c) => {
    if (isWater(terrain[c]) || terrain[c] === "I") return -Infinity;
    const yieldOf = (x) => ({ P: 3, F: 3, D: 1, T: 1, M: 2, S: 1.5, O: 1, I: 0 })[terrain[x]];
    let s = yieldOf(c) * 1.5;
    for (const n of neighbors[c]) s += yieldOf(n);
    if (neighbors[c].some((x) => isWater(terrain[x]))) s += 2.5;
    if (terrain[c] === "M") s -= 3;
    return s;
  };
  const cities = [];
  const taken = /* @__PURE__ */ new Set();
  for (const people of peoples) {
    const sites = [];
    for (const pid of people.provinces) {
      const options = provs[pid].cells.filter((c) => !taken.has(c) && !neighbors[c].some((n) => taken.has(n)));
      if (!options.length) continue;
      const best = options.reduce((a, b) => cellScore(b) > cellScore(a) ? b : a);
      if (cellScore(best) < 9) continue;
      sites.push(best);
      taken.add(best);
    }
    sites.sort((a, b) => cellScore(b) - cellScore(a));
    sites.forEach((cell, k) => {
      const index = cities.length;
      cities.push({ cell, name: namer.city(people.culture), people: people.id, capital: k === 0 });
      if (k === 0) people.capital = index;
    });
  }
  const mountainCells = landCells.filter((c) => terrain[c] === "M");
  const mcomp = components(mountainCells, neighbors);
  const ranges = Array.from({ length: mcomp.count }, () => []);
  for (const c of mountainCells) ranges[mcomp.comp.get(c)].push(c);
  const features = ranges.filter((list) => list.length >= 4).map((list) => ({ kind: "mountains", name: `\u0425\u0440\u0435\u0431\u0435\u0442 ${namer.city("highland")}`, cell: list[Math.floor(list.length / 2)], size: list.length }));
  const OCEANS = [
    { lat: 30, lon: -40 },
    { lat: -25, lon: -15 },
    { lat: 20, lon: -150 },
    { lat: -30, lon: -120 },
    { lat: -20, lon: 75 },
    { lat: 82, lon: 0 },
    { lat: -62, lon: 60 }
  ];
  for (const o of OCEANS) features.push({ kind: "ocean", name: `\u041E\u043A\u0435\u0430\u043D ${namer.city("coastal")}`, cell: nearestCell(grid, o) });
  const startZones = START_ZONES.map((zone) => {
    const candidates = landCells.filter((c) => isNorthAmerica(cells[c]) && province[c] >= 0 && ["P", "F"].includes(terrain[c]) && haversineKm(cells[c], zone.anchor) <= 700);
    if (!candidates.length) throw new Error(`\u041D\u0435\u0442 \u043C\u0435\u0441\u0442\u0430 \u0434\u043B\u044F \u0441\u0442\u0430\u0440\u0442\u043E\u0432\u043E\u0439 \u0437\u043E\u043D\u044B ${zone.id}`);
    const cell = candidates.reduce((a, b) => cellScore(b) - haversineKm(cells[b], zone.anchor) / 300 > cellScore(a) - haversineKm(cells[a], zone.anchor) / 300 ? b : a);
    return { id: zone.id, name: zone.name, cell, province: province[cell] };
  });
  return {
    province: Array.from(province),
    provinces: provinceOut,
    peoples: peoples.map(({ id, name, culture, color, capital }) => ({ id, name, culture, color, capital })),
    cities,
    features,
    startZones
  };
}

// src/game/map.js
var DEFAULT_PATH = fileURLToPath(new URL("../../data/game/map.json", import.meta.url));
var STOP_LIST_PATH = fileURLToPath(new URL("../../data/game/real-names-stoplist.json", import.meta.url));
var stopList = null;
function loadStopList() {
  stopList ??= JSON.parse(readFileSync(STOP_LIST_PATH, "utf8"));
  return stopList;
}
var cached = null;
function prepareMap(input) {
  const source = { ...input, terrain: Array.isArray(input.terrain) ? input.terrain.join("") : input.terrain };
  const grid = buildGrid(source.gridLevel);
  if (source.terrain.length !== grid.cells.length) throw new Error("map.json \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0441\u0435\u0442\u043A\u0435");
  const raw = { ...source, ...buildWorld(source.terrain, { grid, stopList: loadStopList() }) };
  const terrain = raw.terrain;
  const coast = new Uint8Array(grid.cells.length);
  for (let i = 0; i < grid.cells.length; i += 1) {
    if (!isWater(terrain[i]) && grid.neighbors[i].some((n) => isWater(terrain[n]))) coast[i] = 1;
  }
  const naCells = /* @__PURE__ */ new Set();
  raw.province.forEach((p, cell) => {
    if (p >= 0 && raw.provinces[p].na) naCells.add(cell);
  });
  return {
    raw,
    cells: grid.cells,
    neighbors: grid.neighbors,
    terrain,
    coast,
    province: raw.province,
    provinces: raw.provinces,
    peoples: raw.peoples,
    cities: raw.cities,
    startZones: raw.startZones,
    features: raw.features,
    naCells,
    size: grid.cells.length
  };
}
function loadMap(path2 = DEFAULT_PATH) {
  if (cached && cached.path === path2) return cached.map;
  const map = prepareMap(JSON.parse(readFileSync(path2, "utf8")));
  cached = { path: path2, map };
  return map;
}
function cellsWithin(map, start, radius, allowed = () => true) {
  const seen = /* @__PURE__ */ new Map([[start, 0]]);
  const order = [start];
  for (let i = 0; i < order.length; i += 1) {
    const c = order[i];
    const d = seen.get(c);
    if (d >= radius) continue;
    for (const n of map.neighbors[c]) {
      if (seen.has(n) || !allowed(n)) continue;
      seen.set(n, d + 1);
      order.push(n);
    }
  }
  return order;
}
function hopDistance(map, a, b, limit = 64) {
  if (a === b) return 0;
  const seen = /* @__PURE__ */ new Set([a]);
  let frontier = [a];
  for (let d = 1; d <= limit; d += 1) {
    const next = [];
    for (const c of frontier) for (const n of map.neighbors[c]) {
      if (n === b) return d;
      if (!seen.has(n)) {
        seen.add(n);
        next.push(n);
      }
    }
    frontier = next;
  }
  return Infinity;
}

// src/game/data/nations.js
var DOCTRINES = Object.freeze({
  resilience: { name: "\u0421\u0442\u043E\u0439\u043A\u043E\u0441\u0442\u044C", tundraFood: 1, cityDefense: 0.25, domeBonus: 0.5 },
  trade: { name: "\u0422\u043E\u0440\u0433\u043E\u0432\u043B\u044F", goldPct: 0.2, tradeRoutes: 1, domeBonus: 0.1 },
  diplomacy: { name: "\u0414\u0438\u043F\u043B\u043E\u043C\u0430\u0442\u0438\u044F", treatyDiscount: 0.5, influence: 2, domeBonus: 0.2 },
  science: { name: "\u041D\u0430\u0443\u043A\u0430", sciencePct: 0.15, spaceDiscount: 0.1, domeBonus: 0.35 },
  expansion: { name: "\u042D\u043A\u0441\u043F\u0430\u043D\u0441\u0438\u044F", settlerDiscount: 0.25 }
});
var NATIONS = Object.freeze([
  {
    id: "borea",
    name: "\u0411\u043E\u0440\u0435\u044F",
    color: "#7FB2D9",
    zone: "north",
    doctrine: "resilience",
    emblem: { shield: "heater", figure: "star-over-mountain", field: "#24364a" },
    ai: { aggression: 0.35, loyalty: 0.9, coop: 0.7, focus: "defense" }
  },
  {
    id: "cartel",
    name: "\u041D\u043E\u0432\u044B\u0439 \u041A\u0430\u0440\u0442\u0435\u043B\u044C",
    color: "#D9A441",
    zone: "atlantic",
    doctrine: "trade",
    emblem: { shield: "round", figure: "scales-gear", field: "#3a2c12" },
    ai: { aggression: 0.5, loyalty: 0.4, coop: 0.45, focus: "economy" }
  },
  {
    id: "meridian",
    name: "\u041B\u0438\u0433\u0430 \u041C\u0435\u0440\u0438\u0434\u0438\u0430\u043D\u0430",
    color: "#4CB39A",
    zone: "pacific",
    doctrine: "diplomacy",
    emblem: { shield: "kite", figure: "compass-meridian", field: "#123a32" },
    ai: { aggression: 0.2, loyalty: 0.8, coop: 0.9, focus: "diplomacy" }
  },
  {
    id: "auris",
    name: "\u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430 \u0410\u0443\u0440\u0438\u0441",
    color: "#C8574D",
    zone: "south",
    doctrine: "science",
    emblem: { shield: "swiss", figure: "sun-orbit", field: "#3d1714" },
    ai: { aggression: 0.4, loyalty: 0.6, coop: 0.6, focus: "science" }
  }
]);
var CUSTOM_NATION_RULES = Object.freeze({
  nameMin: 2,
  nameMax: 24,
  shields: ["heater", "round", "kite", "swiss", "french", "lozenge"],
  figures: ["star-over-mountain", "scales-gear", "compass-meridian", "sun-orbit", "wolf", "anchor", "tower", "wave", "eagle", "tree", "crown", "rocket"],
  palette: ["#7FB2D9", "#D9A441", "#4CB39A", "#C8574D", "#9B7FD9", "#D97FB0", "#7FD98C", "#D9D27F", "#5A8FD9", "#D98A5A", "#A0A8B8", "#E0E0E0"]
});

// src/game/i18n/ru.js
var ERRORS = Object.freeze({
  NO_GAME: "\u041F\u0430\u0440\u0442\u0438\u044F \u043D\u0435 \u043D\u0430\u0447\u0430\u0442\u0430",
  GAME_OVER: "\u041F\u0430\u0440\u0442\u0438\u044F \u043E\u043A\u043E\u043D\u0447\u0435\u043D\u0430",
  BATTLE_ACTIVE: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0431\u043E\u0439",
  BAD_COMMAND: "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430",
  NOT_YOUR_UNIT: "\u042D\u0442\u043E \u043D\u0435 \u0432\u0430\u0448 \u044E\u043D\u0438\u0442",
  NOT_YOUR_CITY: "\u042D\u0442\u043E \u043D\u0435 \u0432\u0430\u0448 \u0433\u043E\u0440\u043E\u0434",
  NO_MOVES: "\u0423 \u044E\u043D\u0438\u0442\u0430 \u043D\u0435 \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0445\u043E\u0434\u043E\u0432",
  NO_PATH: "\u0422\u0443\u0434\u0430 \u043D\u0435 \u043F\u0440\u043E\u0439\u0442\u0438",
  CELL_OCCUPIED: "\u041A\u043B\u0435\u0442\u043A\u0430 \u0437\u0430\u043D\u044F\u0442\u0430",
  NOT_AT_WAR: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043D\u0443\u0436\u043D\u043E \u043E\u0431\u044A\u044F\u0432\u0438\u0442\u044C \u0432\u043E\u0439\u043D\u0443",
  NOT_SETTLER: "\u0413\u043E\u0440\u043E\u0434 \u043E\u0441\u043D\u043E\u0432\u044B\u0432\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u0435\u043B\u0435\u043D\u0435\u0446",
  BAD_CITY_SITE: "\u0417\u0434\u0435\u0441\u044C \u043D\u0435\u043B\u044C\u0437\u044F \u043E\u0441\u043D\u043E\u0432\u0430\u0442\u044C \u0433\u043E\u0440\u043E\u0434",
  TOO_CLOSE_TO_CITY: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043B\u0438\u0437\u043A\u043E \u043A \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u0433\u043E\u0440\u043E\u0434\u0443",
  TECH_UNAVAILABLE: "\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430",
  ITEM_UNAVAILABLE: "\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0441\u0442\u0440\u043E\u0438\u0442\u044C",
  NEED_RESOURCE: "\u041D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u0441\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0440\u0435\u0441\u0443\u0440\u0441\u0430",
  NEED_SPACEPORT: "\u041D\u0443\u0436\u0435\u043D \u043A\u043E\u0441\u043C\u043E\u0434\u0440\u043E\u043C",
  NEED_SILO: "\u041D\u0443\u0436\u043D\u0430 \u0440\u0430\u043A\u0435\u0442\u043D\u0430\u044F \u0448\u0430\u0445\u0442\u0430",
  NOT_ENOUGH_GOLD: "\u041D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u0437\u043E\u043B\u043E\u0442\u0430",
  NOT_ENOUGH_INFLUENCE: "\u041D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u0432\u043B\u0438\u044F\u043D\u0438\u044F",
  NOT_ENOUGH_SCIENCE: "\u041D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u043D\u0430\u0443\u043A\u0438",
  UNKNOWN_NATION: "\u041D\u0435\u0442 \u0442\u0430\u043A\u043E\u0439 \u043D\u0430\u0446\u0438\u0438",
  NOT_MET: "\u0412\u044B \u0435\u0449\u0451 \u043D\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0430\u043B\u0438\u0441\u044C",
  ALREADY_AT_WAR: "\u0412\u043E\u0439\u043D\u0430 \u0443\u0436\u0435 \u0438\u0434\u0451\u0442",
  TRUCE: "\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0435\u0440\u0435\u043C\u0438\u0440\u0438\u0435",
  TREATY_EXISTS: "\u0414\u043E\u0433\u043E\u0432\u043E\u0440 \u0443\u0436\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442",
  NO_TREATY: "\u0422\u0430\u043A\u043E\u0433\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u043D\u0435\u0442",
  REJECTED: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E",
  BAD_OFFER: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E",
  RELATION_TOO_LOW: "\u041E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u043F\u043B\u043E\u0445\u0438\u0435",
  NO_FINALE: "\u0410\u0441\u0442\u0435\u0440\u043E\u0438\u0434 \u0435\u0449\u0451 \u043D\u0435 \u043E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D",
  PATH_LOCKED: "\u0412\u0441\u0442\u0443\u043F\u0438\u0442\u044C \u0432 \u043F\u0430\u043A\u0442 \u0443\u0436\u0435 \u043F\u043E\u0437\u0434\u043D\u043E",
  BAD_PATH: "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0443\u0442\u044C",
  NOT_IN_PACT: "\u0412\u044B \u043D\u0435 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A \u043F\u0430\u043A\u0442\u0430 \xAB\u041A\u0443\u043F\u043E\u043B\xBB",
  BAD_SETUP: "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043D\u0430\u0446\u0438\u0438",
  EMPTY_DEAL: "\u0412 \u0441\u0434\u0435\u043B\u043A\u0435 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435\u0442",
  CAPITAL_NOT_FOR_SALE: "\u0421\u0442\u043E\u043B\u0438\u0446\u0443 \u043D\u0435 \u043E\u0442\u0434\u0430\u044E\u0442",
  AGENTS_BUSY: "\u0410\u0433\u0435\u043D\u0442\u044B \u0435\u0449\u0451 \u043D\u0435 \u0432\u0435\u0440\u043D\u0443\u043B\u0438\u0441\u044C \u0441 \u043F\u0440\u043E\u0448\u043B\u043E\u0433\u043E \u0437\u0430\u0434\u0430\u043D\u0438\u044F",
  NOTHING_TO_STEAL: "\u041A\u0440\u0430\u0441\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E: \u0432\u0441\u0435 \u0438\u0445 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438 \u0432\u0430\u043C \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B",
  COUNTER: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E, \u0435\u0441\u0442\u044C \u0432\u0441\u0442\u0440\u0435\u0447\u043D\u043E\u0435",
  INTERNAL: "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u043E\u0448\u0438\u0431\u043A\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430. \u041F\u0430\u0440\u0442\u0438\u044F \u043D\u0435 \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u0430",
  TOO_LARGE: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435",
  RATE_LIMIT: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u043A\u043E\u043C\u0430\u043D\u0434 \u043F\u043E\u0434\u0440\u044F\u0434, \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0441\u0435\u043A\u0443\u043D\u0434\u0443",
  TECH_NOT_READY: "\u041F\u043E\u043B\u0443\u0447\u0430\u0442\u0435\u043B\u044C \u0435\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432 \u043A \u044D\u0442\u043E\u0439 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438",
  HAS_TREATY: "\u041D\u0435\u043B\u044C\u0437\u044F \u0443\u0433\u0440\u043E\u0436\u0430\u0442\u044C \u0442\u043E\u043C\u0443, \u0441 \u043A\u0435\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0430\u043A\u0442 \u0438\u043B\u0438 \u0441\u043E\u044E\u0437",
  DEMAND_COOLDOWN: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0440\u0430\u043D\u043E \u0434\u043B\u044F \u043D\u043E\u0432\u043E\u0433\u043E \u0443\u043B\u044C\u0442\u0438\u043C\u0430\u0442\u0443\u043C\u0430",
  EMBARKED: "\u0412\u043E\u0439\u0441\u043A\u0430 \u043D\u0430 \u043A\u043E\u0440\u0430\u0431\u043B\u044F\u0445 \u043D\u0435 \u043C\u043E\u0433\u0443\u0442 \u0430\u0442\u0430\u043A\u043E\u0432\u0430\u0442\u044C",
  NO_TARGET: "\u041F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0435\u0439 \u0446\u0435\u043B\u0438 \u043D\u0435\u0442",
  QUEUE_FULL: "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0430",
  NOT_WARHEAD: "\u042D\u0442\u043E \u043D\u0435 \u0431\u0430\u043B\u043B\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0440\u0430\u043A\u0435\u0442\u0430",
  NOT_EXPLORED: "\u0426\u0435\u043B\u044C \u043D\u0435 \u0440\u0430\u0437\u0432\u0435\u0434\u0430\u043D\u0430: \u043D\u0443\u0436\u043D\u0430 \u043A\u0430\u0440\u0442\u0430 \u044D\u0442\u043E\u0439 \u043C\u0435\u0441\u0442\u043D\u043E\u0441\u0442\u0438",
  NOT_SATELLITE: "\u0420\u0430\u0437\u0432\u0435\u0434\u043A\u0443 \u0441 \u043E\u0440\u0431\u0438\u0442\u044B \u0432\u0435\u0434\u0451\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u043F\u0443\u0442\u043D\u0438\u043A",
  RECON_COOLDOWN: "\u0421\u043F\u0443\u0442\u043D\u0438\u043A \u0435\u0449\u0451 \u043D\u0435 \u0432\u044B\u0448\u0435\u043B \u043D\u0430 \u043D\u0443\u0436\u043D\u0443\u044E \u043E\u0440\u0431\u0438\u0442\u0443"
});
var EVENTS = Object.freeze({
  gameStart: ({ nation }) => `\u041D\u0430\u0446\u0438\u044F \xAB${nation}\xBB \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442 \u0441\u0432\u043E\u044E \u0438\u0441\u0442\u043E\u0440\u0438\u044E.`,
  cityFounded: ({ nation, city }) => `${nation}: \u043E\u0441\u043D\u043E\u0432\u0430\u043D \u0433\u043E\u0440\u043E\u0434 \xAB${city}\xBB.`,
  cityGrew: ({ city, pop }) => `\u0413\u043E\u0440\u043E\u0434 \xAB${city}\xBB: \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u0438\u0435 \u0432\u044B\u0440\u043E\u0441\u043B\u043E \u0434\u043E ${pop}.`,
  built: ({ city, item }) => `\u0413\u043E\u0440\u043E\u0434 \xAB${city}\xBB: \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E \u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E (\xAB${item}\xBB).`,
  techLearned: ({ nation, tech }) => `${nation}: \u043E\u0442\u043A\u0440\u044B\u0442\u043E \xAB${tech}\xBB.`,
  eraReached: ({ nation, era }) => `${nation}: \u043D\u0430\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u044D\u043F\u043E\u0445\u0430 \xAB${era}\xBB.`,
  met: ({ a, b }) => `\u041F\u0435\u0440\u0432\u0430\u044F \u0432\u0441\u0442\u0440\u0435\u0447\u0430: ${a} \u0438 ${b}.`,
  war: ({ a, b }) => `${a} \u043E\u0431\u044A\u044F\u0432\u043B\u044F\u0435\u0442 \u0432\u043E\u0439\u043D\u0443. \u041F\u0440\u043E\u0442\u0438\u0432\u043D\u0438\u043A: ${b}.`,
  peace: ({ a, b }) => `\u041C\u0438\u0440 \u0437\u0430\u043A\u043B\u044E\u0447\u0451\u043D: ${a} \u0438 ${b}.`,
  treaty: ({ a, b, treaty }) => `${a} \u0438 ${b}: ${treaty}.`,
  treatyBroken: ({ a, b, treaty }) => `${a} \u0440\u0430\u0437\u0440\u044B\u0432\u0430\u0435\u0442 \u0434\u043E\u0433\u043E\u0432\u043E\u0440 (\xAB${treaty}\xBB). \u041F\u043E\u0441\u0442\u0440\u0430\u0434\u0430\u0432\u0448\u0430\u044F \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${b}.`,
  offer: ({ from, treaty }) => `${from} \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u0442: ${treaty}.`,
  battleWon: ({ attacker, defender }) => `\u0411\u043E\u0439 \u0432\u044B\u0438\u0433\u0440\u0430\u043D: ${attacker}. \u041F\u0440\u043E\u0442\u0438\u0432\u043D\u0438\u043A: ${defender}.`,
  battleLost: ({ attacker, defender }) => `\u0410\u0442\u0430\u043A\u0430 \u043E\u0442\u0431\u0438\u0442\u0430: ${attacker}. \u041E\u0431\u043E\u0440\u043E\u043D\u0430: ${defender}.`,
  cityCaptured: ({ nation, city }) => `${nation} \u0437\u0430\u0445\u0432\u0430\u0442\u044B\u0432\u0430\u0435\u0442 \u0433\u043E\u0440\u043E\u0434 \xAB${city}\xBB.`,
  annexed: ({ nation, people }) => `\u041D\u0430\u0440\u043E\u0434 \xAB${people}\xBB \u0434\u043E\u0431\u0440\u043E\u0432\u043E\u043B\u044C\u043D\u043E \u043F\u0440\u0438\u0441\u043E\u0435\u0434\u0438\u043D\u044F\u0435\u0442\u0441\u044F. \u041D\u043E\u0432\u044B\u0439 \u0434\u043E\u043C: ${nation}.`,
  asteroid: ({ turns }) => `\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D \u0430\u0441\u0442\u0435\u0440\u043E\u0438\u0434 \xAB\u041D\u0435\u043C\u0435\u0437\u0438\u0434\u0430\xBB. \u0414\u043E \u0441\u0442\u043E\u043B\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0445\u043E\u0434\u043E\u0432: ${turns}.`,
  pactJoined: ({ nation }) => `${nation} \u0432\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u0432 \u043F\u0430\u043A\u0442 \xAB\u041A\u0443\u043F\u043E\u043B\xBB.`,
  pactLeft: ({ nation }) => `${nation} \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0438\u0437 \u043F\u0430\u043A\u0442\u0430 \xAB\u041A\u0443\u043F\u043E\u043B\xBB.`,
  arkChosen: ({ nation }) => `${nation} \u0441\u0442\u0440\u043E\u0438\u0442 \u041A\u043E\u0432\u0447\u0435\u0433 \u0438 \u0441\u043F\u0430\u0441\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u0431\u044F.`,
  tracking: () => "\u0421\u0435\u0442\u044C \u0441\u043B\u0435\u0436\u0435\u043D\u0438\u044F \xAB\u041A\u0443\u043F\u043E\u043B\u0430\xBB \u0437\u0430\u043C\u043A\u043D\u0443\u0442\u0430: \u043E\u0440\u0431\u0438\u0442\u0430 \u0430\u0441\u0442\u0435\u0440\u043E\u0438\u0434\u0430 \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430 \u0442\u043E\u0447\u043D\u043E.",
  impact: ({ outcome }) => ({ saved: "\u0410\u0441\u0442\u0435\u0440\u043E\u0438\u0434 \u0443\u043D\u0438\u0447\u0442\u043E\u0436\u0435\u043D \u0432 \u043A\u043E\u0441\u043C\u043E\u0441\u0435. \u041F\u043B\u0430\u043D\u0435\u0442\u0430 \u0441\u043F\u0430\u0441\u0435\u043D\u0430.", partial: "\u0410\u0441\u0442\u0435\u0440\u043E\u0438\u0434 \u0440\u0430\u0437\u0440\u0443\u0448\u0435\u043D, \u043D\u043E \u043E\u0431\u043B\u043E\u043C\u043A\u0438 \u0443\u043F\u0430\u043B\u0438 \u043D\u0430 \u0417\u0435\u043C\u043B\u044E.", fail: "\u0423\u0434\u0430\u0440. \xAB\u041A\u0443\u043F\u043E\u043B\xBB \u043D\u0435 \u0432\u044B\u0434\u0435\u0440\u0436\u0430\u043B." })[outcome] ?? "\u0423\u0434\u0430\u0440 \u0430\u0441\u0442\u0435\u0440\u043E\u0438\u0434\u0430.",
  conquest: ({ nation }) => `${nation}: \u0432\u0441\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0441\u0442\u043E\u043B\u0438\u0446\u044B \u043C\u0438\u0440\u0430 \u043F\u043E\u043A\u043E\u0440\u0435\u043D\u044B.`,
  eliminated: ({ nation }) => `${nation}: \u043D\u0430\u0446\u0438\u044F \u0443\u043D\u0438\u0447\u0442\u043E\u0436\u0435\u043D\u0430.`,
  dealDone: ({ a, b }) => `\u0421\u0434\u0435\u043B\u043A\u0430 \u0437\u0430\u043A\u043B\u044E\u0447\u0435\u043D\u0430: ${a} \u0438 ${b}.`,
  demandAccepted: ({ a, b }) => `\u0423\u043B\u044C\u0442\u0438\u043C\u0430\u0442\u0443\u043C \u043F\u0440\u0438\u043D\u044F\u0442. \u0423\u0441\u0442\u0443\u043F\u0438\u043B\u0430 \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${a}. \u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043B\u0430 \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${b}.`,
  demandRefused: ({ a, b }) => `\u0423\u043B\u044C\u0442\u0438\u043C\u0430\u0442\u0443\u043C \u043E\u0442\u0432\u0435\u0440\u0433\u043D\u0443\u0442. \u041E\u0442\u043A\u0430\u0437\u0430\u043B\u0430 \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${a}. \u0422\u0440\u0435\u0431\u043E\u0432\u0430\u043B\u0430 \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${b}.`,
  bluffCalled: ({ nation }) => `${nation}: \u0443\u0433\u0440\u043E\u0437\u0430 \u0432\u043E\u0439\u043D\u043E\u0439 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0430. \u0423\u0433\u0440\u043E\u0437\u0430\u043C \u044D\u0442\u043E\u0439 \u043D\u0430\u0446\u0438\u0438 \u0442\u0435\u043F\u0435\u0440\u044C \u0432\u0435\u0440\u044F\u0442 \u043C\u0435\u043D\u044C\u0448\u0435.`,
  plotExposed: ({ actor, target, op }) => `\u0420\u0430\u0441\u043A\u0440\u044B\u0442 \u0437\u0430\u0433\u043E\u0432\u043E\u0440 (\xAB${op}\xBB). \u0417\u0430\u043A\u0430\u0437\u0447\u0438\u043A: ${actor}. \u0426\u0435\u043B\u044C: ${target}.`,
  plotHidden: ({ target, op }) => `${target}: \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0435 \u043F\u0440\u043E\u0432\u0435\u043B\u0438 \u0442\u0430\u0439\u043D\u0443\u044E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E (\xAB${op}\xBB).`,
  plotSuccess: ({ op, target }) => `\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \xAB${op}\xBB \u0443\u0434\u0430\u043B\u0430\u0441\u044C. \u0426\u0435\u043B\u044C: ${target}.`,
  plotFailed: ({ op, target }) => `\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \xAB${op}\xBB \u043F\u0440\u043E\u0432\u0430\u043B\u0438\u043B\u0430\u0441\u044C. \u0426\u0435\u043B\u044C: ${target}.`,
  nuclearStrike: ({ a, b, city }) => `\u042F\u0414\u0415\u0420\u041D\u042B\u0419 \u0423\u0414\u0410\u0420. ${a} \u0431\u044C\u0451\u0442 \u043F\u043E \u0433\u043E\u0440\u043E\u0434\u0443 \xAB${city}\xBB. \u041F\u043E\u0441\u0442\u0440\u0430\u0434\u0430\u0432\u0448\u0430\u044F \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${b}. \u041C\u0438\u0440 \u0432 \u0443\u0436\u0430\u0441\u0435.`,
  nuclearStrikeField: ({ a, b }) => `\u042F\u0414\u0415\u0420\u041D\u042B\u0419 \u0423\u0414\u0410\u0420. ${a} \u0431\u044C\u0451\u0442 \u043F\u043E \u0437\u0435\u043C\u043B\u0435 \u043F\u0440\u043E\u0442\u0438\u0432\u043D\u0438\u043A\u0430. \u041F\u043E\u0441\u0442\u0440\u0430\u0434\u0430\u0432\u0448\u0430\u044F \u0441\u0442\u043E\u0440\u043E\u043D\u0430: ${b}.`,
  nuclearIntercepted: ({ a, b }) => `\u0420\u0430\u043A\u0435\u0442\u0430 \u043F\u0435\u0440\u0435\u0445\u0432\u0430\u0447\u0435\u043D\u0430. \u041F\u043E\u043F\u044B\u0442\u043A\u0430 \u044F\u0434\u0435\u0440\u043D\u043E\u0433\u043E \u0443\u0434\u0430\u0440\u0430: ${a}. \u0426\u0435\u043B\u044C: ${b}.`,
  warheadDismantled: ({ nation, points }) => `${nation}: \u0431\u043E\u0435\u0433\u043E\u043B\u043E\u0432\u043A\u0430 \u0440\u0430\u0437\u043E\u0431\u0440\u0430\u043D\u0430, ${points} \u043E\u0447\u043A\u043E\u0432 \u0443\u0448\u043B\u043E \u0432 \u0449\u0438\u0442 \xAB\u041A\u0443\u043F\u043E\u043B\u0430\xBB.`
});
var TREATY_NAMES = Object.freeze({
  nap: "\u043F\u0430\u043A\u0442 \u043E \u043D\u0435\u043D\u0430\u043F\u0430\u0434\u0435\u043D\u0438\u0438",
  trade: "\u0442\u043E\u0440\u0433\u043E\u0432\u044B\u0439 \u0434\u043E\u0433\u043E\u0432\u043E\u0440",
  alliance: "\u0441\u043E\u044E\u0437",
  research: "\u043D\u0430\u0443\u0447\u043D\u044B\u0439 \u043F\u0430\u043A\u0442"
});
var ENDINGS = Object.freeze({
  saved: "\u0421\u043F\u0430\u0441\u0435\u043D\u0438\u0435",
  partial: "\u0427\u0430\u0441\u0442\u0438\u0447\u043D\u044B\u0439 \u0443\u0441\u043F\u0435\u0445",
  lastRefuge: "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u0443\u0431\u0435\u0436\u0438\u0449\u0435",
  silence: "\u0422\u0438\u0448\u0438\u043D\u0430",
  betrayal: "\u041F\u0440\u0435\u0434\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E",
  conquest: "\u041F\u043E\u043A\u043E\u0440\u0435\u043D\u0438\u0435 \u043C\u0438\u0440\u0430",
  defeat: "\u041F\u043E\u0440\u0430\u0436\u0435\u043D\u0438\u0435"
});
var LEADER_LINES = Object.freeze({
  greet: {
    pride: ["\u0413\u043E\u0432\u043E\u0440\u0438\u0442\u0435. \u0422\u043E\u043B\u044C\u043A\u043E \u043A\u043E\u0440\u043E\u0442\u043A\u043E.", "\u041C\u044B \u0441\u043B\u0443\u0448\u0430\u0435\u043C \u0432\u0430\u0441. \u041F\u043E\u043A\u0430 \u0441\u043B\u0443\u0448\u0430\u0435\u043C."],
    greed: ["\u0420\u0430\u0434\u044B \u0432\u0430\u0441 \u0432\u0438\u0434\u0435\u0442\u044C. \u041D\u0430\u0434\u0435\u0435\u043C\u0441\u044F, \u0432\u044B \u0441 \u0432\u044B\u0433\u043E\u0434\u043D\u044B\u043C \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C.", "\u0412\u0440\u0435\u043C\u044F \u2014 \u0434\u0435\u043D\u044C\u0433\u0438. \u0427\u0442\u043E \u0443 \u0432\u0430\u0441?"],
    honor: ["\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C. \u0417\u0434\u0435\u0441\u044C \u0441\u043B\u043E\u0432\u043E \u0441\u0442\u043E\u0438\u0442 \u0434\u043E\u0440\u043E\u0436\u0435 \u0437\u043E\u043B\u043E\u0442\u0430.", "\u041C\u044B \u043F\u043E\u043C\u043D\u0438\u043C \u0432\u0441\u0435\u0445, \u043A\u0442\u043E \u0434\u0435\u0440\u0436\u0430\u043B \u0441\u043B\u043E\u0432\u043E."],
    cunning: ["\u041A\u0430\u043A \u043D\u0435\u043E\u0436\u0438\u0434\u0430\u043D\u043D\u043E. \u041C\u044B \u043A\u0430\u043A \u0440\u0430\u0437 \u0434\u0443\u043C\u0430\u043B\u0438 \u043E \u0432\u0430\u0441.", "\u0421\u0430\u0434\u0438\u0442\u0435\u0441\u044C. \u041F\u043E\u0433\u043E\u0432\u043E\u0440\u0438\u043C \u043E\u0442\u043A\u0440\u043E\u0432\u0435\u043D\u043D\u043E, \u043D\u0430\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u044D\u0442\u043E \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E."],
    caution: ["\u041C\u044B \u0437\u0430 \u043C\u0438\u0440. \u0414\u0430\u0432\u0430\u0439\u0442\u0435 \u043D\u0435 \u0442\u043E\u0440\u043E\u043F\u0438\u0442\u044C\u0441\u044F.", "\u0420\u0430\u0434\u044B \u0431\u0435\u0441\u0435\u0434\u0435, \u043F\u043E\u043A\u0430 \u043E\u043D\u0430 \u043E\u0441\u0442\u0430\u0451\u0442\u0441\u044F \u0431\u0435\u0441\u0435\u0434\u043E\u0439."]
  },
  acceptDeal: {
    pride: ["\u041F\u0443\u0441\u0442\u044C \u0442\u0430\u043A. \u042D\u0442\u043E \u0434\u043E\u0441\u0442\u043E\u0439\u043D\u043E \u043D\u0430\u0441 \u043E\u0431\u043E\u0438\u0445."],
    greed: ["\u041E\u0442\u043B\u0438\u0447\u043D\u0430\u044F \u0441\u0434\u0435\u043B\u043A\u0430. \u041F\u0440\u0438\u044F\u0442\u043D\u043E \u0438\u043C\u0435\u0442\u044C \u0441 \u0432\u0430\u043C\u0438 \u0434\u0435\u043B\u043E.", "\u041F\u043E\u0434\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u043C, \u043F\u043E\u043A\u0430 \u0432\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0434\u0443\u043C\u0430\u043B\u0438."],
    honor: ["\u0414\u043E\u0433\u043E\u0432\u043E\u0440\u0438\u043B\u0438\u0441\u044C. \u041C\u044B \u0441\u0432\u043E\u0451 \u0441\u043B\u043E\u0432\u043E \u0441\u0434\u0435\u0440\u0436\u0438\u043C."],
    cunning: ["\u0420\u0430\u0437\u0443\u043C\u043D\u043E. \u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438\u043C, \u043A\u0442\u043E \u0432\u044B\u0438\u0433\u0440\u0430\u0435\u0442 \u0431\u043E\u043B\u044C\u0448\u0435."],
    caution: ["\u0425\u043E\u0440\u043E\u0448\u043E. \u042D\u0442\u043E \u0443\u043A\u0440\u0435\u043F\u0438\u0442 \u043C\u0438\u0440 \u043C\u0435\u0436\u0434\u0443 \u043D\u0430\u043C\u0438."]
  },
  rejectDeal: {
    pride: ["\u0412\u044B \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u0442\u0435 \u043D\u0430\u043C \u044D\u0442\u043E? \u0421\u043C\u0435\u0448\u043D\u043E.", "\u041D\u0435\u0442. \u0418 \u043D\u0435 \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0439\u0442\u0435 \u0442\u0430\u043A\u043E\u0433\u043E \u0441\u043D\u043E\u0432\u0430."],
    greed: ["\u041D\u0435\u0432\u044B\u0433\u043E\u0434\u043D\u043E. \u0421\u043E\u0432\u0441\u0435\u043C \u043D\u0435\u0432\u044B\u0433\u043E\u0434\u043D\u043E.", "\u041D\u0430\u043C \u043D\u0443\u0436\u0435\u043D \u043F\u043E\u0432\u043E\u0434 \u0441\u043A\u0430\u0437\u0430\u0442\u044C \xAB\u0434\u0430\xBB, \u0430 \u0432\u044B \u0435\u0433\u043E \u043D\u0435 \u0434\u0430\u043B\u0438."],
    honor: ["\u041C\u044B \u043D\u0435 \u043C\u043E\u0436\u0435\u043C \u043D\u0430 \u044D\u0442\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0442\u044C\u0441\u044F.", "\u041F\u043E\u0434 \u0442\u0430\u043A\u043E\u0439 \u0441\u0434\u0435\u043B\u043A\u043E\u0439 \u043C\u044B \u043D\u0435 \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u044C."],
    cunning: ["\u0418\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u043E, \u043D\u043E \u043D\u0435\u0442. \u041F\u043E\u0434\u0443\u043C\u0430\u0439\u0442\u0435 \u0435\u0449\u0451."],
    caution: ["\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0440\u0438\u0441\u043A\u043E\u0432\u0430\u043D\u043D\u043E \u0434\u043B\u044F \u043D\u0430\u0441."]
  },
  counter: {
    pride: ["\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043A \u044D\u0442\u043E\u043C\u0443, \u0438 \u043C\u044B \u043F\u043E\u0434\u0443\u043C\u0430\u0435\u043C."],
    greed: ["\u041F\u043E\u0447\u0442\u0438. \u0415\u0449\u0451 \u043D\u0435\u043C\u043D\u043E\u0433\u043E \u0441\u0432\u0435\u0440\u0445\u0443, \u0438 \u043F\u043E \u0440\u0443\u043A\u0430\u043C.", "\u0426\u0435\u043D\u0430 \u0434\u0440\u0443\u0433\u0430\u044F. \u0412\u043E\u0442 \u043D\u0430\u0448\u0430."],
    honor: ["\u0421\u043F\u0440\u0430\u0432\u0435\u0434\u043B\u0438\u0432\u043E \u0431\u0443\u0434\u0435\u0442 \u0442\u0430\u043A."],
    cunning: ["\u0423 \u043D\u0430\u0441 \u0435\u0441\u0442\u044C \u0432\u0441\u0442\u0440\u0435\u0447\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435. \u0412\u0430\u043C \u043F\u043E\u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F. \u041D\u0430\u0432\u0435\u0440\u043D\u043E\u0435."],
    caution: ["\u041C\u044B \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u044B, \u0435\u0441\u043B\u0438 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u0431\u0443\u0434\u0443\u0442 \u0442\u0430\u043A\u0438\u043C\u0438."]
  },
  demandAccept: {
    pride: ["\u0417\u0430\u0431\u0438\u0440\u0430\u0439\u0442\u0435. \u041D\u043E \u043C\u044B \u044D\u0442\u043E\u0433\u043E \u043D\u0435 \u0437\u0430\u0431\u0443\u0434\u0435\u043C.", "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0432\u0430\u0448\u0430 \u0441\u0438\u043B\u0430. \u0417\u0430\u0432\u0442\u0440\u0430 \u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0438\u043C."],
    greed: ["\u041B\u0430\u0434\u043D\u043E. \u0421\u0447\u0438\u0442\u0430\u0439\u0442\u0435 \u044D\u0442\u043E \u0437\u0430\u0439\u043C\u043E\u043C \u043F\u043E\u0434 \u043E\u0447\u0435\u043D\u044C \u0432\u044B\u0441\u043E\u043A\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u043D\u0442."],
    honor: ["\u041C\u044B \u0443\u0441\u0442\u0443\u043F\u0430\u0435\u043C \u0441\u0438\u043B\u0435, \u0430 \u043D\u0435 \u043F\u0440\u0430\u0432\u0443. \u0417\u0430\u043F\u043E\u043C\u043D\u0438\u0442\u0435 \u044D\u0442\u043E."],
    cunning: ["\u0411\u0435\u0440\u0438\u0442\u0435. \u041A\u0430\u0436\u0434\u0430\u044F \u0443\u0441\u0442\u0443\u043F\u043A\u0430 \u043E\u0434\u043D\u0430\u0436\u0434\u044B \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442\u0441\u044F."],
    caution: ["\u0425\u043E\u0440\u043E\u0448\u043E, \u0445\u043E\u0440\u043E\u0448\u043E. \u0422\u043E\u043B\u044C\u043A\u043E \u0431\u0435\u0437 \u0432\u043E\u0439\u043D\u044B."]
  },
  demandRefuse: {
    pride: ["\u0423\u0433\u0440\u043E\u0436\u0430\u0435\u0442\u0435? \u041F\u0440\u0438\u0445\u043E\u0434\u0438\u0442\u0435 \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0432\u0437\u044F\u0442\u044C.", "\u041E\u0442\u0432\u0435\u0442 \u2014 \u043D\u0435\u0442. \u0412\u0430\u0448\u0438 \u0430\u0440\u043C\u0438\u0438 \u043D\u0430\u0441 \u043D\u0435 \u043F\u0443\u0433\u0430\u044E\u0442."],
    greed: ["\u041F\u043B\u0430\u0442\u0438\u0442\u044C \u0437\u0430 \u0432\u043E\u0437\u0434\u0443\u0445? \u041D\u0435\u0442 \u0443\u0436."],
    honor: ["\u041C\u044B \u043D\u0435 \u0443\u0441\u0442\u0443\u043F\u0430\u0435\u043C \u0448\u0430\u043D\u0442\u0430\u0436\u0443."],
    cunning: ["\u041A\u0440\u0430\u0441\u0438\u0432\u044B\u0439 \u0431\u043B\u0435\u0444. \u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438\u043C, \u0440\u0435\u0448\u0438\u0442\u0435\u0441\u044C \u043B\u0438 \u0432\u044B.", "\u0412\u044B \u043F\u0440\u0430\u0432\u0434\u0430 \u0433\u043E\u0442\u043E\u0432\u044B \u0432\u043E\u0435\u0432\u0430\u0442\u044C? \u041D\u0435 \u0434\u0443\u043C\u0430\u044E."],
    caution: ["\u041C\u044B \u043D\u0435 \u0445\u043E\u0442\u0438\u043C \u0432\u043E\u0439\u043D\u044B, \u043D\u043E \u0438 \u044D\u0442\u043E \u043E\u0442\u0434\u0430\u0442\u044C \u043D\u0435 \u043C\u043E\u0436\u0435\u043C."]
  },
  demandMade: {
    pride: ["\u041E\u0442\u0434\u0430\u0439\u0442\u0435 \u044D\u0442\u043E, \u0438\u043B\u0438 \u043C\u044B \u0432\u043E\u0437\u044C\u043C\u0451\u043C \u0441\u0430\u043C\u0438."],
    greed: ["\u0412\u044B \u0437\u0430\u043F\u043B\u0430\u0442\u0438\u0442\u0435. \u0412\u043E\u043F\u0440\u043E\u0441 \u0442\u043E\u043B\u044C\u043A\u043E, \u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0442\u043E\u0438\u0442 \u0432\u0430\u0448 \u043E\u0442\u043A\u0430\u0437."],
    honor: ["\u041C\u044B \u0442\u0440\u0435\u0431\u0443\u0435\u043C \u0441\u043F\u0440\u0430\u0432\u0435\u0434\u043B\u0438\u0432\u043E\u0441\u0442\u0438. \u0418\u043D\u0430\u0447\u0435 \u0431\u0443\u0434\u0435\u0442 \u0432\u043E\u0439\u043D\u0430."],
    cunning: ["\u041D\u0435\u0431\u043E\u043B\u044C\u0448\u0430\u044F \u0443\u0441\u0442\u0443\u043F\u043A\u0430, \u0438 \u0432\u0441\u0435 \u043E\u0441\u0442\u0430\u043D\u0443\u0442\u0441\u044F \u0436\u0438\u0432\u044B. \u0420\u0430\u0437\u0432\u0435 \u043D\u0435 \u0440\u0430\u0437\u0443\u043C\u043D\u043E?"],
    caution: ["\u041D\u0430\u043C \u043D\u0443\u0436\u043D\u043E \u044D\u0442\u043E. \u041D\u0435 \u0437\u0430\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u043D\u0430\u0441 \u043F\u0440\u0438\u0431\u0435\u0433\u0430\u0442\u044C \u043A \u0441\u0438\u043B\u0435."]
  },
  plotExposed: {
    pride: ["\u0412\u0430\u0448\u0438 \u0448\u043F\u0438\u043E\u043D\u044B \u043F\u043E\u0439\u043C\u0430\u043D\u044B. \u0417\u0430 \u0442\u0430\u043A\u043E\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u044E\u0442 \u043A\u0440\u043E\u0432\u044C\u044E."],
    greed: ["\u0412\u044B \u043F\u044B\u0442\u0430\u043B\u0438\u0441\u044C \u043D\u0430\u0441 \u043E\u0431\u043E\u043A\u0440\u0430\u0441\u0442\u044C. \u042D\u0442\u043E \u0432\u0430\u043C \u0434\u043E\u0440\u043E\u0433\u043E \u043E\u0431\u043E\u0439\u0434\u0451\u0442\u0441\u044F."],
    honor: ["\u0412\u044B \u0443\u043B\u044B\u0431\u0430\u043B\u0438\u0441\u044C \u043D\u0430\u043C \u0438 \u043F\u043B\u0435\u043B\u0438 \u0437\u0430\u0433\u043E\u0432\u043E\u0440. \u0411\u043E\u043B\u044C\u0448\u0435 \u043C\u044B \u0432\u0430\u043C \u043D\u0435 \u0432\u0435\u0440\u0438\u043C."],
    cunning: ["\u041D\u0435\u0443\u043A\u043B\u044E\u0436\u0435. \u041E\u0447\u0435\u043D\u044C \u043D\u0435\u0443\u043A\u043B\u044E\u0436\u0435."],
    caution: ["\u041C\u044B \u0437\u043D\u0430\u0435\u043C, \u0447\u0442\u043E \u0432\u044B \u0441\u0434\u0435\u043B\u0430\u043B\u0438. \u0411\u0443\u0434\u044C\u0442\u0435 \u0443\u0432\u0435\u0440\u0435\u043D\u044B, \u044D\u0442\u043E \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043E."]
  }
});
function formatEvent(key2, params = {}) {
  const fn = Object.hasOwn(EVENTS, key2) ? EVENTS[key2] : null;
  return fn ? fn(params) : "\u0421\u043E\u0431\u044B\u0442\u0438\u0435 \u0432 \u043C\u0438\u0440\u0435.";
}
function errorText(code) {
  return typeof code === "string" && Object.hasOwn(ERRORS, code) ? ERRORS[code] : "\u042D\u0442\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0441\u0435\u0439\u0447\u0430\u0441 \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E";
}

// src/game/data/techs.js
var ERAS = Object.freeze([
  { id: 0, name: "\u0414\u0440\u0435\u0432\u043D\u043E\u0441\u0442\u044C", cost: 130 },
  { id: 1, name: "\u0418\u043D\u0434\u0443\u0441\u0442\u0440\u0438\u044F", cost: 740 },
  { id: 2, name: "\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u044D\u043F\u043E\u0445\u0430", cost: 2650 },
  { id: 3, name: "\u041A\u043E\u0441\u043C\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u044D\u043F\u043E\u0445\u0430", cost: 5e3 }
]);
var TECHS_TO_ADVANCE = 4;
var TECHS = Object.freeze({
  agriculture: { era: 0, name: "\u0417\u0435\u043C\u043B\u0435\u0434\u0435\u043B\u0438\u0435", req: [] },
  bronze: { era: 0, name: "\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0431\u0440\u043E\u043D\u0437\u044B", req: [] },
  iron: { era: 0, name: "\u0416\u0435\u043B\u0435\u0437\u043E", req: ["bronze"] },
  writing: { era: 0, name: "\u041F\u0438\u0441\u044C\u043C\u0435\u043D\u043D\u043E\u0441\u0442\u044C", req: [] },
  seafaring: { era: 0, name: "\u041C\u043E\u0440\u0435\u0445\u043E\u0434\u0441\u0442\u0432\u043E", req: [] },
  wheel: { era: 0, name: "\u041A\u043E\u043B\u0435\u0441\u043E", req: ["agriculture"] },
  steam: { era: 1, name: "\u041F\u0430\u0440\u043E\u0432\u043E\u0439 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043B\u044C", req: [] },
  steel: { era: 1, name: "\u0421\u0442\u0430\u043B\u044C", req: ["iron"] },
  electricity: { era: 1, name: "\u042D\u043B\u0435\u043A\u0442\u0440\u0438\u0447\u0435\u0441\u0442\u0432\u043E", req: [] },
  oilDrilling: { era: 1, name: "\u041D\u0435\u0444\u0442\u0435\u0434\u043E\u0431\u044B\u0447\u0430", req: ["steam"] },
  flight: { era: 1, name: "\u0412\u043E\u0437\u0434\u0443\u0445\u043E\u043F\u043B\u0430\u0432\u0430\u043D\u0438\u0435", req: ["steam"] },
  massProduction: { era: 1, name: "\u041C\u0430\u0441\u0441\u043E\u0432\u043E\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E", req: ["electricity"] },
  radio: { era: 2, name: "\u0420\u0430\u0434\u0438\u043E\u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u0438\u043A\u0430", req: [] },
  jet: { era: 2, name: "\u0420\u0435\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043B\u044C", req: ["flight"] },
  computers: { era: 2, name: "\u042D\u0412\u041C", req: ["radio"] },
  drones: { era: 2, name: "\u0411\u0435\u0441\u043F\u0438\u043B\u043E\u0442\u043D\u0438\u043A\u0438", req: ["computers"] },
  networks: { era: 2, name: "\u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u044B\u0435 \u0441\u0435\u0442\u0438", req: ["computers"] },
  rocketry: { era: 2, name: "\u0420\u0430\u043A\u0435\u0442\u043E\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u0435", req: ["jet"] },
  fission: { era: 2, name: "\u042F\u0434\u0435\u0440\u043D\u043E\u0435 \u0434\u0435\u043B\u0435\u043D\u0438\u0435", req: ["rocketry"] },
  satellites: { era: 3, name: "\u041E\u0440\u0431\u0438\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0441\u043F\u0443\u0442\u043D\u0438\u043A\u0438", req: ["rocketry"] },
  heavyLift: { era: 3, name: "\u0422\u044F\u0436\u0451\u043B\u044B\u0435 \u043D\u043E\u0441\u0438\u0442\u0435\u043B\u0438", req: ["rocketry"] },
  deepRadar: { era: 3, name: "\u0420\u0430\u0434\u0430\u0440 \u0434\u0430\u043B\u044C\u043D\u0435\u0433\u043E \u043A\u043E\u0441\u043C\u043E\u0441\u0430", req: ["satellites", "heavyLift"] },
  kinetic: { era: 3, name: "\u041A\u0438\u043D\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u0435\u0440\u0435\u0445\u0432\u0430\u0442", req: ["heavyLift"] },
  fusion: { era: 3, name: "\u0422\u0435\u0440\u043C\u043E\u044F\u0434\u0435\u0440\u043D\u044B\u0435 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043B\u0438", req: ["heavyLift"] },
  shield: { era: 3, name: "\u041F\u043B\u0430\u043D\u0435\u0442\u0430\u0440\u043D\u044B\u0439 \u0449\u0438\u0442", req: ["kinetic", "deepRadar"] }
});
var CATCH_UP_DISCOUNT = 0.1;

// src/game/events.js
var EVENT_LIMIT = 400;
function pushEvent(state, key2, params = {}, audience = "all", extra = {}) {
  state.eventSeq += 1;
  state.events.push({ seq: state.eventSeq, turn: state.turn, key: key2, text: formatEvent(key2, params), audience, ...extra });
  state.stats ??= {};
  state.stats[key2] = (state.stats[key2] ?? 0) + 1;
  if (state.events.length > EVENT_LIMIT) state.events.splice(0, state.events.length - EVENT_LIMIT);
}
var isNeutral = (id) => typeof id === "string" && id.startsWith("p");
var nameOf = (state, id) => (isNeutral(id) ? state.neutrals[id]?.name : state.nations[id]?.name) ?? String(id);
var own = (obj, key2) => typeof key2 === "string" && obj !== null && typeof obj === "object" && Object.hasOwn(obj, key2);
function techLearnable(nation, tech) {
  if (!own(TECHS, tech) || nation.techs.includes(tech)) return false;
  const t = TECHS[tech];
  return t.era <= nation.era && t.req.every((r) => nation.techs.includes(r));
}
function grantTech(state, nation, tech) {
  if (nation.techs.includes(tech)) return false;
  nation.techs.push(tech);
  if (nation.research === tech) nation.research = null;
  while (nation.era < ERAS.length - 1 && nation.techs.filter((t) => TECHS[t].era === nation.era).length >= TECHS_TO_ADVANCE) {
    nation.era += 1;
    pushEvent(state, "eraReached", { nation: nation.name, era: ERAS[nation.era].name });
  }
  return true;
}

// src/game/data/units.js
var UNITS = Object.freeze({
  settler: { name: "\u041F\u043E\u0441\u0435\u043B\u0435\u043D\u0435\u0446", era: 0, cost: 30, str: 0, moves: 2, domain: "land", civilian: true, model: null },
  warrior: { name: "\u0412\u043E\u0438\u043D", era: 0, cost: 15, str: 6, moves: 2, domain: "land", model: null },
  archer: { name: "\u041B\u0443\u0447\u043D\u0438\u043A", era: 0, cost: 20, str: 8, moves: 2, domain: "land", tech: "bronze", model: null },
  swordsman: { name: "\u041C\u0435\u0447\u043D\u0438\u043A", era: 0, cost: 25, str: 10, moves: 2, domain: "land", tech: "iron", resource: "iron", model: null },
  galley: { name: "\u0413\u0430\u043B\u0435\u0440\u0430", era: 0, cost: 25, str: 6, moves: 3, domain: "sea", tech: "seafaring", model: "ship.glb" },
  infantry: { name: "\u041F\u0435\u0445\u043E\u0442\u0430", era: 1, cost: 45, str: 20, moves: 2, domain: "land", tech: "steam", model: null },
  artillery: { name: "\u0410\u0440\u0442\u0438\u043B\u043B\u0435\u0440\u0438\u044F", era: 1, cost: 55, str: 24, moves: 2, domain: "land", tech: "steel", model: null },
  tank: { name: "\u0422\u0430\u043D\u043A", era: 1, cost: 80, str: 36, moves: 3, domain: "land", tech: "massProduction", resource: "oil", model: null },
  ironclad: { name: "\u0411\u0440\u043E\u043D\u0435\u043D\u043E\u0441\u0435\u0446", era: 1, cost: 70, str: 30, moves: 5, domain: "sea", tech: "steel", model: "ship.glb" },
  biplane: { name: "\u0411\u0438\u043F\u043B\u0430\u043D-\u0440\u0430\u0437\u0432\u0435\u0434\u0447\u0438\u043A", era: 1, cost: 50, str: 12, moves: 6, domain: "air", tech: "flight", model: "c172.glb" },
  fighter: { name: "\u0418\u0441\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B\u044C", era: 2, cost: 110, str: 50, moves: 10, domain: "air", tech: "jet", resource: "oil", model: "jet.glb" },
  drone: { name: "\u0423\u0434\u0430\u0440\u043D\u044B\u0439 \u0431\u0435\u0441\u043F\u0438\u043B\u043E\u0442\u043D\u0438\u043A", era: 2, cost: 100, str: 40, moves: 12, domain: "air", tech: "drones", resource: "silicon", model: "mq9.glb" },
  helicopter: { name: "\u0412\u0435\u0440\u0442\u043E\u043B\u0451\u0442", era: 2, cost: 90, str: 35, moves: 6, domain: "air", tech: "radio", model: "bell206.glb" },
  recon: { name: "\u0421\u0430\u043C\u043E\u043B\u0451\u0442-\u0440\u0430\u0437\u0432\u0435\u0434\u0447\u0438\u043A", era: 2, cost: 70, str: 0, moves: 14, domain: "air", tech: "computers", civilian: true, sight: 4, model: "citation2.glb" },
  icbm: { name: "\u0411\u0430\u043B\u043B\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0440\u0430\u043A\u0435\u0442\u0430", era: 2, cost: 200, str: 0, moves: 0, domain: "space", tech: "fission", resource: "rare", civilian: true, needs: "silo", model: null },
  satellite: { name: "\u0421\u043F\u0443\u0442\u043D\u0438\u043A", era: 3, cost: 150, str: 0, moves: 0, domain: "space", tech: "satellites", resource: "silicon", civilian: true, needs: "spaceport", model: null },
  interceptor: { name: "\u041F\u0435\u0440\u0435\u0445\u0432\u0430\u0442\u0447\u0438\u043A", era: 3, cost: 220, str: 0, moves: 0, domain: "space", tech: "kinetic", resource: "rare", civilian: true, needs: "spaceport", model: null }
});
var VETERAN_STEP = 0.1;
var VETERAN_MAX = 3;

// src/game/data/buildings.js
var BUILDINGS = Object.freeze({
  granary: { name: "\u0410\u043C\u0431\u0430\u0440", era: 0, cost: 30, food: 2, tech: "agriculture" },
  mine: { name: "\u0428\u0430\u0445\u0442\u0430", era: 0, cost: 35, prod: 2, tech: "bronze" },
  library: { name: "\u0411\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0430", era: 0, cost: 40, science: 3, tech: "writing" },
  barracks: { name: "\u041A\u0430\u0437\u0430\u0440\u043C\u044B", era: 0, cost: 30, veteran: true },
  port: { name: "\u041F\u043E\u0440\u0442", era: 0, cost: 40, gold: 2, food: 1, tech: "seafaring", coastal: true },
  walls: { name: "\u0421\u0442\u0435\u043D\u044B", era: 0, cost: 35, defense: 0.5, tech: "bronze" },
  factory: { name: "\u0417\u0430\u0432\u043E\u0434", era: 1, cost: 90, prodPct: 0.3, tech: "electricity" },
  university: { name: "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0438\u0442\u0435\u0442", era: 1, cost: 100, sciencePct: 0.3, tech: "steam" },
  airfield: { name: "\u0410\u044D\u0440\u043E\u0434\u0440\u043E\u043C", era: 1, cost: 70, tech: "flight" },
  research: { name: "\u0418\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0439 \u0446\u0435\u043D\u0442\u0440", era: 2, cost: 160, sciencePct: 0.4, tech: "computers" },
  datacenter: { name: "\u0421\u0435\u0440\u0432\u0435\u0440-\u043A\u043B\u0430\u0441\u0442\u0435\u0440", era: 2, cost: 150, gold: 6, science: 4, tech: "networks" },
  silo: { name: "\u0420\u0430\u043A\u0435\u0442\u043D\u0430\u044F \u0448\u0430\u0445\u0442\u0430", era: 2, cost: 120, tech: "fission" },
  spaceport: { name: "\u041A\u043E\u0441\u043C\u043E\u0434\u0440\u043E\u043C", era: 3, cost: 240, tech: "satellites", maxLat: 35 },
  observatory: { name: "\u041E\u0431\u0441\u0435\u0440\u0432\u0430\u0442\u043E\u0440\u0438\u044F \u0434\u0430\u043B\u044C\u043D\u0435\u0433\u043E \u043A\u043E\u0441\u043C\u043E\u0441\u0430", era: 3, cost: 200, science: 8, tech: "deepRadar" },
  ark: { name: "\u041A\u043E\u0432\u0447\u0435\u0433", era: 3, tech: "heavyLift", cost: 260, finale: "ark" }
});
function launchDiscount(lat) {
  return 0.3 * Math.max(0, 1 - Math.abs(lat) / 35);
}

// src/game/rules.js
var PROJECTS = Object.freeze({
  science: { name: "\u041D\u0430\u0443\u0447\u043D\u044B\u0439 \u043F\u0440\u043E\u0435\u043A\u0442", rate: 0.5 },
  gold: { name: "\u0422\u043E\u0440\u0433\u043E\u0432\u044B\u0439 \u043F\u0440\u043E\u0435\u043A\u0442", rate: 0.7 }
});
var isNeutralId = (id) => typeof id === "string" && id.startsWith("p");
var pairKey = (a, b) => a < b ? `${a}|${b}` : `${b}|${a}`;
function majorIds(state) {
  return Object.keys(state.nations);
}
function hasTech(state, nationId, tech) {
  return state.nations[nationId]?.techs.includes(tech) ?? false;
}
function techCost(state, nationId, tech) {
  const t = TECHS[tech];
  const known = majorIds(state).filter((id) => id !== nationId && state.nations[id].alive && hasTech(state, id, tech)).length;
  return Math.round(ERAS[t.era].cost * Math.max(0.5, 1 - CATCH_UP_DISCOUNT * known));
}
function availableTechs(state, nationId) {
  const n = state.nations[nationId];
  return Object.entries(TECHS).filter(([id, t]) => !n.techs.includes(id) && t.era <= n.era && t.req.every((r) => n.techs.includes(r))).map(([id]) => id);
}
function hasResource(state, nationId, resource) {
  const n = state.nations[nationId];
  if (!n || STRATEGIC[resource].era > n.era) return false;
  const owns = (id) => state.resourceCells[resource].some((cell) => state.owner[cell] === id);
  if (owns(nationId)) return true;
  return state.treaties.some((t) => t.type === "trade" && (t.a === nationId || t.b === nationId) && owns(t.a === nationId ? t.b : t.a));
}
function cellYield(state, map, cell, ownerId) {
  if ((state.fallout?.[cell] ?? 0) > state.turn) return { food: 0, prod: 0, gold: 0 };
  const code = map.terrain[cell];
  const t = TERRAIN[code];
  let food = t.food;
  let prod = t.prod;
  let gold = t.gold;
  if (map.coast[cell]) food += COAST_FOOD_BONUS;
  const res = state.resourceAt[cell];
  if (res && ownerId && !isNeutralId(ownerId) && STRATEGIC[res].era <= (state.nations[ownerId]?.era ?? 0)) {
    if (res === "silicon") gold += 1;
    else prod += 1;
  }
  const doctrine = state.nations[ownerId]?.doctrine;
  if (doctrine === "resilience" && code === "T") food += DOCTRINES.resilience.tundraFood;
  return { food, prod, gold };
}
function cityRadius(city) {
  return city.pop >= 5 ? 2 : 1;
}
function workedCells(state, map, city) {
  const options = cellsWithin(map, city.cell, cityRadius(city)).filter((c) => c !== city.cell && state.owner[c] === city.owner);
  const score = (c) => {
    const y = cellYield(state, map, c, city.owner);
    return y.food * 1.2 + y.prod + y.gold * 0.6;
  };
  options.sort((a, b) => score(b) - score(a) || a - b);
  return options.slice(0, city.pop);
}
function cityYield(state, map, city) {
  const centre = cellYield(state, map, city.cell, city.owner);
  let food = Math.max(3, centre.food);
  let prod = Math.max(1, centre.prod);
  let gold = centre.gold + 1;
  for (const c of workedCells(state, map, city)) {
    const y = cellYield(state, map, c, city.owner);
    food += y.food;
    prod += y.prod;
    gold += y.gold;
  }
  let science = city.pop * 0.5 + 1;
  let prodPct = 0;
  let sciencePct = 0;
  for (const b of city.buildings) {
    const def = BUILDINGS[b];
    food += def.food ?? 0;
    prod += def.prod ?? 0;
    gold += def.gold ?? 0;
    science += def.science ?? 0;
    prodPct += def.prodPct ?? 0;
    sciencePct += def.sciencePct ?? 0;
  }
  const nation = state.nations[city.owner];
  if (nation) {
    const d = DOCTRINES[nation.doctrine];
    sciencePct += d.sciencePct ?? 0;
    if (d.goldPct) gold *= 1 + d.goldPct;
    if (state.treaties.some((t) => t.type === "research" && (t.a === city.owner || t.b === city.owner))) sciencePct += 0.1;
  }
  gold += city.pop * 0.4;
  const mult = (isOccupied(state, city) ? OCCUPATION_YIELD : 1) * (1 - empirePenalty(state, city.owner));
  return {
    food: food * nuclearWinter(state),
    prod: prod * (1 + prodPct) * mult,
    gold: gold * mult,
    science: science * (1 + sciencePct) * mult,
    upkeep: city.pop * 2
  };
}
var OCCUPATION_TURNS = 8;
var OCCUPATION_YIELD = 0.5;
var EMPIRE_FREE_CITIES = 12;
var EMPIRE_PENALTY_PER_CITY = 0.028;
var EMPIRE_PENALTY_CAP = 0.45;
function nuclearWinter(state) {
  const strikes = state.nuclear?.strikes;
  if (!strikes?.length) return 1;
  const recent = strikes.filter((x) => !x.intercepted && state.turn - x.turn < 30).length;
  return Math.max(0.7, 1 - 0.05 * recent);
}
var isOccupied = (state, city) => (city.occupiedUntil ?? 0) > state.turn;
function empirePenalty(state, owner) {
  if (!own(state.nations, owner)) return 0;
  let n = 0;
  for (const c of Object.values(state.cities)) if (c.owner === owner) n += 1;
  return Math.min(EMPIRE_PENALTY_CAP, Math.max(0, n - EMPIRE_FREE_CITIES) * EMPIRE_PENALTY_PER_CITY);
}
var growthThreshold = (pop) => 10 + 5 * pop;
function itemCost(state, map, city, item) {
  if (item.kind === "dome" || item.kind === "project") return Infinity;
  const nation = state.nations[city.owner];
  if (item.kind === "unit") {
    let cost = UNITS[item.id].cost;
    if (item.id === "settler" && nation?.doctrine === "expansion") cost *= 0.75;
    if (UNITS[item.id].needs === "spaceport") {
      const doctrineDiscount = DOCTRINES[nation?.doctrine]?.spaceDiscount ?? 0;
      cost *= 1 - Math.max(launchDiscount(map.cells[city.cell].lat), doctrineDiscount);
    }
    return Math.round(cost);
  }
  return BUILDINGS[item.id].cost;
}
function itemBlocker(state, map, city, item) {
  const nationId = city.owner;
  if (item.kind === "project") return own(PROJECTS, item.id) ? null : "ITEM_UNAVAILABLE";
  if (item.kind === "dome") {
    if (!state.finale.detectedTurn) return "NO_FINALE";
    if (state.nations[nationId].finale.path !== "pact") return "NOT_IN_PACT";
    if (!hasTech(state, nationId, "heavyLift")) return "TECH_UNAVAILABLE";
    return null;
  }
  if (item.kind === "unit") {
    if (!own(UNITS, item.id)) return "ITEM_UNAVAILABLE";
    const u = UNITS[item.id];
    if (u.tech && !hasTech(state, nationId, u.tech)) return "TECH_UNAVAILABLE";
    if (u.resource && !hasResource(state, nationId, u.resource)) return "NEED_RESOURCE";
    if (u.needs && !city.buildings.includes(u.needs)) return u.needs === "silo" ? "NEED_SILO" : "NEED_SPACEPORT";
    if (u.domain === "sea" && !map.coast[city.cell]) return "ITEM_UNAVAILABLE";
    return null;
  }
  if (item.kind === "building") {
    if (!own(BUILDINGS, item.id)) return "ITEM_UNAVAILABLE";
    const b = BUILDINGS[item.id];
    if (city.buildings.includes(item.id)) return "ITEM_UNAVAILABLE";
    if (b.tech && !hasTech(state, nationId, b.tech)) return "TECH_UNAVAILABLE";
    if (b.coastal && !map.coast[city.cell]) return "ITEM_UNAVAILABLE";
    if (b.maxLat !== void 0 && Math.abs(map.cells[city.cell].lat) > b.maxLat) return "ITEM_UNAVAILABLE";
    if (b.finale === "ark" && (state.nations[nationId].finale.path !== "ark" || !city.capital)) return "ITEM_UNAVAILABLE";
    if (b.tech === void 0 && b.era > state.nations[nationId].era) return "TECH_UNAVAILABLE";
    return null;
  }
  return "ITEM_UNAVAILABLE";
}
function unitsAt(state, cell) {
  return state.unitsByCell[cell] ?? [];
}
function canEnter(state, map, unit, cell) {
  const def = UNITS[unit.type];
  const water = isWater(map.terrain[cell]);
  if (def.domain === "space") return false;
  if (def.domain === "air") return true;
  if (def.domain === "sea") {
    if (water) return true;
    const city = state.cityAt[cell];
    return Boolean(city && state.cities[city].owner === unit.owner);
  }
  if (water) {
    if (!hasTech(state, unit.owner, "seafaring")) return false;
    if (map.terrain[cell] === "O" && !hasTech(state, unit.owner, "steam")) return false;
    if (def.civilian && unit.type !== "settler") return false;
    return true;
  }
  return true;
}
var EMBARK_COST = 99;
function moveCost(map, cell, unit, from = unit.cell) {
  const def = UNITS[unit.type];
  if (def.domain !== "land") return 1;
  const toWater = isWater(map.terrain[cell]);
  const fromWater = isWater(map.terrain[from]);
  if (toWater !== fromWater) return EMBARK_COST;
  if (toWater) return 2;
  return TERRAIN[map.terrain[cell]].move;
}
var isEmbarked = (map, unit) => UNITS[unit.type].domain === "land" && isWater(map.terrain[unit.cell]);
var MinHeap = class _MinHeap {
  constructor() {
    this.items = [];
  }
  get size() {
    return this.items.length;
  }
  static less(x, y) {
    return x[0] < y[0] || x[0] === y[0] && x[1] < y[1];
  }
  push(item) {
    const a = this.items;
    a.push(item);
    let i = a.length - 1;
    while (i > 0) {
      const p = i - 1 >> 1;
      if (!_MinHeap.less(a[i], a[p])) break;
      [a[i], a[p]] = [a[p], a[i]];
      i = p;
    }
  }
  pop() {
    const a = this.items;
    const top = a[0];
    const last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (; ; ) {
        const l = 2 * i + 1;
        const r = l + 1;
        let m = i;
        if (l < a.length && _MinHeap.less(a[l], a[m])) m = l;
        if (r < a.length && _MinHeap.less(a[r], a[m])) m = r;
        if (m === i) break;
        [a[i], a[m]] = [a[m], a[i]];
        i = m;
      }
    }
    return top;
  }
};
function findPath(state, map, unit, target, { maxNodes = 3e3, allowEnemyAt = null } = {}) {
  if (unit.cell === target) return [];
  const embarkPathCost = Math.max(2, UNITS[unit.type].moves ?? 2) + 1;
  const dist3 = /* @__PURE__ */ new Map([[unit.cell, 0]]);
  const prev = /* @__PURE__ */ new Map();
  const open = new MinHeap();
  open.push([0, unit.cell]);
  let visited = 0;
  while (open.size && visited < maxNodes) {
    const [d, cell] = open.pop();
    if (d > dist3.get(cell)) continue;
    visited += 1;
    if (cell === target) break;
    for (const n of map.neighbors[cell]) {
      if (!canEnter(state, map, unit, n)) continue;
      if (n !== target && n !== allowEnemyAt && blockedFor(state, unit, n)) continue;
      const step = moveCost(map, n, unit, cell);
      const nd = d + (step === EMBARK_COST ? embarkPathCost : Math.min(4, step));
      if (nd < (dist3.get(n) ?? Infinity)) {
        dist3.set(n, nd);
        prev.set(n, cell);
        open.push([nd, n]);
      }
    }
  }
  if (!prev.has(target)) return null;
  const path2 = [];
  for (let c = target; c !== unit.cell; c = prev.get(c)) path2.push(c);
  return path2.reverse();
}
function blockedFor(state, unit, cell) {
  if (unitsAt(state, cell).some((id) => state.units[id].owner !== unit.owner)) return true;
  const city = state.cityAt[cell];
  return Boolean(city && state.cities[city].owner !== unit.owner);
}
function unitStrength(state, unit) {
  const def = UNITS[unit.type];
  const vet = 1 + VETERAN_STEP * (unit.vet ?? 0);
  const hp = Math.max(0.3, unit.hp / 100);
  return def.str * vet * hp;
}
function cityDefense(state, map, city) {
  let base = 6 + city.pop * 2;
  if (isNeutralId(city.owner)) base += Math.min(3, Math.floor(state.turn / 50)) * 9;
  else base += state.nations[city.owner].era * 6;
  let mult = 1 + (city.buildings.includes("walls") ? BUILDINGS.walls.defense : 0);
  if (state.nations[city.owner]?.doctrine === "resilience") mult += DOCTRINES.resilience.cityDefense;
  const g = unitsAt(state, city.cell).map((id) => state.units[id]).filter((u) => u.owner === city.owner && UNITS[u.type].str > 0).map((u) => unitStrength(state, u)).sort((x, y) => y - x);
  const garrison = g.length ? g[0] + 0.25 * g.slice(1).reduce((s, v) => s + v, 0) : 0;
  return (base + garrison) * mult * Math.max(0.35, city.hp / 100) * TERRAIN[map.terrain[city.cell]].defense;
}
function defenderStrength(state, map, unit) {
  const def = UNITS[unit.type];
  if (def.str === 0) return 0.5;
  let s = unitStrength(state, unit) * TERRAIN[map.terrain[unit.cell]].defense;
  if (unit.fortified) s *= 1.25;
  if (def.domain === "land" && isWater(map.terrain[unit.cell])) s *= 0.5;
  return s;
}
function attackOdds(state, map, attacker, cell) {
  const a = unitStrength(state, attacker);
  if (a <= 0) return 0;
  const cityId = state.cityAt[cell];
  let d;
  if (cityId && state.cities[cityId].owner !== attacker.owner) d = cityDefense(state, map, state.cities[cityId]);
  else {
    const defenders = unitsAt(state, cell).map((id) => state.units[id]).filter((u) => u.owner !== attacker.owner);
    if (!defenders.length) return 1;
    const strengths = defenders.map((u) => defenderStrength(state, map, u)).sort((x, y) => y - x);
    d = strengths[0] + 0.25 * strengths.slice(1).reduce((s, v) => s + v, 0);
  }
  return a / (a + d);
}
function visionSources(state, nationId) {
  const sources = [];
  for (const c of Object.values(state.cities)) if (c.owner === nationId) sources.push([c.cell, 2]);
  for (const u of Object.values(state.units)) if (u.owner === nationId && UNITS[u.type].domain !== "space") sources.push([u.cell, UNITS[u.type].sight ?? (UNITS[u.type].domain === "air" ? 3 : 2)]);
  return sources;
}
function visibleCells(state, map, nationId) {
  const allies = [nationId, ...state.treaties.filter((t) => t.type === "alliance" && (t.a === nationId || t.b === nationId)).map((t) => t.a === nationId ? t.b : t.a)];
  const set = /* @__PURE__ */ new Set();
  for (const id of allies) for (const [cell, r] of visionSources(state, id)) for (const c of cellsWithin(map, cell, r)) set.add(c);
  for (const z of state.recon?.[nationId] ?? []) if (z.until > state.turn) for (const c of cellsWithin(map, z.cell, 3)) set.add(c);
  return set;
}
function relation(state, a, b) {
  if (isNeutralId(b)) return state.neutrals[b].relations[a] ?? 0;
  if (isNeutralId(a)) return state.neutrals[a].relations[b] ?? 0;
  return state.relations[pairKey(a, b)] ?? 0;
}
function atWar(state, a, b) {
  return state.wars.includes(pairKey(a, b));
}
function treatyBetween(state, a, b, type) {
  return state.treaties.find((t) => t.type === type && (t.a === a && t.b === b || t.a === b && t.b === a));
}
function militaryPower(state, nationId) {
  return Object.values(state.units).filter((u) => u.owner === nationId).reduce((s, u) => s + unitStrength(state, u), 0);
}

// src/game/data/leaders.js
var TRAITS = Object.freeze({
  pride: "\u0413\u043E\u0440\u0434\u043E\u0441\u0442\u044C",
  // не терпит требований и угроз
  greed: "\u0416\u0430\u0434\u043D\u043E\u0441\u0442\u044C",
  // ценит золото и выгоду выше отношений
  honor: "\u0427\u0435\u0441\u0442\u044C",
  // держит слово, не прощает обмана
  cunning: "\u0425\u0438\u0442\u0440\u043E\u0441\u0442\u044C",
  // любит интриги, лучше их раскрывает
  caution: "\u041E\u0441\u0442\u043E\u0440\u043E\u0436\u043D\u043E\u0441\u0442\u044C",
  // боится сильных, уступает угрозам
  memory: "\u0417\u043B\u043E\u043F\u0430\u043C\u044F\u0442\u043D\u043E\u0441\u0442\u044C"
  // как медленно забываются обиды
});
var LEADERS = Object.freeze({
  borea: {
    id: "borea-ingvar",
    name: "\u0418\u043D\u0433\u0432\u0430\u0440 \u0425\u043E\u043B\u044C\u043C\u0441\u0442\u0430\u0434",
    title: "\u0425\u0440\u0430\u043D\u0438\u0442\u0435\u043B\u044C \u0421\u0435\u0432\u0435\u0440\u0430",
    portrait: "borea.png",
    // + borea-<настроение>.png
    bio: "\u0411\u044B\u0432\u0448\u0438\u0439 \u043D\u0430\u0447\u0430\u043B\u044C\u043D\u0438\u043A \u043F\u043E\u043B\u044F\u0440\u043D\u043E\u0439 \u044D\u043A\u0441\u043F\u0435\u0434\u0438\u0446\u0438\u0438. \u0413\u043E\u0432\u043E\u0440\u0438\u0442 \u043C\u0430\u043B\u043E, \u0434\u0435\u0440\u0436\u0438\u0442 \u0441\u043B\u043E\u0432\u043E, \u043E\u0431\u0438\u0434 \u043D\u0435 \u0437\u0430\u0431\u044B\u0432\u0430\u0435\u0442.",
    traits: { pride: 0.6, greed: 0.2, honor: 0.95, cunning: 0.3, caution: 0.7, memory: 0.9 }
  },
  cartel: {
    id: "cartel-sabina",
    name: "\u0421\u0430\u0431\u0438\u043D\u0430 \u041E\u0440\u0442\u0435\u043B\u043B\u0438",
    title: "\u041F\u0440\u0435\u0434\u0441\u0435\u0434\u0430\u0442\u0435\u043B\u044C \u041A\u0430\u0440\u0442\u0435\u043B\u044F",
    portrait: "cartel.png",
    bio: "\u0411\u0430\u043D\u043A\u0438\u0440, \u043A\u0443\u043F\u0438\u0432\u0448\u0430\u044F \u043F\u043E\u043B\u043E\u0432\u0438\u043D\u0443 \u043F\u043E\u0431\u0435\u0440\u0435\u0436\u044C\u044F. \u041B\u044E\u0431\u0443\u044E \u0434\u0440\u0443\u0436\u0431\u0443 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442 \u0432 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u044B.",
    traits: { pride: 0.4, greed: 0.95, honor: 0.25, cunning: 0.85, caution: 0.5, memory: 0.4 }
  },
  meridian: {
    id: "meridian-tael",
    name: "\u0422\u0430\u044D\u043B\u044C \u041D\u043E\u044D\u0440\u0438\u0441",
    title: "\u041F\u0435\u0440\u0432\u0430\u044F \u043F\u043E\u0441\u0440\u0435\u0434\u043D\u0438\u0446\u0430 \u041B\u0438\u0433\u0438",
    portrait: "meridian.png",
    bio: "\u0414\u0438\u043F\u043B\u043E\u043C\u0430\u0442, \u043F\u0440\u0438\u043C\u0438\u0440\u0438\u0432\u0448\u0430\u044F \u0433\u043E\u0440\u043D\u044B\u0435 \u043A\u043B\u0430\u043D\u044B. \u041F\u0440\u0435\u0434\u043F\u043E\u0447\u0438\u0442\u0430\u0435\u0442 \u0434\u043E\u0433\u043E\u0432\u043E\u0440 \u0432\u043E\u0439\u043D\u0435, \u0430 \u043A\u043E\u0430\u043B\u0438\u0446\u0438\u044E \u043E\u0434\u0438\u043D\u043E\u0447\u043A\u0435.",
    traits: { pride: 0.3, greed: 0.35, honor: 0.8, cunning: 0.5, caution: 0.6, memory: 0.6 }
  },
  auris: {
    id: "auris-ilan",
    name: "\u0418\u043B\u0430\u043D \u0421\u043E\u0440\u0435\u0439\u043E",
    title: "\u041A\u0430\u043D\u0446\u043B\u0435\u0440 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0438",
    portrait: "auris.png",
    bio: "\u0410\u0441\u0442\u0440\u043E\u0444\u0438\u0437\u0438\u043A \u0432\u043E \u0433\u043B\u0430\u0432\u0435 \u0433\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0430. \u0420\u0430\u0434\u0438 \u0440\u0430\u043A\u0435\u0442\u044B \u043D\u0430 \u043E\u0440\u0431\u0438\u0442\u0435 \u0433\u043E\u0442\u043E\u0432 \u043D\u0430 \u043C\u043D\u043E\u0433\u043E\u0435.",
    traits: { pride: 0.75, greed: 0.4, honor: 0.5, cunning: 0.65, caution: 0.35, memory: 0.5 }
  }
});
function customLeader(name = "\u041B\u0438\u0434\u0435\u0440") {
  return {
    id: "player-leader",
    name,
    title: "\u0413\u043B\u0430\u0432\u0430 \u043D\u0430\u0446\u0438\u0438",
    portrait: "custom.png",
    bio: "\u0412\u0430\u0448 \u043B\u0438\u0434\u0435\u0440.",
    traits: { pride: 0.5, greed: 0.5, honor: 0.5, cunning: 0.5, caution: 0.5, memory: 0.5 }
  };
}

// src/game/leaders.js
var MOODS = Object.freeze([
  { min: -Infinity, id: "hostile", name: "\u0432\u0440\u0430\u0436\u0434\u0435\u0431\u043D\u043E\u0441\u0442\u044C" },
  { min: -40, id: "cold", name: "\u0445\u043E\u043B\u043E\u0434\u043D\u043E\u0441\u0442\u044C" },
  { min: -10, id: "neutral", name: "\u0441\u0434\u0435\u0440\u0436\u0430\u043D\u043D\u043E\u0441\u0442\u044C" },
  { min: 15, id: "warm", name: "\u0434\u0440\u0443\u0436\u0435\u043B\u044E\u0431\u0438\u0435" },
  { min: 45, id: "friend", name: "\u0431\u043B\u0438\u0437\u043A\u0438\u0439 \u0441\u043E\u044E\u0437\u043D\u0438\u043A" }
]);
var key = (judge, other) => `${judge}>${other}`;
function credibility(state, id) {
  const n = state.nations[id];
  return Math.max(0.2, 1 - 0.25 * (n?.bluffsCalled ?? 0));
}
function makeLeader(nationId, custom = null) {
  if (custom) return customLeader(custom.leaderName || `\u0413\u043B\u0430\u0432\u0430 ${custom.name}`);
  return structuredClone(LEADERS[nationId]);
}
function traits(state, id) {
  return state.nations[id]?.leader?.traits ?? customLeader().traits;
}
function aggressionOf(state, id) {
  const n = state.nations[id];
  const t = traits(state, id);
  return Math.max(0, Math.min(1, (n.ai?.aggression ?? 0.4) + (t.pride - 0.5) * 0.3 - (t.caution - 0.5) * 0.3));
}
function entry(state, judge, other) {
  state.memory ??= {};
  return state.memory[key(judge, other)] ??= { grievance: 0, favor: 0, log: [] };
}
function remember(state, judge, other, kind, amount, reason) {
  if (!state.nations[judge] || !state.nations[other] || judge === other) return;
  const e = entry(state, judge, other);
  e[kind] = Math.min(200, e[kind] + amount);
  e.log.push({ turn: state.turn, kind, amount: Math.round(amount), reason });
  if (e.log.length > 12) e.log.shift();
}
function memoryOf(state, judge, other) {
  return state.memory?.[key(judge, other)] ?? { grievance: 0, favor: 0, log: [] };
}
function attitude(state, judge, other) {
  const base = relation(state, judge, other);
  if (isNeutralId(judge) || isNeutralId(other) || !state.nations[judge]) return base;
  const m = memoryOf(state, judge, other);
  const t = traits(state, judge);
  const rep = ((state.nations[other]?.reputation ?? 50) - 50) * (0.25 + 0.25 * t.honor);
  return base + rep + m.favor * 0.4 - m.grievance * (0.4 + 0.4 * t.memory);
}
function moodOf(value) {
  let mood = MOODS[0];
  for (const m of MOODS) if (value >= m.min) mood = m;
  return mood;
}
function memoryTick(state) {
  for (const [k, e] of Object.entries(state.memory ?? {})) {
    const judge = k.split(">")[0];
    const t = traits(state, judge);
    e.grievance *= 1 - 0.03 * (1 - t.memory);
    e.favor *= 0.98;
    if (e.grievance < 0.5) e.grievance = 0;
    if (e.favor < 0.5) e.favor = 0;
  }
}
function hash(...parts) {
  let h = 2166136261;
  for (const ch of parts.join("|")) h = Math.imul(h ^ ch.codePointAt(0), 16777619);
  return h >>> 0;
}
var SITUATION_WEIGHTS = Object.freeze({
  greet: {},
  acceptDeal: { greed: 1.3, honor: 1.1 },
  rejectDeal: { pride: 1.2, greed: 1.1 },
  counter: { greed: 1.4, cunning: 1.2 },
  demandMade: { pride: 1.3, cunning: 1.1 },
  demandAccept: { caution: 1.5, cunning: 1.1 },
  demandRefuse: { pride: 1.4, honor: 1.2 },
  plotExposed: { honor: 1.3, pride: 1.2 }
});
function dominantTone(t, situation = "greet") {
  const w = SITUATION_WEIGHTS[situation] ?? {};
  const k = (name) => t[name] * (w[name] ?? 1);
  const options = [["pride", k("pride")], ["greed", k("greed")], ["honor", k("honor")], ["cunning", k("cunning")], ["caution", k("caution")]];
  options.sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  return options[0][0];
}
function say(state, speaker, situation, params = {}) {
  const n = state.nations[speaker];
  if (!n?.leader) return null;
  const lines = LEADER_LINES[situation];
  if (!lines) return null;
  const tone = dominantTone(n.leader.traits, situation);
  const pool = lines[tone] ?? lines.any;
  const text = pool[hash(speaker, situation, state.turn, params.target ?? "") % pool.length];
  return {
    speaker,
    leader: n.leader.name,
    portrait: n.leader.portrait,
    situation,
    text: text.replace(/\{(\w+)\}/g, (_, k) => params[k] ?? "")
  };
}

// src/game/diplomacy.js
var TREATY_RULES = Object.freeze({
  nap: { minRelation: 0, duration: 20, influence: 5, breakReputation: 30 },
  trade: { minRelation: -20, duration: null, influence: 5, breakReputation: 10 },
  research: { minRelation: 20, duration: 30, influence: 10, breakReputation: 10 },
  alliance: { minRelation: 40, duration: null, influence: 15, breakReputation: 40 }
});
var TRUCE_TURNS = 10;
var TREATY_CEILING = 50;
var PEACE_MIN_WAR_TURNS = 5;
var clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function changeRelation(state, a, b, delta) {
  if (isNeutralId(b)) {
    const p = state.neutrals[b];
    p.relations[a] = clamp((p.relations[a] ?? 0) + delta, -100, 100);
    return;
  }
  if (isNeutralId(a)) {
    changeRelation(state, b, a, delta);
    return;
  }
  const key2 = pairKey(a, b);
  state.relations[key2] = clamp((state.relations[key2] ?? 0) + delta, -100, 100);
}
function changeReputation(state, id, delta) {
  const n = state.nations[id];
  n.reputation = clamp(n.reputation + delta, 0, 100);
}
function treatyInfluenceCost(state, nationId, type) {
  const discount = DOCTRINES[state.nations[nationId].doctrine].treatyDiscount ?? 0;
  return Math.round(TREATY_RULES[type].influence * (1 - discount));
}
function evaluateTreaty(state, judge, from, type) {
  const rule = TREATY_RULES[type];
  const j = state.nations[judge];
  const f = state.nations[from];
  if (atWar(state, judge, from)) return { accept: false, score: -Infinity };
  const rel = attitude(state, judge, from);
  let score = rel;
  const coop = j.ai?.coop ?? 0.6;
  score += (coop - 0.5) * 30;
  if (type === "alliance") {
    const commonEnemy = Object.keys(state.nations).some((x) => x !== judge && x !== from && atWar(state, judge, x) && atWar(state, from, x));
    if (commonEnemy) score += 20;
    const ratio = (militaryPower(state, from) + 1) / (militaryPower(state, judge) + 1);
    if (ratio < 0.4) score -= 15;
  }
  if (type === "research" && f.techs.length + 4 < j.techs.length) score -= 40;
  const t = j.leader?.traits;
  if (t) {
    score += (t.honor - 0.5) * (f.reputation - 50) * 0.4;
    if (type === "alliance") score -= (t.caution - 0.5) * 30;
    if (type === "trade") score += (t.greed - 0.5) * 20;
  }
  return { accept: score >= rule.minRelation, score };
}
function addTreaty(state, a, b, type) {
  const rule = TREATY_RULES[type];
  state.treaties.push({ type, a, b, since: state.turn, until: rule.duration ? state.turn + rule.duration : null });
  state.treaties.sort((x, y) => (x.type + x.a + x.b).localeCompare(y.type + y.a + y.b));
  changeRelation(state, a, b, 5);
  pushEvent(state, "treaty", { a: nameOf(state, a), b: nameOf(state, b), treaty: TREATY_NAMES[type] });
}
function removeTreaty(state, a, b, type, { broken = false, by = a } = {}) {
  const t = treatyBetween(state, a, b, type);
  if (!t) return false;
  state.treaties = state.treaties.filter((x) => x !== t);
  if (broken) {
    remember(state, by === a ? b : a, by, "grievance", TREATY_RULES[type].breakReputation, "treatyBroken");
    changeReputation(state, by, -TREATY_RULES[type].breakReputation);
    changeRelation(state, a, b, type === "alliance" ? -80 : -30);
    pushEvent(state, "treatyBroken", { a: nameOf(state, by), b: nameOf(state, by === a ? b : a), treaty: TREATY_NAMES[type] });
  }
  return true;
}
function declareWar(state, aggressor, target) {
  const key2 = pairKey(aggressor, target);
  if (state.wars.includes(key2)) return { ok: false, error: "ALREADY_AT_WAR" };
  if (!isNeutralId(target) && (state.truces[key2] ?? 0) > state.turn) return { ok: false, error: "TRUCE" };
  if (!isNeutralId(target)) {
    const justified = (state.casusBelli?.[`${aggressor}>${target}`] ?? 0) >= state.turn;
    for (const type of ["nap", "alliance", "research", "trade"]) {
      if (treatyBetween(state, aggressor, target, type)) removeTreaty(state, aggressor, target, type, { broken: !justified && (type === "nap" || type === "alliance"), by: aggressor });
    }
    changeRelation(state, aggressor, target, -60);
    remember(state, target, aggressor, "grievance", justified ? 20 : 50, "war");
    for (const other of Object.keys(state.nations)) {
      if (other === aggressor || other === target || justified) continue;
      changeRelation(state, other, aggressor, treatyBetween(state, other, target, "alliance") ? -30 : -10);
    }
  } else {
    if (treatyBetween(state, aggressor, target, "trade")) removeTreaty(state, aggressor, target, "trade");
    changeRelation(state, aggressor, target, -60);
    changeReputation(state, aggressor, -5);
  }
  state.wars.push(key2);
  state.wars.sort();
  state.warSince[key2] = state.turn;
  pushEvent(state, "war", { a: nameOf(state, aggressor), b: nameOf(state, target) });
  return { ok: true };
}
function makePeace(state, a, b) {
  const key2 = pairKey(a, b);
  state.wars = state.wars.filter((k) => k !== key2);
  delete state.warSince[key2];
  state.truces[key2] = state.turn + TRUCE_TURNS;
  changeRelation(state, a, b, 15);
  pushEvent(state, "peace", { a: nameOf(state, a), b: nameOf(state, b) });
}
function evaluatePeace(state, judge, from) {
  const key2 = pairKey(judge, from);
  const turns = state.turn - (state.warSince[key2] ?? state.turn);
  if (turns < PEACE_MIN_WAR_TURNS) return false;
  if (isNeutralId(judge)) return true;
  const mine = militaryPower(state, judge) + 1;
  const theirs = militaryPower(state, from) + 1;
  return mine < theirs * 1.2 || relation(state, judge, from) > -50 || turns > 25;
}
function diplomacyTick(state, map) {
  const ids = Object.keys(state.nations).filter((id) => state.nations[id].alive);
  const borders = /* @__PURE__ */ new Set();
  for (let cell = 0; cell < map.size; cell += 1) {
    const o = state.owner[cell];
    if (!o || isNeutralId(o)) continue;
    for (const n of map.neighbors[cell]) {
      const p = state.owner[n];
      if (p && p !== o && !isNeutralId(p)) borders.add(pairKey(o, p));
    }
  }
  for (let i = 0; i < ids.length; i += 1) for (let j = i + 1; j < ids.length; j += 1) {
    const a = ids[i];
    const b = ids[j];
    const key2 = pairKey(a, b);
    const rel = state.relations[key2] ?? 0;
    let delta = -rel * 0.01;
    if (borders.has(key2)) delta -= 0.3;
    if (atWar(state, a, b)) delta -= 1;
    let bonus = 0;
    if (treatyBetween(state, a, b, "trade")) bonus += 0.5;
    if (treatyBetween(state, a, b, "research")) bonus += 0.5;
    if (treatyBetween(state, a, b, "alliance")) bonus += 1;
    if (state.nations[a].finale.path === "pact" && state.nations[b].finale.path === "pact") bonus += 1;
    delta += bonus * Math.max(0, (TREATY_CEILING - rel) / TREATY_CEILING);
    changeRelation(state, a, b, delta);
  }
  for (const id of ids) {
    const n = state.nations[id];
    n.reputation += (70 - n.reputation) * 0.01;
  }
  for (const p of Object.values(state.neutrals)) {
    for (const id of ids) {
      const v = p.relations[id] ?? 0;
      p.relations[id] = clamp(v - v * 0.02 + (atWar(state, p.id, id) ? -2 : 0), -100, 100);
    }
  }
  const expired = state.treaties.filter((t) => t.until !== null && t.until <= state.turn);
  for (const t of expired) removeTreaty(state, t.a, t.b, t.type);
  state.offers = state.offers.filter((o) => o.turn >= state.turn - 3);
}

// src/game/intrigue.js
var OPS = Object.freeze({
  stealTech: { name: "\u041A\u0440\u0430\u0436\u0430 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438", influence: 25, gold: 40, base: 0.45, exposure: 0.35 },
  sabotage: { name: "\u0421\u0430\u0431\u043E\u0442\u0430\u0436", influence: 20, gold: 30, base: 0.55, exposure: 0.3 },
  incite: { name: "\u041F\u043E\u0434\u0441\u0442\u0440\u0435\u043A\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043D\u0430\u0440\u043E\u0434\u0430", influence: 15, gold: 40, base: 0.6, exposure: 0.25 },
  falseFlag: { name: "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u043F\u043E\u0434 \u0447\u0443\u0436\u0438\u043C \u0444\u043B\u0430\u0433\u043E\u043C", influence: 35, gold: 50, base: 0.4, exposure: 0.4 },
  smear: { name: "\u041A\u0430\u043C\u043F\u0430\u043D\u0438\u044F \u043E\u0447\u0435\u0440\u043D\u0435\u043D\u0438\u044F", influence: 15, gold: 20, base: 0.6, exposure: 0.3 }
});
var CASUS_BELLI_TURNS = 15;
var EXPOSED_REPUTATION = 15;
var OP_COOLDOWN = 3;
var SABOTAGE_IMMUNITY = 10;
function counterIntel(state, target) {
  let level = traits(state, target).cunning * 0.15;
  const cities = Object.values(state.cities).filter((c) => c.owner === target);
  const datacenters = cities.filter((c) => c.buildings.includes("datacenter")).length;
  const research = cities.filter((c) => c.buildings.includes("research")).length;
  level += Math.min(0.2, datacenters * 0.04) + Math.min(0.1, research * 0.02);
  return level;
}
function opChances(state, actor, target, op) {
  const def = OPS[op];
  const skill = traits(state, actor).cunning * 0.2 + (state.nations[actor].era - state.nations[target].era) * 0.05;
  const defense = counterIntel(state, target);
  const success = Math.max(0.05, Math.min(0.9, def.base + skill - defense));
  const exposure = Math.max(0.05, Math.min(0.9, def.exposure + defense - skill * 0.5));
  return { success, exposure };
}
function hasCasusBelli(state, victim, culprit) {
  return (state.casusBelli?.[`${victim}>${culprit}`] ?? 0) >= state.turn;
}
function opBlocker(state, actor, op, target, third) {
  const a = state.nations[actor];
  if (!own(OPS, op)) return "BAD_COMMAND";
  const def = OPS[op];
  if (!own(state.nations, target) || target === actor || !state.nations[target].alive) return "UNKNOWN_NATION";
  if (!a.met.includes(target)) return "NOT_MET";
  if (a.influence < def.influence) return "NOT_ENOUGH_INFLUENCE";
  if (a.gold < def.gold) return "NOT_ENOUGH_GOLD";
  if ((a.lastOpTurn ?? -99) + OP_COOLDOWN > state.turn) return "AGENTS_BUSY";
  if (op === "falseFlag" && (!own(state.nations, third) || third === actor || third === target || !a.met.includes(third))) return "UNKNOWN_NATION";
  if (op === "incite") {
    const people = own(state.neutrals, third) ? state.neutrals[third] : null;
    if (!people?.alive) return "UNKNOWN_NATION";
  }
  if (op === "stealTech" && !stealable(state, actor, target).length) return "NOTHING_TO_STEAL";
  if (op === "sabotage" && !sabotageTarget(state, null, target)) return "NO_TARGET";
  return null;
}
function stealable(state, actor, target) {
  const a = state.nations[actor];
  return state.nations[target].techs.filter((t) => techLearnable(a, t)).sort();
}
function sabotageTarget(state, map, target) {
  const cities = Object.values(state.cities).filter((c) => c.owner === target && (c.sabotagedAt ?? -99) + SABOTAGE_IMMUNITY <= state.turn).sort((x, y) => x.id.localeCompare(y.id));
  if (!map) return cities[0] ?? null;
  const port2 = cities.find((c) => c.buildings.includes("spaceport"));
  if (port2) return port2;
  return cities.sort((x, y) => cityYield(state, map, y).prod - cityYield(state, map, x).prod || x.id.localeCompare(y.id))[0] ?? null;
}
function runOperation(state, map, actor, op, target, third = null) {
  const blocker = opBlocker(state, actor, op, target, third);
  if (blocker) return { ok: false, error: blocker };
  const a = state.nations[actor];
  const def = OPS[op];
  a.influence -= def.influence;
  a.gold -= def.gold;
  a.lastOpTurn = state.turn;
  const chances = opChances(state, actor, target, op);
  const success = nextRandom(state) < chances.success;
  const exposed = nextRandom(state) < (success ? chances.exposure : Math.min(0.95, chances.exposure + 0.3));
  let effect = null;
  if (success) {
    if (op === "stealTech") {
      const options = stealable(state, actor, target);
      const tech = options[Math.floor(nextRandom(state) * options.length)];
      grantTech(state, a, tech);
      effect = { tech };
    } else if (op === "sabotage") {
      const city = sabotageTarget(state, map, target);
      if (city) {
        effect = { city: city.id, lost: Math.round(city.prod) };
        city.prod = 0;
        city.hp = Math.max(20, city.hp - 30);
        city.sabotagedAt = state.turn;
      }
    } else if (op === "incite") {
      const people = state.neutrals[third];
      people.relations[target] = Math.max(-100, (people.relations[target] ?? 0) - 35);
      people.relations[actor] = Math.min(100, (people.relations[actor] ?? 0) + 10);
      if (treatyBetween(state, target, third, "trade") && people.relations[target] < 0) removeTreaty(state, target, third, "trade");
      effect = { people: third };
    } else if (op === "falseFlag") {
      changeRelation(state, target, third, -30);
      remember(state, target, third, "grievance", 30, "falseFlag");
      effect = { blamed: third };
    } else if (op === "smear") {
      changeReputation(state, target, -10);
      effect = { reputation: -10 };
    }
  }
  if (exposed) {
    changeReputation(state, actor, -EXPOSED_REPUTATION);
    changeRelation(state, actor, target, -30);
    remember(state, target, actor, "grievance", 25 + 30 * traits(state, target).honor, "plot");
    state.casusBelli ??= {};
    state.casusBelli[`${target}>${actor}`] = state.turn + CASUS_BELLI_TURNS;
    if (op === "falseFlag") {
      changeRelation(state, target, third, 30);
      remember(state, third, actor, "grievance", 30, "framed");
      state.casusBelli[`${third}>${actor}`] = state.turn + CASUS_BELLI_TURNS;
    }
    pushEvent(state, "plotExposed", { actor: nameOf(state, actor), target: nameOf(state, target), op: def.name });
  } else if (success) {
    pushEvent(state, "plotHidden", { target: nameOf(state, target), op: def.name }, [target]);
  }
  pushEvent(state, success ? "plotSuccess" : "plotFailed", { op: def.name, target: nameOf(state, target) }, [actor]);
  return {
    ok: true,
    success,
    exposed,
    effect,
    reply: exposed ? say(state, target, "plotExposed", { target: nameOf(state, actor) }) : null
  };
}

// src/game/finale.js
var DETECTION_FORCED_TURN = 200;
var IMPACT_DELAY = 25;
var PATH_LOCK = 15;
var SATELLITES_FOR_TRACKING = 3;
var SHIELD_TARGET = 4e4;
var RARE_POINTS_PER_TILE = 3;
var INTERCEPTOR_POWER = 0.045;
var INTERCEPTOR_CAP = 0.5;
var SHIELD_CAP = 0.7;
var GOLD_RATE = 0.13;
function maybeDetect(state, map) {
  const f = state.finale;
  if (f.detectedTurn) return false;
  const finder = majorIds(state).find((id) => state.nations[id].alive && hasTech(state, id, "deepRadar"));
  if (!finder && state.turn < DETECTION_FORCED_TURN) return false;
  f.detectedTurn = state.turn;
  f.impactTurn = state.turn + IMPACT_DELAY;
  f.detectedBy = finder ?? null;
  const owned = [];
  for (let cell = 0; cell < map.size; cell += 1) if (state.owner[cell] && !state.owner[cell].startsWith("p") && !isWater(map.terrain[cell])) owned.push(cell);
  f.impactCell = owned.length ? owned[Math.floor(nextRandom(state) * owned.length)] : 0;
  f.uncertaintyKm = 3e3;
  pushEvent(state, "asteroid", { turns: IMPACT_DELAY });
  return true;
}
function canJoinPact(state) {
  const f = state.finale;
  return Boolean(f.detectedTurn) && state.turn <= f.detectedTurn + PATH_LOCK;
}
function choosePath(state, nationId, path2) {
  const f = state.finale;
  const n = state.nations[nationId];
  if (!f.detectedTurn) return { ok: false, error: "NO_FINALE" };
  if (path2 !== "pact" && path2 !== "ark") return { ok: false, error: "BAD_PATH" };
  if (n.finale.path === path2) return { ok: true };
  if (path2 === "pact") {
    if (!canJoinPact(state)) return { ok: false, error: "PATH_LOCKED" };
    n.finale.path = "pact";
    n.finale.joinedAt = state.turn;
    pushEvent(state, "pactJoined", { nation: n.name });
    return { ok: true };
  }
  if (n.finale.path === "pact") {
    n.finale.leftAt = state.turn;
    if (state.turn > f.detectedTurn + PATH_LOCK) {
      n.finale.betrayed = true;
      changeReputation(state, nationId, -50);
    }
    pushEvent(state, "pactLeft", { nation: n.name });
  } else {
    pushEvent(state, "arkChosen", { nation: n.name });
  }
  n.finale.path = "ark";
  return { ok: true };
}
function contribute(state, nationId, { gold = 0, science = 0 } = {}) {
  const n = state.nations[nationId];
  if (!state.finale.detectedTurn) return { ok: false, error: "NO_FINALE" };
  if (n.finale.path !== "pact") return { ok: false, error: "NOT_IN_PACT" };
  const num = (v) => typeof v === "number" && Number.isFinite(v) ? v : 0;
  gold = Math.max(0, Math.floor(num(gold)));
  science = Math.max(0, Math.floor(num(science)));
  if (gold > n.gold) return { ok: false, error: "NOT_ENOUGH_GOLD" };
  if (science > n.sciencePool) return { ok: false, error: "NOT_ENOUGH_SCIENCE" };
  n.gold -= gold;
  n.sciencePool -= science;
  if (gold) addShield(state, nationId, gold * GOLD_RATE, "gold");
  if (science) addShield(state, nationId, science, "science");
  return { ok: true };
}
function addShield(state, nationId, points, source = "production") {
  state.finale.shield += points;
  addContribution(state, nationId, points, source);
}
function addContribution(state, nationId, points, source) {
  const f = state.nations[nationId].finale;
  f.contribution += points;
  f.sources ??= {};
  f.sources[source] = (f.sources[source] ?? 0) + points;
}
function pactMembers(state) {
  return majorIds(state).filter((id) => state.nations[id].alive && state.nations[id].finale.path === "pact");
}
function finaleTick(state) {
  const f = state.finale;
  if (!f.detectedTurn || f.result) return;
  const members = pactMembers(state);
  for (const id of members) {
    const tiles = state.resourceCells.rare.filter((c) => state.owner[c] === id).length;
    if (tiles) addShield(state, id, tiles * RARE_POINTS_PER_TILE, "rare");
  }
  const sats = Object.values(state.units).filter((u) => u.type === "satellite" && members.includes(u.owner)).length;
  const observatory = Object.values(state.cities).some((c) => members.includes(c.owner) && c.buildings.includes("observatory"));
  if (!f.tracking && sats >= SATELLITES_FOR_TRACKING && observatory) {
    f.tracking = true;
    pushEvent(state, "tracking");
  }
  f.uncertaintyKm = Math.max(150, f.uncertaintyKm - (f.tracking ? 250 : 80));
}
var UNTRACKED_FACTOR = 0.84;
function partialLoss(defense) {
  return Math.max(0.05, Math.min(0.5, 1 - defense));
}
function defenseLevel(state) {
  const f = state.finale;
  const members = pactMembers(state);
  const interceptors = Object.values(state.units).filter((u) => u.type === "interceptor" && members.includes(u.owner)).length;
  const tracking = f.tracking ? 1.2 : UNTRACKED_FACTOR;
  const intercept = Math.min(INTERCEPTOR_CAP, interceptors * INTERCEPTOR_POWER);
  const shield = Math.min(SHIELD_CAP, f.shield / SHIELD_TARGET * SHIELD_CAP);
  return { defense: tracking * (intercept + shield), tracking, intercept, shield, interceptors };
}
function outcomeFor(defense) {
  if (defense >= 1) return "saved";
  if (defense >= 0.5) return "partial";
  return "fail";
}
function resolveImpact(state, map) {
  const f = state.finale;
  if (!f.detectedTurn || f.result || state.turn < f.impactTurn) return null;
  const level = defenseLevel(state);
  const outcome = outcomeFor(level.defense);
  const members = pactMembers(state);
  const contributions = Object.fromEntries(majorIds(state).map((id) => [id, Math.round(state.nations[id].finale.contribution)]));
  let winner = null;
  if (outcome !== "fail" && members.length) {
    winner = [...members].sort((a, b) => contributions[b] - contributions[a] || a.localeCompare(b))[0];
  }
  if (outcome === "partial" || outcome === "fail") {
    const radius = outcome === "partial" ? 2 : 6;
    for (const cell of cellsWithin(map, f.impactCell, radius)) {
      const id = state.cityAt[cell];
      if (!id) continue;
      const city = state.cities[id];
      const owner = state.nations[city.owner];
      const saved = owner?.finale.path === "ark" && Object.values(state.cities).some((c) => c.owner === city.owner && c.buildings.includes("ark"));
      city.pop = Math.max(1, Math.floor(city.pop * (outcome === "partial" ? 1 - partialLoss(level.defense) : saved ? 0.6 : 0.1)));
    }
  }
  const player = state.player;
  const p = state.nations[player];
  let ending = outcome;
  if (outcome === "fail") {
    const hasArk = p.finale.path === "ark" && Object.values(state.cities).some((c) => c.owner === player && c.buildings.includes("ark"));
    if (p.finale.betrayed) ending = "betrayal";
    else if (hasArk) ending = "lastRefuge";
    else ending = "silence";
  }
  f.result = { outcome, defense: Math.round(level.defense * 100), winner, contributions, interceptors: level.interceptors, tracking: f.tracking };
  pushEvent(state, "impact", { outcome });
  return { outcome, winner, ending, defense: f.result.defense, contributions, winnerName: winner ? nameOf(state, winner) : null };
}

// src/game/nuclear.js
var NUKE = Object.freeze({
  radius: 1,
  popFactor: 0.35,
  buildingsLost: 2,
  falloutTurns: 20,
  interceptPerUnit: 0.12,
  interceptCap: 0.6,
  earlyWarning: 0.1,
  // спутник жертвы засекает старт
  reputation: 40,
  worldRelation: 30,
  worldGrievance: 40,
  victimGrievance: 120,
  casusBelliTurns: 30,
  winterWindow: 30,
  winterPerStrike: 0.05,
  winterFloor: 0.7
});
var DISMANTLE_SHIELD = 250;
var RECON = Object.freeze({ radius: 3, turns: 5, cooldown: 5 });
var ensure = (state) => {
  state.nuclear ??= { strikes: [] };
  state.fallout ??= {};
  state.recon ??= {};
  return state.nuclear;
};
var winterFactor = (state) => nuclearWinter(state);
function warheads(state, nationId) {
  return Object.values(state.units).filter((u) => u.owner === nationId && u.type === "icbm").length;
}
function interceptChance(state, victim) {
  if (isNeutralId(victim)) return 0;
  const mine = Object.values(state.units).filter((u) => u.owner === victim);
  const interceptors = mine.filter((u) => u.type === "interceptor").length;
  const warning = mine.some((u) => u.type === "satellite") ? NUKE.earlyWarning : 0;
  return Math.min(NUKE.interceptCap, interceptors * NUKE.interceptPerUnit + (interceptors ? warning : warning / 2));
}
var validCell = (map, cell) => typeof cell === "number" && Number.isSafeInteger(cell) && cell >= 0 && cell < map.size;
function nukeBlocker(state, map, nationId, unit, to) {
  if (!unit || unit.owner !== nationId) return "NOT_YOUR_UNIT";
  if (unit.type !== "icbm") return "NOT_WARHEAD";
  const launchCity = Object.values(state.cities).find((city) => city.cell === unit.cell);
  if (!launchCity || launchCity.owner !== nationId || !launchCity.buildings.includes("silo")) return "NEED_SILO";
  if (!validCell(map, to)) return "NO_TARGET";
  if (!state.explored[nationId][to]) return "NOT_EXPLORED";
  const victim = state.owner[to];
  if (!victim || victim === nationId) return "NO_TARGET";
  if (!atWar(state, nationId, victim)) return "NOT_AT_WAR";
  return null;
}
function launchNuke(state, map, nationId, unit, to) {
  const blocker = nukeBlocker(state, map, nationId, unit, to);
  if (blocker) return { ok: false, error: blocker };
  const log = ensure(state);
  const victim = state.owner[to];
  const from = unit.cell;
  removeUnit(state, unit.id);
  const chance = interceptChance(state, victim);
  const intercepted = chance > 0 && nextRandom(state) < chance;
  const target = Object.values(state.cities).find((c) => c.cell === to) ?? null;
  const strike = { turn: state.turn, from: nationId, to: victim, fromCell: from, cell: to, intercepted, city: target?.name ?? null };
  log.strikes.push(strike);
  if (log.strikes.length > 60) log.strikes.shift();
  const coordinateAudience = Object.keys(state.nations).sort().filter((id) => {
    if (!state.nations[id].alive || id === nationId || id === victim) return state.nations[id]?.alive;
    const seen = visibleCells(state, map, id);
    return seen.has(to) || seen.has(from);
  });
  const detail = { cell: to, fromCell: from, nuclear: true };
  const emitNuclear = (key2, params) => {
    pushEvent(state, key2, params, "all");
    if (coordinateAudience.length) pushEvent(state, key2, params, coordinateAudience, detail);
  };
  const attackerName = nameOf(state, nationId);
  const victimName = nameOf(state, victim);
  changeReputation(state, nationId, -(intercepted ? NUKE.reputation / 2 : NUKE.reputation));
  for (const other of Object.keys(state.nations).sort()) {
    if (other === nationId || !state.nations[other].alive) continue;
    if (other === victim) {
      changeRelation(state, other, nationId, -100);
      remember(state, other, nationId, "grievance", NUKE.victimGrievance, "nuclear");
    } else {
      changeRelation(state, other, nationId, -NUKE.worldRelation);
      remember(state, other, nationId, "grievance", NUKE.worldGrievance, "nuclear");
    }
    state.casusBelli ??= {};
    state.casusBelli[`${other}>${nationId}`] = state.turn + NUKE.casusBelliTurns;
  }
  if (isNeutralId(victim)) for (const p of Object.values(state.neutrals)) p.relations[nationId] = Math.max(-100, (p.relations[nationId] ?? 0) - 40);
  if (intercepted) {
    emitNuclear("nuclearIntercepted", { a: attackerName, b: victimName });
    return { ok: true, intercepted: true, chance };
  }
  let killed = 0;
  const hitCities = [];
  for (const cell of cellsWithin(map, to, NUKE.radius)) {
    for (const id of [...unitsAt(state, cell)]) {
      const u = state.units[id];
      if (UNITS[u.type].domain === "space") continue;
      removeUnit(state, id);
      killed += 1;
    }
    state.fallout[cell] = state.turn + NUKE.falloutTurns;
    const city = Object.values(state.cities).find((c) => c.cell === cell);
    if (city) {
      city.pop = Math.max(1, Math.round(city.pop * NUKE.popFactor));
      city.hp = 0;
      const lost = city.buildings.filter((b) => b !== "ark").slice(-NUKE.buildingsLost);
      city.buildings = city.buildings.filter((b) => !lost.includes(b));
      city.prod = 0;
      hitCities.push(city.name);
    }
  }
  strike.killed = killed;
  emitNuclear(target ? "nuclearStrike" : "nuclearStrikeField", { a: attackerName, b: victimName, city: target?.name ?? "" });
  return { ok: true, intercepted: false, chance, killed, cities: hitCities };
}
function dismantle(state, nationId, unit) {
  if (!unit || unit.owner !== nationId) return { ok: false, error: "NOT_YOUR_UNIT" };
  if (unit.type !== "icbm") return { ok: false, error: "NOT_WARHEAD" };
  if (!state.finale.detectedTurn) return { ok: false, error: "NO_FINALE" };
  if (!pactMembers(state).includes(nationId)) return { ok: false, error: "NOT_IN_PACT" };
  removeUnit(state, unit.id);
  addShield(state, nationId, DISMANTLE_SHIELD, "warheads");
  pushEvent(state, "warheadDismantled", { nation: nameOf(state, nationId), points: DISMANTLE_SHIELD });
  return { ok: true, points: DISMANTLE_SHIELD };
}
function orbitalRecon(state, map, nationId, unit, to) {
  if (!unit || unit.owner !== nationId) return { ok: false, error: "NOT_YOUR_UNIT" };
  if (unit.type !== "satellite") return { ok: false, error: "NOT_SATELLITE" };
  if (!validCell(map, to)) return { ok: false, error: "NO_TARGET" };
  if ((unit.reconReady ?? 0) > state.turn) return { ok: false, error: "RECON_COOLDOWN" };
  ensure(state);
  unit.reconReady = state.turn + RECON.cooldown;
  const list = (state.recon[nationId] ??= []).filter((r) => r.until > state.turn);
  list.push({ cell: to, until: state.turn + RECON.turns, by: unit.id });
  state.recon[nationId] = list;
  for (const c of cellsWithin(map, to, RECON.radius)) state.explored[nationId][c] = 1;
  return { ok: true };
}
function reconZones(state, nationId) {
  return (state.recon?.[nationId] ?? []).filter((r) => r.until > state.turn);
}
function nuclearTick(state) {
  if (state.fallout) {
    for (const k of Object.keys(state.fallout)) if (state.fallout[k] <= state.turn) delete state.fallout[k];
  }
  if (state.recon) for (const id of Object.keys(state.recon)) state.recon[id] = state.recon[id].filter((r) => r.until > state.turn);
}
function nuclearView(state, nationId) {
  const explored = state.explored[nationId];
  const seismic = state.nations[nationId].techs.includes("fission");
  return {
    warheads: warheads(state, nationId),
    winter: Math.round((1 - winterFactor(state)) * 100),
    fallout: Object.entries(state.fallout ?? {}).filter(([c, until]) => until > state.turn && (explored[c] || state.owner[c] === nationId)).map(([c, until]) => [Number(c), until]).sort((a, b) => a[0] - b[0]),
    recon: reconZones(state, nationId).map(({ cell, until }) => ({ cell, until })),
    // точку взрыва знают свидетели и все, у кого есть «Ядерное деление» (сейсмический мониторинг)
    strikes: (state.nuclear?.strikes ?? []).slice(-12).map((s) => ({ turn: s.turn, from: s.from, to: s.to, cell: explored[s.cell] || seismic || s.from === nationId || s.to === nationId ? s.cell : null, fromCell: explored[s.fromCell] || s.from === nationId ? s.fromCell : null, intercepted: s.intercepted })),
    nuclearPowers: Object.keys(state.nations).filter((id) => state.nations[id].techs.includes("fission") && (state.nations[id].met?.includes(nationId) || id === nationId)).sort()
  };
}

// src/game/state.js
var STATE_VERSION = 1;
var START_GOLD = 30;
var START_REPUTATION = 70;
var DIFFICULTIES = Object.freeze(/* @__PURE__ */ new Set(["easy", "normal", "hard"]));
function nextId(state, prefix) {
  state.idSeq += 1;
  return `${prefix}${state.idSeq}`;
}
function addUnit(state, owner, type, cell) {
  const id = nextId(state, "u");
  const unit = { id, owner, type, cell, hp: 100, moves: 0, vet: 0, fortified: false, goal: null };
  state.units[id] = unit;
  (state.unitsByCell[cell] ??= []).push(id);
  state.unitsByCell[cell].sort();
  return unit;
}
function removeUnit(state, id) {
  const unit = state.units[id];
  if (!unit) return;
  const list = state.unitsByCell[unit.cell] ?? [];
  state.unitsByCell[unit.cell] = list.filter((x) => x !== id);
  if (!state.unitsByCell[unit.cell].length) delete state.unitsByCell[unit.cell];
  delete state.units[id];
}
function placeUnit(state, unit, cell) {
  const list = state.unitsByCell[unit.cell] ?? [];
  state.unitsByCell[unit.cell] = list.filter((x) => x !== unit.id);
  if (!state.unitsByCell[unit.cell].length) delete state.unitsByCell[unit.cell];
  unit.cell = cell;
  (state.unitsByCell[cell] ??= []).push(unit.id);
  state.unitsByCell[cell].sort();
}
function claimAround(state, map, cell, owner, radius) {
  for (const c of cellsWithin(map, cell, radius)) {
    if (state.owner[c] === null && !isWater(map.terrain[c])) state.owner[c] = owner;
  }
  state.owner[cell] = owner;
}
function addCity(state, map, owner, cell, name, { capital = false, pop = 1 } = {}) {
  const id = nextId(state, "c");
  const city = { id, owner, cell, name, pop, food: 0, prod: 0, hp: 100, queue: [], buildings: [], capital, founded: state.turn, originalOwner: owner };
  state.cities[id] = city;
  state.cityAt[cell] = id;
  claimAround(state, map, cell, owner, capital && isNeutralId(owner) ? 2 : 1);
  return city;
}
var realGuard = null;
function tooRealName(name) {
  realGuard ??= createRealNameGuard(loadStopList());
  return name.split(/[\s-]+/).some((word) => word.length >= 4 && realGuard(word)) || realGuard(name);
}
function validateCustom(custom) {
  const r = CUSTOM_NATION_RULES;
  if (!custom || typeof custom.name !== "string") return null;
  const name = custom.name.trim();
  if (name.length < r.nameMin || name.length > r.nameMax || !/^[\p{L}\p{N} '\-]+$/u.test(name)) return null;
  if (tooRealName(name)) return null;
  if (!/^#[0-9a-fA-F]{6}$/.test(custom.color ?? "")) return null;
  if (!DOCTRINES[custom.doctrine]) return null;
  const emblem = custom.emblem ?? {};
  if (!r.shields.includes(emblem.shield) || !r.figures.includes(emblem.figure) || !/^#[0-9a-fA-F]{6}$/.test(emblem.field ?? "")) return null;
  const zone = custom.zone ?? "north";
  if (!NATIONS.some((n) => n.zone === zone)) return null;
  const leaderName = typeof custom.leaderName === "string" ? custom.leaderName.trim() : "";
  if (leaderName && (leaderName.length > r.nameMax || !/^[\p{L}\p{N} '\-]+$/u.test(leaderName) || tooRealName(leaderName))) return null;
  return { name, color: custom.color.toUpperCase(), doctrine: custom.doctrine, emblem: { ...emblem }, zone, leaderName };
}
function placeResources(state, map) {
  state.resourceAt = {};
  state.resourceCells = Object.fromEntries(Object.keys(STRATEGIC).map((k) => [k, []]));
  const startCells = new Set(map.startZones.flatMap((z) => cellsWithin(map, z.cell, 1)));
  for (let cell = 0; cell < map.size; cell += 1) {
    const code = map.terrain[cell];
    if (code === "O" || code === "I" || startCells.has(cell)) continue;
    for (const [res, def] of Object.entries(STRATEGIC)) {
      let p = def.weights[code] ?? 0;
      if (res === "rare" && map.naCells.has(cell)) p *= RARE_IN_NORTH_AMERICA;
      if (p > 0 && nextRandom(state) < p) {
        state.resourceAt[cell] = res;
        state.resourceCells[res].push(cell);
        break;
      }
    }
  }
  for (const zone of map.startZones) {
    const near = cellsWithin(map, zone.cell, 4).filter((c) => !startCells.has(c) && !isWater(map.terrain[c]) && map.terrain[c] !== "I");
    if (near.some((c) => state.resourceAt[c] === "iron")) continue;
    const free = near.filter((c) => !state.resourceAt[c]);
    const cell = free[Math.floor(nextRandom(state) * free.length)];
    if (cell !== void 0) {
      state.resourceAt[cell] = "iron";
      state.resourceCells.iron.push(cell);
    }
  }
  for (const list of Object.values(state.resourceCells)) list.sort((a, b) => a - b);
}
function createGame({ seed = 1, setup = {}, map = loadMap() } = {}) {
  const state = {
    version: STATE_VERSION,
    mapVersion: map.raw.version,
    seed: seedToInt(seed),
    difficulty: DIFFICULTIES.has(setup.difficulty) ? setup.difficulty : "normal",
    rng: seedToInt(seed),
    turn: 1,
    status: "running",
    result: null,
    idSeq: 0,
    eventSeq: 0,
    events: [],
    nations: {},
    neutrals: {},
    owner: new Array(map.size).fill(null),
    cities: {},
    units: {},
    unitsByCell: {},
    cityAt: {},
    relations: {},
    memory: {},
    casusBelli: {},
    pendingThreats: [],
    lastDemand: {},
    wars: [],
    warSince: {},
    truces: {},
    treaties: [],
    offers: [],
    explored: {},
    nuclear: { strikes: [] },
    fallout: {},
    recon: {},
    finale: { detectedTurn: null, impactTurn: null, impactCell: null, uncertaintyKm: null, shield: 0, tracking: false, result: null }
  };
  const custom = setup.custom ? validateCustom(setup.custom) : null;
  if (setup.custom && !custom) throw new Error("BAD_SETUP");
  if (setup.player !== void 0 && !NATIONS.some((n) => n.id === setup.player)) throw new Error("BAD_SETUP");
  const playerZone = custom ? custom.zone : NATIONS.find((n) => n.id === setup.player)?.zone ?? "north";
  for (const base of NATIONS) {
    const isPlayerSlot = base.zone === playerZone;
    const def = isPlayerSlot && custom ? { ...base, id: "player", ...custom } : base;
    state.nations[def.id] = {
      id: def.id,
      name: def.name,
      color: def.color,
      emblem: def.emblem,
      doctrine: def.doctrine,
      zone: def.zone,
      human: isPlayerSlot,
      ai: isPlayerSlot ? null : base.ai,
      alive: true,
      gold: START_GOLD,
      influence: 0,
      sciencePool: 0,
      research: null,
      techs: [],
      era: 0,
      reputation: START_REPUTATION,
      met: [],
      capital: null,
      finale: { path: null, joinedAt: null, leftAt: null, betrayed: false, contribution: 0 },
      leader: makeLeader(base.id, isPlayerSlot && custom ? custom : null),
      bluffsCalled: 0,
      lastOpTurn: -99
    };
    state.explored[def.id] = new Array(map.size).fill(0);
  }
  state.player = Object.values(state.nations).find((n) => n.human).id;
  const ids = Object.keys(state.nations);
  for (let i = 0; i < ids.length; i += 1) for (let j = i + 1; j < ids.length; j += 1) state.relations[pairKey(ids[i], ids[j])] = 0;
  placeResources(state, map);
  for (const people of map.peoples) {
    const id = `p${people.id}`;
    state.neutrals[id] = { id, name: people.name, culture: people.culture, color: people.color, alive: true, relations: Object.fromEntries(ids.map((n) => [n, 0])) };
  }
  for (const site of map.cities) {
    addCity(state, map, `p${site.people}`, site.cell, site.name, { capital: site.capital, pop: site.capital ? 3 : 2 });
  }
  for (const nation of Object.values(state.nations)) {
    const zone = map.startZones.find((z) => z.id === nation.zone);
    const settler = addUnit(state, nation.id, "settler", zone.cell);
    const next = map.neighbors[zone.cell].find((c) => !isWater(map.terrain[c]) && map.terrain[c] !== "I") ?? zone.cell;
    addUnit(state, nation.id, "warrior", next);
    settler.moves = 2;
    pushEvent(state, "gameStart", { nation: nation.name }, [nation.id]);
  }
  for (const u of Object.values(state.units)) u.moves = 2;
  updateExplored(state, map);
  return state;
}
function updateExplored(state, map) {
  for (const id of Object.keys(state.nations)) {
    if (!state.nations[id].alive) continue;
    const seen = state.explored[id];
    state.intel ??= {};
    const intel = state.intel[id] ??= {};
    for (const c of visibleCells(state, map, id)) {
      seen[c] = 1;
      const cityId = state.cityAt[c];
      if (cityId && state.cities[cityId].owner !== id) intel[cityId] = { pop: state.cities[cityId].pop, turn: state.turn };
    }
  }
}
function snapshot(state, nationId, { sinceSeq = 0, map = loadMap() } = {}) {
  const me = state.nations[nationId];
  const visible = visibleCells(state, map, nationId);
  const explored = state.explored[nationId];
  const owner = state.owner.map((o, cell) => explored[cell] ? o : void 0);
  const cities = Object.values(state.cities).filter((c) => c.owner === nationId || explored[c.cell]).map((c) => {
    if (c.owner === nationId) return c;
    const base = { id: c.id, owner: c.owner, cell: c.cell, name: c.name, capital: c.capital };
    if (visible.has(c.cell)) return { ...base, pop: c.pop, hp: c.hp, seenTurn: state.turn };
    const intel = state.intel?.[nationId]?.[c.id];
    return { ...base, pop: intel?.pop ?? null, hp: null, seenTurn: intel?.turn ?? null };
  });
  const units = Object.values(state.units).filter((u) => u.owner === nationId || visible.has(u.cell)).map((u) => u.owner === nationId ? u : { id: u.id, owner: u.owner, type: u.type, cell: u.cell, hp: u.hp });
  const resources = {};
  for (const [cell, res] of Object.entries(state.resourceAt)) {
    if (explored[cell] && STRATEGIC[res].era <= me.era) resources[cell] = res;
  }
  const nations = Object.values(state.nations).map((n) => n.id === nationId ? n : {
    id: n.id,
    name: n.name,
    color: n.color,
    emblem: n.emblem,
    alive: n.alive,
    // доктрина и лидер — разведданные: до встречи о нации известно только имя и флаг
    doctrine: me.met.includes(n.id) ? n.doctrine : null,
    met: me.met.includes(n.id),
    era: me.met.includes(n.id) ? n.era : null,
    reputation: me.met.includes(n.id) ? n.reputation : null,
    // выбор пути в финале объявляется всем; вклад виден только знакомым нациям
    finale: state.finale.detectedTurn ? { path: n.finale.path, contribution: me.met.includes(n.id) ? Math.round(n.finale.contribution) : null } : { path: null, contribution: null },
    leader: me.met.includes(n.id) ? n.leader : null,
    // как этот лидер относится к игроку и что помнит о нём
    attitude: me.met.includes(n.id) ? Math.round(attitude(state, n.id, nationId)) : null,
    mood: me.met.includes(n.id) ? moodOf(attitude(state, n.id, nationId)).name : null,
    moodId: me.met.includes(n.id) ? moodOf(attitude(state, n.id, nationId)).id : null,
    remembers: me.met.includes(n.id) ? memoryOf(state, n.id, nationId).log.slice(-5) : [],
    credibility: me.met.includes(n.id) ? Math.round(credibility(state, n.id) * 100) : null,
    intrigue: me.met.includes(n.id) ? Object.fromEntries(Object.keys(OPS).map((op) => {
      const c = opChances(state, nationId, n.id, op);
      return [op, { success: Math.round(c.success * 100), exposure: Math.round(c.exposure * 100) }];
    })) : null,
    casusBelli: me.met.includes(n.id) ? hasCasusBelli(state, nationId, n.id) : false
  });
  return structuredClone({
    version: state.version,
    turn: state.turn,
    status: state.status,
    result: state.result,
    nationId,
    difficulty: state.difficulty,
    nations,
    neutrals: Object.values(state.neutrals).map((p) => ({ id: p.id, name: p.name, color: p.color, alive: p.alive, relation: Math.round(p.relations[nationId] ?? 0) })),
    relations: Object.fromEntries(me.met.map((id) => [id, Math.round(state.relations[pairKey(nationId, id)])])),
    wars: state.wars.filter((k) => k.split("|").includes(nationId)),
    treaties: state.treaties.filter((t) => t.a === nationId || t.b === nationId),
    offers: state.offers.filter((o) => o.to === nationId),
    owner,
    explored: explored.join(""),
    visible: [...visible].sort((a, b) => a - b),
    cities,
    units,
    resources,
    // точная точка удара остаётся на сервере: клиент видит только эллипс неопределённости
    finale: state.finale.detectedTurn ? (({ impactCell, ...rest }) => ({ ...rest, shieldTarget: SHIELD_TARGET, impactArea: impactArea(state, map, impactCell, rest.uncertaintyKm) }))(state.finale) : null,
    events: state.events.filter((e) => e.seq > sinceSeq && (e.audience === "all" || e.audience.includes(nationId))),
    choices: playerChoices(state, map, nationId),
    nuclear: nuclearView(state, nationId)
  });
}
function impactArea(state, map, impactCell, uncertaintyKm) {
  if (impactCell === null || impactCell === void 0) return null;
  const { lat, lon } = map.cells[impactCell];
  const bearing = seedToInt(`${state.seed}:impact`) % 360 * Math.PI / 180;
  const d = uncertaintyKm * 0.5;
  const cLat = Math.max(-89, Math.min(89, lat + d / 111.2 * Math.cos(bearing)));
  let cLon = lon + d / (111.2 * Math.max(0.1, Math.cos(lat * Math.PI / 180))) * Math.sin(bearing);
  cLon = (cLon + 540) % 360 - 180;
  return { lat: Math.round(cLat * 10) / 10, lon: Math.round(cLon * 10) / 10, uncertaintyKm };
}
function playerChoices(state, map, nationId) {
  if (!state.nations[nationId]?.alive) return { techs: [], production: {} };
  const production = {};
  for (const city of Object.values(state.cities)) {
    if (city.owner !== nationId) continue;
    const items = [];
    for (const id of Object.keys(UNITS)) {
      const item = { kind: "unit", id };
      if (!itemBlocker(state, map, city, item)) items.push({ ...item, cost: Math.round(itemCost(state, map, city, item)) });
    }
    for (const id of Object.keys(BUILDINGS)) {
      const item = { kind: "building", id };
      if (!itemBlocker(state, map, city, item)) items.push({ ...item, cost: Math.round(itemCost(state, map, city, item)) });
    }
    if (!itemBlocker(state, map, city, { kind: "dome" })) items.push({ kind: "dome", id: null, cost: null });
    production[city.id] = items;
  }
  return { techs: availableTechs(state, nationId), production };
}

// src/game/negotiation.js
var DEMAND_REPUTATION = 5;
var BLUFF_WINDOW = 3;
var DEMAND_COOLDOWN = 10;
function normalizeSide(raw) {
  const side = raw !== null && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  return {
    gold: Math.min(1e6, Math.max(0, Math.floor(typeof side.gold === "number" && Number.isFinite(side.gold) ? side.gold : 0))),
    techs: Array.isArray(side.techs) ? [...new Set(side.techs.filter((t) => typeof t === "string"))].slice(0, 6).sort() : [],
    cities: Array.isArray(side.cities) ? [...new Set(side.cities.filter((c) => typeof c === "string"))].slice(0, 4).sort() : [],
    treaties: Array.isArray(side.treaties) ? [...new Set(side.treaties.filter((t) => own(TREATY_RULES, t)))].sort() : [],
    peace: side.peace === true,
    joinWar: typeof side.joinWar === "string" ? side.joinWar : null
  };
}
function normalizeDeal(raw) {
  const deal = raw !== null && typeof raw === "object" ? raw : {};
  const give = normalizeSide(deal.give);
  const take = normalizeSide(deal.take);
  give.treaties = [.../* @__PURE__ */ new Set([...give.treaties, ...take.treaties])].sort();
  give.peace = give.peace || take.peace;
  take.treaties = [];
  take.peace = false;
  return { give, take };
}
var isEmptySide = (s) => !s.gold && !s.techs.length && !s.cities.length && !s.treaties.length && !s.peace && !s.joinWar;
function sideBlocker(state, owner, to, side) {
  const o = state.nations[owner];
  if (side.gold > o.gold) return "NOT_ENOUGH_GOLD";
  for (const t of side.techs) {
    if (!own(TECHS, t) || !o.techs.includes(t)) return "TECH_UNAVAILABLE";
    if (!techLearnable(state.nations[to], t)) return "TECH_NOT_READY";
  }
  for (const id of side.cities) {
    const c = own(state.cities, id) ? state.cities[id] : null;
    if (!c || c.owner !== owner) return "NOT_YOUR_CITY";
    if (c.capital || c.id === o.originalCapital) return "CAPITAL_NOT_FOR_SALE";
  }
  if (side.joinWar) {
    const enemy = side.joinWar;
    if (!own(state.nations, enemy) || enemy === owner || enemy === to || !state.nations[enemy].alive) return "UNKNOWN_NATION";
    if (!o.met.includes(enemy)) return "NOT_MET";
    if (atWar(state, owner, enemy)) return "ALREADY_AT_WAR";
    if ((state.truces[pairKey(owner, enemy)] ?? 0) > state.turn) return "TRUCE";
    if (treatyBetween(state, owner, enemy, "alliance")) return "TREATY_EXISTS";
  }
  return null;
}
function dealBlocker(state, from, to, deal) {
  if (isEmptySide(deal.give) && isEmptySide(deal.take)) return "EMPTY_DEAL";
  for (const t of deal.give.treaties) if (treatyBetween(state, from, to, t)) return "TREATY_EXISTS";
  const war = atWar(state, from, to);
  if (deal.give.peace && !war) return "NOT_AT_WAR";
  if (war && !deal.give.peace) return "ALREADY_AT_WAR";
  for (const t of deal.give.treaties) {
    if (attitude(state, to, from) < TREATY_RULES[t].minRelation - 10) return "RELATION_TOO_LOW";
    if (attitude(state, from, to) < TREATY_RULES[t].minRelation - 10 && !state.nations[from].human) return "RELATION_TOO_LOW";
  }
  return sideBlocker(state, from, to, deal.give) ?? sideBlocker(state, to, from, deal.take);
}
function techValue(state, nationId, tech) {
  return techCost(state, nationId, tech) * 0.5;
}
var TRUST_CAP = 20;
function cityValue(state, id) {
  const c = state.cities[id];
  return 60 + c.pop * 35 + c.buildings.length * 25;
}
function sideValue(state, judge, other, side, receiving) {
  const t = traits(state, judge);
  let v = side.gold * (0.4 + t.greed * 0.6);
  for (const tech of side.techs) {
    const cost = techValue(state, receiving ? judge : other, tech);
    v += receiving ? cost : cost * (1.1 + t.pride * 0.4) * (TECHS[tech].era === 3 ? 2 : 1);
  }
  for (const id of side.cities) v += cityValue(state, id) * (receiving ? 1 : 1.6 + t.pride);
  if (side.joinWar) {
    const enemyAttitude = attitude(state, judge, side.joinWar);
    const value = Math.max(-200, -enemyAttitude * 3) - 60 * t.caution;
    v += receiving ? value : -value;
  }
  return v;
}
function mutualValue(state, judge, other, deal) {
  const t = traits(state, judge);
  const att = attitude(state, judge, other);
  let v = 0;
  for (const type of deal.give.treaties) {
    const need = TREATY_RULES[type].minRelation;
    v += (att - need) * 2 + (type === "trade" ? 20 * t.greed : 0) + (type === "alliance" ? -30 * t.caution : 0);
  }
  if (deal.give.peace) {
    const turns = state.turn - (state.warSince[pairKey(judge, other)] ?? state.turn);
    if (turns < PEACE_MIN_WAR_TURNS) v -= 300;
    const ratio = (militaryPower(state, judge) + 1) / (militaryPower(state, other) + 1);
    v += (1.2 - ratio) * 120 + turns * 3 - t.pride * 40;
  }
  return v;
}
function evaluateDeal(state, judge, from, deal) {
  const gets = sideValue(state, judge, from, deal.give, true);
  const pays = sideValue(state, judge, from, deal.take, false);
  const att = attitude(state, judge, from);
  const rep = state.nations[from].reputation;
  const trust = Math.min(TRUST_CAP, (rep - 50) * 0.8 + att * 0.6);
  const mutual = mutualValue(state, judge, from, deal);
  let score = gets - pays + mutual + trust;
  if ((deal.take.techs.length || deal.take.cities.length) && gets + Math.max(0, mutual) < pays * 0.5) {
    score = Math.min(score, -Math.max(1, pays * 0.5 - gets - Math.max(0, mutual)));
  }
  return { score, accept: score >= 0 };
}
function counterOffer(state, judge, from, deal, score) {
  if (score >= 0) return null;
  const t = traits(state, judge);
  const missing = -score;
  const rate = 0.4 + t.greed * 0.6;
  const counter = structuredClone(deal);
  const goldNeeded = Math.ceil(missing / rate);
  const fromGold = state.nations[from].gold - counter.give.gold;
  if (goldNeeded <= fromGold) {
    counter.give.gold += goldNeeded;
    return counter;
  }
  const techs = state.nations[from].techs.filter((x) => !state.nations[judge].techs.includes(x) && !counter.give.techs.includes(x) && techLearnable(state.nations[judge], x)).sort((a, b) => techValue(state, judge, b) - techValue(state, judge, a) || a.localeCompare(b));
  let covered = Math.max(0, fromGold) * rate;
  for (const tech of techs) {
    counter.give.techs.push(tech);
    covered += techValue(state, judge, tech);
    if (covered >= missing) {
      counter.give.gold += Math.max(0, fromGold);
      counter.give.techs.sort();
      return counter;
    }
  }
  return null;
}
function transferSide(state, map, from, to, side) {
  state.nations[from].gold -= side.gold;
  state.nations[to].gold += side.gold;
  for (const tech of side.techs) grantTech(state, state.nations[to], tech);
  for (const id of side.cities) {
    const c = state.cities[id];
    c.owner = to;
    c.queue = [];
    for (const cell of cellsWithin(map, c.cell, 2)) if (state.owner[cell] === from) state.owner[cell] = to;
    evacuate(state, map, from, c.cell);
  }
}
function evacuate(state, map, owner, cell) {
  const units = (state.unitsByCell[cell] ?? []).map((id) => state.units[id]).filter((u) => u.owner === owner);
  if (!units.length) return;
  const candidates = cellsWithin(map, cell, 6).filter((c) => !isWater(map.terrain[c]) && !state.cityAt[c] && !(state.unitsByCell[c] ?? []).some((id) => state.units[id].owner !== owner));
  const home = candidates.filter((c) => state.owner[c] === owner);
  for (const u of units) {
    const target = home[0] ?? candidates[0];
    if (target === void 0) {
      removeUnitRaw(state, u);
      continue;
    }
    moveUnitRaw(state, u, target);
    u.goal = null;
    u.moves = 0;
  }
}
function removeUnitRaw(state, unit) {
  state.unitsByCell[unit.cell] = (state.unitsByCell[unit.cell] ?? []).filter((x) => x !== unit.id);
  if (!state.unitsByCell[unit.cell].length) delete state.unitsByCell[unit.cell];
  delete state.units[unit.id];
}
function moveUnitRaw(state, unit, cell) {
  state.unitsByCell[unit.cell] = (state.unitsByCell[unit.cell] ?? []).filter((x) => x !== unit.id);
  if (!state.unitsByCell[unit.cell].length) delete state.unitsByCell[unit.cell];
  unit.cell = cell;
  (state.unitsByCell[cell] ??= []).push(unit.id);
  state.unitsByCell[cell].sort();
}
function executeDeal(state, map, from, to, deal) {
  const blocker = dealBlocker(state, from, to, deal);
  if (blocker) return blocker;
  if (deal.give.peace) makePeace(state, from, to);
  transferSide(state, map, from, to, deal.give);
  transferSide(state, map, to, from, deal.take);
  for (const type of deal.give.treaties) addTreaty(state, from, to, type);
  if (deal.give.joinWar && !atWar(state, from, deal.give.joinWar)) declareWar(state, from, deal.give.joinWar);
  if (deal.take.joinWar && !atWar(state, to, deal.take.joinWar)) declareWar(state, to, deal.take.joinWar);
  remember(state, to, from, "favor", 8, "deal");
  remember(state, from, to, "favor", 8, "deal");
  pushEvent(state, "dealDone", { a: nameOf(state, from), b: nameOf(state, to) });
  return null;
}
function evaluateDemand(state, judge, from, rawTake) {
  const take = normalizeSide(rawTake);
  const t = traits(state, judge);
  const ratio = (militaryPower(state, from) + 1) / (militaryPower(state, judge) + 1);
  const allies = majorIds(state).filter((x) => x !== judge && x !== from && treatyBetween(state, judge, x, "alliance"));
  const alliedPower = allies.reduce((s, x) => s + militaryPower(state, x), 0);
  const effective = (militaryPower(state, from) + 1) / (militaryPower(state, judge) + alliedPower * 0.6 + 1);
  const threat = effective * credibility(state, from) * (0.6 + t.caution * 0.8);
  const cost = sideValue(state, judge, from, take, false) / 250;
  const resistance = 1 + t.pride * 0.8 + cost;
  return { accept: threat > resistance, threat, resistance, ratio };
}
function demandBlocker(state, from, to) {
  if (treatyBetween(state, from, to, "nap") || treatyBetween(state, from, to, "alliance")) return "HAS_TREATY";
  const last = state.lastDemand?.[`${from}>${to}`];
  if (last !== void 0 && state.turn - last < DEMAND_COOLDOWN) return "DEMAND_COOLDOWN";
  return null;
}
function makeDemand(state, map, from, to, rawTake) {
  const take = normalizeSide(rawTake);
  state.lastDemand ??= {};
  state.lastDemand[`${from}>${to}`] = state.turn;
  const n = state.nations[from];
  n.demandLog = (n.demandLog ?? []).filter((t) => state.turn - t < 30);
  changeReputation(state, from, -DEMAND_REPUTATION * (1 + n.demandLog.length));
  n.demandLog.push(state.turn);
  const verdict = evaluateDemand(state, to, from, take);
  if (verdict.accept) {
    transferSide(state, map, to, from, take);
    remember(state, to, from, "grievance", 35, "extortion");
    changeRelation(state, from, to, -20);
    pushEvent(state, "demandAccepted", { a: nameOf(state, to), b: nameOf(state, from) });
    return { accepted: true, reply: say(state, to, "demandAccept", { target: nameOf(state, from) }) };
  }
  remember(state, from, to, "grievance", 10, "refused");
  changeRelation(state, from, to, -25);
  state.pendingThreats ??= [];
  state.pendingThreats.push({ from, to, turn: state.turn });
  pushEvent(state, "demandRefused", { a: nameOf(state, to), b: nameOf(state, from) });
  return { accepted: false, reply: say(state, to, "demandRefuse", { target: nameOf(state, from) }) };
}
function threatTick(state) {
  if (!state.pendingThreats?.length) return;
  const keep = [];
  for (const th of state.pendingThreats) {
    if (atWar(state, th.from, th.to)) continue;
    if (state.turn - th.turn >= BLUFF_WINDOW) {
      const n = state.nations[th.from];
      n.bluffsCalled = (n.bluffsCalled ?? 0) + 1;
      pushEvent(state, "bluffCalled", { nation: n.name });
    } else keep.push(th);
  }
  state.pendingThreats = keep;
}

// src/game/tactical.js
var TICK = 0.2;
var FIELD = Object.freeze({ w: 640, h: 480, deploy: 130, grid: 33 });
var TIME_LIMIT = 15 * 60 / TICK;
var K = Object.freeze({ melee: 0.012, fire: 0.03, moraleLoss: 90, rout: 20, rally: 45, flank: 1.6, rear: 2.2 });
var TROOPS = Object.freeze({
  warrior: { men: 48, kind: "foot", melee: 1, armor: 0.8, speed: 1.6, run: 3.4, spacing: 1.3, ranks: 4 },
  archer: { men: 40, kind: "foot", melee: 0.5, armor: 0.7, speed: 1.6, run: 3.4, spacing: 1.4, ranks: 3, range: 130, fire: 0.6, reload: 12, ammo: 24, projectile: "arrow" },
  swordsman: { men: 48, kind: "foot", melee: 1.35, armor: 1.25, speed: 1.5, run: 3.1, spacing: 1.3, ranks: 4 },
  militia: { men: 40, kind: "foot", melee: 0.8, armor: 0.8, speed: 1.4, run: 3, spacing: 1.3, ranks: 4 },
  infantry: { men: 48, kind: "foot", melee: 0.8, armor: 1, speed: 1.8, run: 3.8, spacing: 1.8, ranks: 2, range: 220, fire: 0.75, reload: 9, ammo: 40, projectile: "bullet" },
  artillery: { men: 4, kind: "gun", melee: 0.15, armor: 1, speed: 1, run: 1.3, spacing: 14, ranks: 1, range: 480, fire: 1.2, reload: 30, ammo: 30, projectile: "shell", splash: true },
  tank: { men: 4, kind: "vehicle", melee: 1.6, armor: 2.5, speed: 5, run: 8, spacing: 16, ranks: 1, range: 320, fire: 1.1, reload: 18, ammo: 40, projectile: "shell" },
  helicopter: { men: 3, kind: "air", melee: 0, armor: 1.4, speed: 18, run: 30, spacing: 22, ranks: 1, range: 300, fire: 1, reload: 12, ammo: 30, projectile: "rocket" },
  drone: { men: 3, kind: "air", melee: 0, armor: 1, speed: 25, run: 40, spacing: 25, ranks: 1, range: 400, fire: 1, reload: 20, ammo: 12, projectile: "rocket" },
  fighter: { men: 2, kind: "air", melee: 0, armor: 1.2, speed: 60, run: 90, spacing: 40, ranks: 1, range: 450, fire: 1.2, reload: 25, ammo: 8, projectile: "rocket" },
  biplane: { men: 3, kind: "air", melee: 0, armor: 0.8, speed: 30, run: 45, spacing: 30, ranks: 1, range: 250, fire: 0.5, reload: 10, ammo: 30, projectile: "bullet" }
});
var FORMATIONS = Object.freeze({
  line: { name: "\u041B\u0438\u043D\u0438\u044F", ranksMul: 1, spacingMul: 1, melee: 1, armor: 1, fireTaken: 1 },
  deep: { name: "\u041A\u043E\u043B\u043E\u043D\u043D\u0430", ranksMul: 2, spacingMul: 0.9, melee: 1.15, armor: 1.15, fireTaken: 1.3 },
  loose: { name: "\u0420\u0430\u0441\u0441\u044B\u043F\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u0439", ranksMul: 0.5, spacingMul: 2.2, melee: 0.75, armor: 0.9, fireTaken: 0.55 }
});
var rand = (b) => {
  b.rng = Math.imul(b.rng, 1664525) + 1013904223 | 0;
  return (b.rng >>> 0) / 4294967296;
};
var dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var clamp2 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var alive = (r) => r.men > 0 && r.state !== "fled";
var fighting = (r) => alive(r) && r.state !== "rout";
var isTacticalType = (type) => Boolean(TROOPS[type]);
function buildTerrain(b, code) {
  const amp = { M: 38, F: 12, P: 7, D: 9, T: 6, I: 10 }[code] ?? 8;
  const n = FIELD.grid;
  const waves = Array.from({ length: 5 }, () => ({ fx: 1 + rand(b) * 3, fy: 1 + rand(b) * 3, px: rand(b) * 6.28, py: rand(b) * 6.28, a: 0.3 + rand(b) * 0.7 }));
  const heights = [];
  for (let j = 0; j < n; j += 1) for (let i = 0; i < n; i += 1) {
    let h = 0;
    for (const w of waves) h += w.a * Math.sin(i / n * w.fx * 3.14 + w.px) * Math.cos(j / n * w.fy * 3.14 + w.py);
    heights.push(Math.round(h * amp * 10) / 10);
  }
  const woods = [];
  const patches = { F: 9, P: 3, T: 4, M: 3, D: 0, I: 0 }[code] ?? 2;
  for (let k = 0; k < patches; k += 1) {
    const x = (rand(b) - 0.5) * FIELD.w * 0.9;
    const y = (rand(b) - 0.5) * FIELD.h * 0.9;
    if (Math.abs(y) < 40 && Math.abs(x) < 120) continue;
    woods.push({ x: Math.round(x), y: Math.round(y), r: Math.round(30 + rand(b) * (code === "F" ? 60 : 35)) });
  }
  return { code, biome: TERRAIN[code]?.id ?? "plain", heights, n, woods };
}
function heightAt(t, x, y) {
  const n = t.n;
  const fx = clamp2((x / FIELD.w + 0.5) * (n - 1), 0, n - 1.001);
  const fy = clamp2((y / FIELD.h + 0.5) * (n - 1), 0, n - 1.001);
  const i = Math.floor(fx);
  const j = Math.floor(fy);
  const u = fx - i;
  const v = fy - j;
  const h = (a, c) => t.heights[c * n + a];
  return h(i, j) * (1 - u) * (1 - v) + h(i + 1, j) * u * (1 - v) + h(i, j + 1) * (1 - u) * v + h(i + 1, j + 1) * u * v;
}
var inWoods = (t, p) => t.woods.some((w) => Math.hypot(w.x - p.x, w.y - p.y) < w.r);
function makeRegiment(b, unit, side, slot, count, extra = {}) {
  const type = extra.type ?? unit.type;
  const T = TROOPS[type];
  const hp = unit ? unit.hp : 100;
  const menMax = T.men;
  const men = Math.max(1, Math.round(menMax * hp / 100));
  const dir = side === "a" ? -1 : 1;
  const spread = Math.min(70, 340 / Math.max(1, count));
  const x = (slot - (count - 1) / 2) * spread;
  const backRow = T.range && T.kind !== "air" ? 30 : 0;
  const r = {
    id: `R${b.regiments.length + 1}`,
    side,
    owner: extra.owner ?? unit.owner,
    unitId: unit?.id ?? null,
    type,
    str: (extra.str ?? UNITS[unit.type].str) * (1 + 0.1 * (unit?.vet ?? 0)),
    men,
    menStart: men,
    menMax,
    morale: 70 + 8 * (unit?.vet ?? 0),
    fatigue: 0,
    ammo: T.ammo ?? 0,
    reloadLeft: 0,
    x,
    y: dir * (FIELD.deploy + backRow),
    facing: side === "a" ? Math.PI / 2 : -Math.PI / 2,
    formation: "line",
    state: "ready",
    order: { kind: "hold" },
    engaged: null,
    dmg: 0,
    kills: 0,
    era: extra.era ?? 0
    // эпоха владельца: по ней клиент выбирает облик полка
  };
  b.regiments.push(r);
  return r;
}
function startBattle(state, map, attacker, cell) {
  const cityId = state.cityAt[cell];
  const city = cityId && state.cities[cityId].owner !== attacker.owner ? state.cities[cityId] : null;
  const b = { id: `B${state.turn}-${attacker.id}`, rng: Math.floor(nextRandom(state) * 2 ** 31), tick: 0, regiments: [], fx: [], result: null };
  b.terrain = buildTerrain(b, map.terrain[cell]);
  const mine = [attacker, ...unitsAt(state, attacker.cell).map((id) => state.units[id]).filter((u) => u.id !== attacker.id && u.owner === attacker.owner && isTacticalType(u.type) && u.moves > 0)];
  const theirs = unitsAt(state, cell).map((id) => state.units[id]).filter((u) => u.owner !== attacker.owner && isTacticalType(u.type));
  const defOwner = city?.owner ?? theirs[0]?.owner;
  const eraOf = (id) => isNeutralId(id) ? Math.min(3, Math.floor(state.turn / 50)) : state.nations[id]?.era ?? 0;
  mine.forEach((u, i) => makeRegiment(b, u, "a", i, mine.length, { era: eraOf(u.owner) }));
  const dCount = theirs.length + (city ? 1 : 0);
  theirs.forEach((u, i) => makeRegiment(b, u, "d", i, dCount, { era: eraOf(u.owner) }));
  if (city) {
    const era = isNeutralId(city.owner) ? Math.min(3, Math.floor(state.turn / 50)) : state.nations[city.owner].era;
    const militia = makeRegiment(b, null, "d", theirs.length, dCount, { type: "militia", owner: city.owner, str: 6 + era * 8 + city.pop, era });
    militia.men = militia.menStart = Math.max(8, Math.round(militia.menMax * Math.max(0.35, city.hp / 100)));
  }
  b.city = city ? { id: city.id, name: city.name, x: 0, y: FIELD.deploy + 40, r: 95, walls: city.buildings.includes("walls") } : null;
  b.attacker = { owner: attacker.owner, unitId: attacker.id, from: attacker.cell, name: nameOf(state, attacker.owner) };
  b.defender = { owner: defOwner, cell, name: city ? city.name : nameOf(state, defOwner) };
  b.human = state.nations[attacker.owner]?.human ? "a" : null;
  for (const u of mine) {
    u.moves = 0;
    u.fortified = false;
  }
  state.battle = b;
  return b;
}
var enemiesOf = (b, r) => b.regiments.filter((o) => o.side !== r.side && alive(o));
function nearest(list, p) {
  let best = null;
  let d = Infinity;
  for (const o of list) {
    const k = dist(o, p);
    if (k < d || k === d && o.id < best.id) {
      d = k;
      best = o;
    }
  }
  return best;
}
var frontage = (r) => {
  const T = TROOPS[r.type];
  const F = FORMATIONS[r.formation];
  const ranks = Math.max(1, Math.round(T.ranks * F.ranksMul));
  const files = Math.ceil(r.men / ranks);
  return { w: files * T.spacing * F.spacingMul, d: ranks * T.spacing * F.spacingMul, ranks, files };
};
var reach = (a, o) => {
  const fa = frontage(a);
  const fo = frontage(o);
  return (fa.d + fo.d) / 2 + Math.min(fa.w, fo.w) * 0.35 + 3;
};
function flankMul(attacker, target) {
  const dx = attacker.x - target.x;
  const dy = attacker.y - target.y;
  const len = Math.hypot(dx, dy) || 1;
  const dot = (Math.cos(target.facing) * dx + Math.sin(target.facing) * dy) / len;
  return dot > 0.5 ? 1 : dot > -0.5 ? K.flank : K.rear;
}
var heightMul = (b, a, o) => 1 + clamp2((heightAt(b.terrain, a.x, a.y) - heightAt(b.terrain, o.x, o.y)) / 25, -0.25, 0.25);
var fortMul = (b, r) => b.city && r.side === "d" && Math.hypot(r.x - b.city.x, r.y - b.city.y) < b.city.r ? b.city.walls ? 1 + BUILDINGS.walls.defense * 2 : 1.4 : 1;
function hurt(b, target, loss, source) {
  if (loss <= 0 || !alive(target)) return;
  target.dmg += loss * target.menMax;
  const before = target.men;
  while (target.dmg >= 1 && target.men > 0) {
    target.dmg -= 1;
    target.men -= 1;
  }
  const dead = before - target.men;
  if (source) source.kills += dead;
  target.morale -= dead / target.menMax * K.moraleLoss + loss * 20;
  if (target.men <= 0) target.state = "dead";
}
function turnTo(r, angle, dt) {
  let d = angle - r.facing;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  const max = (TROOPS[r.type].kind === "air" ? 3 : 1.6) * dt;
  r.facing += clamp2(d, -max, max);
}
function moveToward(b, r, p, run, dt) {
  const T = TROOPS[r.type];
  const d = dist(r, p);
  if (d < 1.5) return true;
  let speed = run ? T.run : T.speed;
  if (T.kind !== "air" && inWoods(b.terrain, r)) speed *= 0.6;
  if (T.kind !== "air") {
    const ahead = { x: r.x + (p.x - r.x) / d * 4, y: r.y + (p.y - r.y) / d * 4 };
    const slope = (heightAt(b.terrain, ahead.x, ahead.y) - heightAt(b.terrain, r.x, r.y)) / 4;
    speed *= clamp2(1 - slope * 1.5, 0.5, 1.2);
    speed *= 1 - r.fatigue / 200;
  }
  const step = Math.min(d, speed * dt);
  turnTo(r, Math.atan2(p.y - r.y, p.x - r.x), dt);
  r.x = clamp2(r.x + (p.x - r.x) / d * step, -FIELD.w / 2 + 5, FIELD.w / 2 - 5);
  r.y += (p.y - r.y) / d * step;
  if (run) r.fatigue = Math.min(100, r.fatigue + 0.35 * dt * 5);
  return false;
}
function aiOrder(b, r) {
  const enemies = enemiesOf(b, r).filter((o) => o.state !== "rout");
  if (!enemies.length) return { kind: "hold" };
  const T = TROOPS[r.type];
  const target = nearest(enemies, r);
  const d = dist(r, target);
  if (T.range && r.ammo > 0) {
    if (d < T.range * 0.9 && !(d < 25 && T.melee < 0.6)) return { kind: "hold", target: target.id };
    if (d < 25) return { kind: "move", x: r.x, y: r.y + (r.side === "a" ? -60 : 60), run: true };
    return r.side === "d" && b.tick < 300 ? { kind: "hold" } : { kind: "attack", target: target.id, keep: T.range * 0.8 };
  }
  if (r.side === "d" && d > 180 && b.tick < 900) return { kind: "hold" };
  const ours = b.regiments.filter((o) => o.side === r.side && fighting(o) && TROOPS[o.type].melee >= 0.8 && !TROOPS[o.type].range);
  const theirs = enemies.filter((o) => TROOPS[o.type].melee >= 0.8 && !TROOPS[o.type].range);
  const idx = ours.indexOf(r);
  if (idx >= theirs.length && theirs.length && d > 60) {
    const side = idx % 2 ? 1 : -1;
    const fx = target.x + Math.cos(target.facing + side * Math.PI / 2) * 70 - Math.cos(target.facing) * 30;
    const fy = target.y + Math.sin(target.facing + side * Math.PI / 2) * 70 - Math.sin(target.facing) * 30;
    return { kind: "move", x: fx, y: fy, run: false, then: target.id };
  }
  return { kind: "attack", target: target.id, run: d < 70 };
}
function stepRegiment(b, r, dt) {
  const T = TROOPS[r.type];
  if (!alive(r)) return;
  if (r.state === "rout") {
    const foe = nearest(enemiesOf(b, r).filter(fighting), r);
    const away = r.side === "a" ? -FIELD.h : FIELD.h;
    moveToward(b, r, { x: r.x + (foe ? Math.sign(r.x - foe.x) * 30 : 0), y: away }, true, dt);
    if (Math.abs(r.y) > FIELD.h / 2) r.state = "fled";
    if (r.morale > K.rally && (!foe || dist(foe, r) > 150)) {
      r.state = "ready";
      r.order = { kind: "hold" };
    }
    r.morale += 0.6 * dt;
    return;
  }
  const human = b.human === r.side && !b.auto;
  if (!human && b.tick % 5 === 0) r.order = aiOrder(b, r);
  const o = r.order;
  const byId = (id) => b.regiments.find((x) => x.id === id);
  const contact = T.kind === "air" ? null : nearest(enemiesOf(b, r).filter((e) => TROOPS[e.type].kind !== "air" && dist(e, r) < reach(r, e)), r);
  r.engaged = contact?.id ?? null;
  if (contact) {
    turnTo(r, Math.atan2(contact.y - r.y, contact.x - r.x), dt * 0.02);
    const F = FORMATIONS[r.formation];
    const FC = FORMATIONS[contact.formation];
    const power = r.str * (r.men / r.menMax) * T.melee * F.melee * (1 - r.fatigue / 250) * clamp2(r.morale / 60, 0.5, 1.2);
    const guard = contact.str * TROOPS[contact.type].armor * FC.armor * fortMul(b, contact);
    const exposed = flankMul(contact, r) > 1 ? 0.55 : 1;
    const mul = flankMul(r, contact) * exposed * heightMul(b, r, contact) * (0.85 + rand(b) * 0.3);
    hurt(b, contact, K.melee * dt * power * mul / guard, r);
    if (mul > 1.3) contact.morale -= 2.5 * dt;
    r.fatigue = Math.min(100, r.fatigue + 0.25 * dt);
    return;
  }
  if (!T.range || r.ammo <= 0) r.aim = null;
  if (T.range && r.ammo > 0) {
    r.reloadLeft = Math.max(0, r.reloadLeft - 1);
    const wanted = o.target ? byId(o.target) : null;
    const targets = enemiesOf(b, r).filter((e) => dist(e, r) <= T.range && !(T.kind === "foot" && TROOPS[e.type].kind === "air" && T.projectile === "arrow"));
    const target = wanted && alive(wanted) && dist(wanted, r) <= T.range ? wanted : o.kind !== "move" ? nearest(targets, r) : null;
    if (target && r.reloadLeft === 0) {
      const d = dist(target, r);
      const acc = clamp2(1.15 - d / T.range, 0.2, 1);
      const cover = inWoods(b.terrain, target) ? 0.6 : 1;
      const air = TROOPS[target.type].kind === "air" ? 0.35 : 1;
      const power = r.str * (r.men / r.menMax) * T.fire * acc * cover * air * FORMATIONS[target.formation].fireTaken * (0.8 + rand(b) * 0.4);
      const guard = target.str * TROOPS[target.type].armor * fortMul(b, target);
      hurt(b, target, K.fire * T.reload * TICK * power / guard, r);
      target.morale -= T.splash ? 3 : 0.6;
      r.ammo -= 1;
      r.reloadLeft = T.reload;
      b.fx.push({ t: b.tick, kind: T.projectile, from: r.id, to: target.id, x: target.x, y: target.y });
      r.aim = target.id;
      if (o.kind === "hold" || o.kind === "attack" && o.keep && d <= o.keep) turnTo(r, Math.atan2(target.y - r.y, target.x - r.x), dt * 3);
    }
    if (!target) r.aim = null;
    if (target && o.kind === "attack" && o.keep && dist(target, r) <= o.keep) return;
  }
  if (o.kind === "move") {
    const done = moveToward(b, r, o, o.run, dt);
    if (done) r.order = o.then ? { kind: "attack", target: o.then, run: true } : { kind: "hold" };
  } else if (o.kind === "attack") {
    const t = byId(o.target);
    if (!t || !alive(t)) r.order = { kind: "hold" };
    else moveToward(b, r, t, o.run || dist(t, r) < 60, dt);
  } else {
    r.fatigue = Math.max(0, r.fatigue - 0.4 * dt);
  }
  if (!r.engaged) r.morale = Math.min(80 + 8 * (r.vet ?? 0), r.morale + 0.25 * dt);
}
function moraleChecks(b) {
  for (const r of b.regiments) {
    if (!alive(r) || r.state === "rout") continue;
    if (r.morale < K.rout) {
      r.state = "rout";
      r.engaged = null;
      for (const o of b.regiments) if (o !== r && alive(o) && o.side === r.side && dist(o, r) < 120) o.morale -= 8;
      for (const o of b.regiments) if (alive(o) && o.side !== r.side && dist(o, r) < 150) o.morale += 6;
    }
  }
}
function checkEnd(b) {
  const standing = (side) => b.regiments.some((r) => r.side === side && fighting(r));
  if (!standing("a")) return "d";
  if (!standing("d")) return "a";
  if (b.tick >= TIME_LIMIT) return "d";
  return null;
}
function stepBattle(b, ticks = 1) {
  for (let i = 0; i < ticks && !b.result; i += 1) {
    b.tick += 1;
    for (const r of b.regiments) stepRegiment(b, r, TICK);
    const live = b.regiments.filter(alive).filter((r) => TROOPS[r.type].kind !== "air");
    for (let p = 0; p < live.length; p += 1) for (let q = p + 1; q < live.length; q += 1) {
      const a = live[p];
      const c = live[q];
      const d = dist(a, c);
      const min = (frontage(a).d + frontage(c).d) / 2 + 2;
      if (d > 0 && d < min) {
        const push = (min - d) / 2;
        a.x += (a.x - c.x) / d * push;
        a.y += (a.y - c.y) / d * push;
        c.x -= (a.x - c.x) / d * push;
        c.y -= (a.y - c.y) / d * push;
      }
    }
    moraleChecks(b);
    if (b.fx.length > 80) b.fx.splice(0, b.fx.length - 80);
    const end = checkEnd(b);
    if (end) b.result = { winner: end };
  }
  return b.result?.winner ?? null;
}
function validateBattleOrder(b, side, order) {
  const r = b.regiments.find((x) => x.id === order?.regiment);
  if (!r || r.side !== side || !alive(r)) return { error: "NOT_YOUR_UNIT" };
  if (r.state === "rout") return { error: "ROUTING" };
  const num = (v) => typeof v === "number" && Number.isFinite(v);
  switch (order.kind) {
    case "move":
      if (!Number.isFinite(order.x) || !Number.isFinite(order.y)) return { error: "BAD_COMMAND" };
      return { r, value: { kind: "move", x: clamp2(order.x, -FIELD.w / 2, FIELD.w / 2), y: clamp2(order.y, -FIELD.h / 2, FIELD.h / 2), run: Boolean(order.run) } };
    case "attack": {
      const t = b.regiments.find((x) => x.id === order.target);
      if (!t || t.side === side || !alive(t)) return { error: "NO_TARGET" };
      return { r, value: { kind: "attack", target: t.id, run: Boolean(order.run), keep: TROOPS[r.type].range && !order.melee ? TROOPS[r.type].range * 0.8 : 0 } };
    }
    case "hold":
      return { r, value: { kind: "hold" } };
    case "formation":
      if (!FORMATIONS[order.formation] || TROOPS[r.type].kind !== "foot") return { error: "BAD_COMMAND" };
      return { r, value: null, formation: order.formation };
    default:
      return { error: "BAD_COMMAND" };
  }
}
function applyRegimentOrder(validated) {
  if (validated.formation) validated.r.formation = validated.formation;
  else validated.r.order = validated.value;
}
function orderRegiment(b, side, order) {
  const validated = validateBattleOrder(b, side, order);
  if (validated.error) return validated.error;
  applyRegimentOrder(validated);
  return null;
}
function finishBattle(state, map, captureCity2) {
  const b = state.battle;
  if (!b?.result) return null;
  const won = b.result.winner === "a";
  for (const r of b.regiments) {
    if (!r.unitId) continue;
    const u = state.units[r.unitId];
    if (!u) continue;
    const share = r.men / r.menMax;
    if (r.men === 0 || share < 0.1) removeUnit(state, u.id);
    else {
      u.hp = Math.max(5, Math.round(share * 100));
      if (r.side === "a" === won) u.vet = Math.min(VETERAN_MAX, (u.vet ?? 0) + 1);
    }
  }
  const cell = b.defender.cell;
  const cityId = state.cityAt[cell];
  const city = cityId && state.cities[cityId].owner !== b.attacker.owner ? state.cities[cityId] : null;
  if (city) {
    const militia = b.regiments.find((r) => r.type === "militia");
    city.hp = won ? 0 : Math.max(5, Math.round(100 * (militia ? militia.men / militia.menMax : 0.5)));
  }
  const lead = state.units[b.attacker.unitId] ?? b.regiments.filter((r) => r.side === "a" && r.men > 0 && state.units[r.unitId] && UNITS[state.units[r.unitId].type].domain === "land").map((r) => state.units[r.unitId])[0];
  let captured = false;
  if (won && lead && UNITS[lead.type].domain === "land") {
    for (const id of [...unitsAt(state, cell)]) if (state.units[id].owner !== lead.owner) removeUnit(state, id);
    if (city) {
      captureCity2(state, map, lead, city);
      captured = city.owner === lead.owner;
    } else placeUnit(state, lead, cell);
  }
  const losses = (side) => b.regiments.filter((r) => r.side === side).reduce((s, r) => s + (r.menStart - r.men), 0);
  const audience = [b.attacker.owner, b.defender.owner].filter((x) => x && !isNeutralId(x));
  const combat = { tactical: true, from: b.attacker.from, to: cell, attackerOwner: b.attacker.owner, defenderOwner: b.defender.owner, won, captured, lossesA: losses("a"), lossesD: losses("d"), seconds: Math.round(b.tick * TICK) };
  pushEvent(state, won ? "battleWon" : "battleLost", { attacker: b.attacker.name, defender: b.defender.name }, audience, { combat });
  state.battle = null;
  return combat;
}
function battleView(b, { terrain = b?.tick === 0 } = {}) {
  if (!b) return null;
  return {
    // рельеф неизменен весь бой: по умолчанию он уходит только до первого тика (12 КБ → ~3 КБ на кадр)
    id: b.id,
    tick: b.tick,
    seconds: Math.round(b.tick * TICK),
    timeLimit: TIME_LIMIT * TICK,
    field: FIELD,
    terrain: terrain ? b.terrain : null,
    city: b.city,
    attacker: b.attacker,
    defender: b.defender,
    human: b.human,
    result: b.result,
    auto: Boolean(b.auto),
    regiments: b.regiments.map((r) => ({
      id: r.id,
      side: r.side,
      owner: r.owner,
      type: r.type,
      era: r.era ?? 0,
      men: r.men,
      menStart: r.menStart,
      menMax: r.menMax,
      x: Math.round(r.x * 10) / 10,
      y: Math.round(r.y * 10) / 10,
      facing: Math.round(r.facing * 1e3) / 1e3,
      formation: r.formation,
      state: r.state,
      morale: Math.round(r.morale),
      fatigue: Math.round(r.fatigue),
      ammo: r.ammo,
      engaged: r.engaged,
      order: r.order?.kind ?? "hold",
      target: r.order?.target ?? null,
      aim: r.aim ?? null,
      range: TROOPS[r.type].range ?? 0,
      kills: r.kills,
      ...frontage(r),
      dest: r.order?.kind === "move" ? [Math.round(r.order.x), Math.round(r.order.y)] : null,
      run: Boolean(r.order?.run)
    })),
    fx: b.fx.slice(-40)
  };
}

// src/game/commands.js
var ok = (extra = {}) => ({ ok: true, ...extra });
var fail = (error) => ({ ok: false, error });
var MIN_CITY_DISTANCE = 3;
var ANNEX_RELATION = 60;
var annexCost = (cities, ownCities = 0) => Math.round((50 + 40 * cities) * (1 + ownCities / 12));
var INTEGRATION_TURNS = 5;
function citySiteBlocker(state, map, nationId, cell) {
  const code = map.terrain[cell];
  if (isWater(code) || code === "I") return "BAD_CITY_SITE";
  if (state.owner[cell] && state.owner[cell] !== nationId) return "BAD_CITY_SITE";
  for (const c of cellsWithin(map, cell, MIN_CITY_DISTANCE - 1)) {
    if (state.cityAt[c]) return "TOO_CLOSE_TO_CITY";
  }
  return null;
}
var NATION_CULTURE = { borea: "northern", cartel: "coastal", meridian: "highland", auris: "desert" };
var realGuard2 = null;
function newCityName(state, nation) {
  const forbidden = new Set(Object.values(state.cities).map((c) => c.name.toLowerCase()));
  realGuard2 ??= createRealNameGuard(loadStopList());
  const namer = createNamer(state, { forbidden, tooReal: realGuard2 });
  return namer.city(NATION_CULTURE[nation.id] ?? "coastal");
}
function foundCity(state, map, nationId, unit) {
  if (unit.type !== "settler") return fail("NOT_SETTLER");
  const blocker = citySiteBlocker(state, map, nationId, unit.cell);
  if (blocker) return fail(blocker);
  const nation = state.nations[nationId];
  const capital = !Object.values(state.cities).some((c) => c.owner === nationId);
  const city = addCity(state, map, nationId, unit.cell, newCityName(state, nation), { capital });
  if (capital) {
    nation.capital = city.id;
    nation.originalCapital ??= city.id;
  }
  removeUnit(state, unit.id);
  pushEvent(state, "cityFounded", { nation: nation.name, city: city.name });
  return ok({ cityId: city.id });
}
function resolveAttack(state, map, attacker, cell) {
  const odds = attackOdds(state, map, attacker, cell);
  const roll = nextRandom(state);
  const cityId = state.cityAt[cell];
  const city = cityId ? state.cities[cityId] : null;
  const defenderOwner = city && city.owner !== attacker.owner ? city.owner : state.units[unitsAt(state, cell).find((id) => state.units[id].owner !== attacker.owner)]?.owner;
  const attackerName = `${UNITS[attacker.type].name} (${nameOf(state, attacker.owner)})`;
  const defenderName = city ? city.name : nameOf(state, defenderOwner);
  const audience = [attacker.owner, defenderOwner].filter((x) => x && !isNeutralId(x));
  const front = unitsAt(state, cell).map((id) => state.units[id]).filter((u) => u.owner !== attacker.owner).sort((a, b) => defenderStrength(state, map, b) - defenderStrength(state, map, a) || a.id.localeCompare(b.id))[0];
  const combat = {
    from: attacker.cell,
    to: cell,
    attacker: attacker.type,
    attackerOwner: attacker.owner,
    attackerId: attacker.id,
    defender: front?.type ?? null,
    defenderOwner: defenderOwner ?? null,
    city: city?.name ?? null,
    odds: Math.round(odds * 100),
    hpBefore: attacker.hp,
    cityHpBefore: city?.hp ?? null
  };
  attacker.moves = 0;
  attacker.fortified = false;
  if (roll < odds) {
    attacker.hp = Math.max(5, attacker.hp - Math.round(10 + 50 * (1 - odds)));
    attacker.vet = Math.min(VETERAN_MAX, (attacker.vet ?? 0) + 1);
    if (city) {
      city.hp = Math.max(0, city.hp - Math.round(35 + 30 * odds));
      for (const id of [...unitsAt(state, cell)]) if (state.units[id].owner === city.owner && UNITS[state.units[id].type].str > 0) {
        removeUnit(state, id);
        break;
      }
      if (city.hp === 0 && UNITS[attacker.type].domain === "land") captureCity(state, map, attacker, city);
    } else {
      const defenders = unitsAt(state, cell).map((id) => state.units[id]).filter((u) => u.owner !== attacker.owner).sort((a, b) => defenderStrength(state, map, b) - defenderStrength(state, map, a) || a.id.localeCompare(b.id));
      if (defenders.length) removeUnit(state, defenders[0].id);
      for (const u of defenders.slice(1)) u.hp = Math.max(10, u.hp - 20);
      const left = unitsAt(state, cell).some((id) => state.units[id].owner !== attacker.owner);
      if (!left && UNITS[attacker.type].domain !== "air" && canEnter(state, map, attacker, cell)) placeUnit(state, attacker, cell);
    }
    combat.won = true;
    combat.attackerHp = attacker.hp;
    combat.cityHp = city ? city.hp : null;
    combat.captured = Boolean(city && city.owner === attacker.owner);
    combat.killed = front ? !state.units[front.id] : false;
    pushEvent(state, "battleWon", { attacker: attackerName, defender: defenderName }, audience, { combat });
    return { won: true, odds, combat };
  }
  if (UNITS[attacker.type].domain === "air" || attacker.hp <= 40) removeUnit(state, attacker.id);
  else attacker.hp = Math.max(5, attacker.hp - 45);
  combat.won = false;
  combat.attackerHp = state.units[attacker.id] ? attacker.hp : 0;
  combat.cityHp = city ? city.hp : null;
  combat.killed = false;
  pushEvent(state, "battleLost", { attacker: attackerName, defender: defenderName }, audience, { combat });
  return { won: false, odds, combat };
}
function captureCity(state, map, attacker, city) {
  const previous = city.owner;
  for (const id of [...unitsAt(state, city.cell)]) if (state.units[id].owner === previous) removeUnit(state, id);
  city.owner = attacker.owner;
  city.hp = 40;
  city.queue = [];
  city.pop = Math.max(1, city.pop - 1);
  const wasCapital = city.capital;
  const winner = state.nations[attacker.owner];
  city.capital = Boolean(winner && winner.originalCapital === city.id);
  if (city.capital) {
    for (const c of Object.values(state.cities)) if (c.owner === attacker.owner && c !== city) c.capital = false;
    winner.capital = city.id;
  }
  city.occupiedUntil = city.capital ? 0 : state.turn + OCCUPATION_TURNS;
  if (wasCapital && !isNeutralId(previous) && state.nations[previous]) {
    const next = Object.values(state.cities).filter((c) => c.owner === previous).sort((a, b) => b.pop - a.pop || a.id.localeCompare(b.id))[0];
    state.nations[previous].capital = next ? next.id : null;
    if (next) next.capital = true;
  }
  for (const cell of cellsWithin(map, city.cell, 2)) {
    if (state.owner[cell] === previous) state.owner[cell] = attacker.owner;
  }
  placeUnit(state, attacker, city.cell);
  pushEvent(state, "cityCaptured", { nation: nameOf(state, attacker.owner), city: city.name });
  if (!isNeutralId(previous)) remember(state, previous, attacker.owner, "grievance", 15, "cityLost");
  if (isNeutralId(previous) && !Object.values(state.cities).some((c) => c.owner === previous)) state.neutrals[previous].alive = false;
  if (!isNeutralId(previous)) {
    const n = state.nations[previous];
    if (!Object.values(state.cities).some((c) => c.owner === previous) && !Object.values(state.units).some((u) => u.owner === previous && u.type === "settler")) {
      n.alive = false;
      for (const u of Object.values(state.units)) if (u.owner === previous) removeUnit(state, u.id);
      pushEvent(state, "eliminated", { nation: n.name });
    }
  }
}
function combatPreview(state, map, unit, to) {
  if (typeof to !== "number" || !Number.isSafeInteger(to) || to < 0 || to >= map.size) return fail("NO_TARGET");
  if (!map.neighbors[unit.cell].includes(to)) return fail("NO_TARGET");
  const enemy = enemyOwnerAt(state, unit, to);
  if (!enemy) return fail("NO_TARGET");
  if (UNITS[unit.type].str === 0) return fail("NO_TARGET");
  const cityId = state.cityAt[to];
  const city = cityId && state.cities[cityId].owner !== unit.owner ? state.cities[cityId] : null;
  const defenders = unitsAt(state, to).map((id) => state.units[id]).filter((u) => u.owner !== unit.owner).sort((a, b) => defenderStrength(state, map, b) - defenderStrength(state, map, a) || a.id.localeCompare(b.id));
  const odds = attackOdds(state, map, unit, to);
  const attack = unitStrength(state, unit);
  const defense = odds > 0 && odds < 1 ? attack * (1 - odds) / odds : 0;
  const mods = [];
  if (unit.vet) mods.push({ side: "a", text: `\u0432\u0435\u0442\u0435\u0440\u0430\u043D \xD7${(1 + 0.1 * unit.vet).toFixed(1)}` });
  if (unit.hp < 100) mods.push({ side: "a", text: `\u0440\u0430\u043D\u0435\u043D: ${unit.hp}%` });
  const terrain = TERRAIN[map.terrain[to]];
  if (terrain.defense !== 1) mods.push({ side: "d", text: `\u043C\u0435\u0441\u0442\u043D\u043E\u0441\u0442\u044C \xD7${terrain.defense}` });
  if (city?.buildings.includes("walls")) mods.push({ side: "d", text: "\u0441\u0442\u0435\u043D\u044B +50%" });
  if (city) mods.push({ side: "d", text: `\u0433\u043E\u0440\u043E\u0434, \u043F\u0440\u043E\u0447\u043D\u043E\u0441\u0442\u044C ${city.hp}%` });
  if (defenders[0]?.fortified) mods.push({ side: "d", text: "\u0443\u043A\u0440\u0435\u043F\u0438\u043B\u0441\u044F +25%" });
  if (defenders.length > 1) mods.push({ side: "d", text: `\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0441\u0442\u0435\u043A\u0430: ${defenders.length - 1}` });
  if (isEmbarked(map, unit)) return fail("EMBARKED");
  return ok({
    preview: {
      tactical: Boolean(state.nations[unit.owner]?.human && isTacticalType(unit.type)),
      odds: Math.round(odds * 100),
      attack: Math.round(attack * 10) / 10,
      defense: Math.round(defense * 10) / 10,
      attacker: unit.type,
      defender: defenders[0]?.type ?? null,
      defenderOwner: enemy,
      city: city?.name ?? null,
      atWar: atWar(state, unit.owner, enemy),
      mods
    }
  });
}
function advanceUnit(state, map, unit) {
  if (unit.goal === null || unit.goal === void 0) return { moved: 0 };
  let moved = 0;
  let guard = 0;
  while (unit.moves > 0 && unit.cell !== unit.goal && guard < 40) {
    guard += 1;
    const path2 = findPath(state, map, unit, unit.goal, { allowEnemyAt: unit.goal });
    if (!path2 || !path2.length) {
      unit.goal = null;
      return { moved, error: "NO_PATH" };
    }
    const step = path2[0];
    if (blockedFor(state, unit, step)) {
      const enemy = enemyOwnerAt(state, unit, step);
      if (!enemy) {
        unit.goal = null;
        return { moved, error: "CELL_OCCUPIED" };
      }
      if (UNITS[unit.type].str === 0) {
        unit.goal = null;
        return { moved, error: "CELL_OCCUPIED" };
      }
      if (isEmbarked(map, unit)) {
        unit.goal = null;
        return { moved, error: "EMBARKED" };
      }
      if (!atWar(state, unit.owner, enemy)) {
        if (isNeutralId(enemy)) declareWar(state, unit.owner, enemy);
        else {
          unit.goal = null;
          return { moved, error: "NOT_AT_WAR" };
        }
      }
      const result = resolveAttack(state, map, unit, step);
      if (state.units[unit.id]) unit.goal = null;
      return { moved, attacked: true, ...result };
    }
    const cost = moveCost(map, step, unit, unit.cell);
    unit.moves = cost >= unit.moves ? 0 : unit.moves - cost;
    placeUnit(state, unit, step);
    unit.fortified = false;
    moved += 1;
  }
  if (unit.cell === unit.goal) unit.goal = null;
  return { moved };
}
function enemyOwnerAt(state, unit, cell) {
  const cityId = state.cityAt[cell];
  if (cityId && state.cities[cityId].owner !== unit.owner) return state.cities[cityId].owner;
  const other = unitsAt(state, cell).map((id) => state.units[id]).find((u) => u.owner !== unit.owner);
  return other?.owner ?? null;
}
function buyPrice(state, map, city) {
  const item = city.queue[0];
  if (!item || item.kind === "dome" || item.kind === "project") return Infinity;
  const left = Math.max(0, itemCost(state, map, city, item) - city.prod);
  const space = item.kind === "unit" && UNITS[item.id].domain === "space";
  return Math.ceil(left * (space ? 3 : 2));
}
var isMajor = (state, id) => own(state.nations, id);
var isPeople = (state, id) => own(state.neutrals, id);
function applyCommand(state, nationId, command, map = loadMap()) {
  try {
    if (state.status !== "running") return fail("GAME_OVER");
    if (!isMajor(state, nationId) || !state.nations[nationId].alive) return fail("UNKNOWN_NATION");
    if (command === null || typeof command !== "object" || Array.isArray(command) || typeof command.kind !== "string") return fail("BAD_COMMAND");
    return dispatch(state, nationId, command, map);
  } catch (error) {
    if (process.env.KUPOL_DEBUG) console.error(error);
    return fail("BAD_COMMAND");
  }
}
function dispatch(state, nationId, command, map) {
  const nation = state.nations[nationId];
  const unit = own(state.units, command.unitId) ? state.units[command.unitId] : null;
  const city = own(state.cities, command.cityId) ? state.cities[command.cityId] : null;
  const needUnit = () => unit && unit.owner === nationId ? null : fail("NOT_YOUR_UNIT");
  const needCity = () => city && city.owner === nationId ? null : fail("NOT_YOUR_CITY");
  const target = typeof command.target === "string" ? command.target : null;
  const knownTarget = isMajor(state, target) || isPeople(state, target);
  const targetAlive = (id) => isMajor(state, id) ? state.nations[id].alive : isPeople(state, id) ? state.neutrals[id].alive : false;
  if (state.battle && !command.kind.startsWith("battle")) return fail("BATTLE_ACTIVE");
  switch (command.kind) {
    case "battle": {
      const e = needUnit();
      if (e) return e;
      if (!nation.human) return fail("BAD_COMMAND");
      if (!isTacticalType(unit.type) || UNITS[unit.type].str === 0 || unit.moves <= 0) return fail("NO_TARGET");
      const to = command.to;
      if (typeof to !== "number" || !Number.isSafeInteger(to) || to < 0 || to >= map.size || !map.neighbors[unit.cell].includes(to)) return fail("NO_TARGET");
      const enemy = enemyOwnerAt(state, unit, to);
      if (!enemy) return fail("NO_TARGET");
      if (!atWar(state, nationId, enemy)) {
        if (!isNeutralId(enemy)) return fail("NOT_AT_WAR");
        declareWar(state, nationId, enemy);
      }
      return ok({ battle: battleView(startBattle(state, map, unit, to)) });
    }
    case "battleOrder": {
      if (!state.battle) return fail("NO_BATTLE");
      const orders = Array.isArray(command.orders) ? command.orders : [command];
      if (orders.length > 40) return fail("BAD_COMMAND");
      const checked = orders.map((o) => validateBattleOrder(state.battle, state.battle.human, o));
      const invalid = checked.find((x) => x.error);
      if (invalid) return fail(invalid.error);
      for (const o of orders) orderRegiment(state.battle, state.battle.human, o);
      return ok({ battle: battleView(state.battle) });
    }
    case "battleAdvance": {
      if (!state.battle) return fail("NO_BATTLE");
      const ticks = Number.isInteger(command.ticks) ? Math.max(1, Math.min(20, command.ticks)) : 1;
      if (command.auto === true) state.battle.auto = true;
      stepBattle(state.battle, state.battle.auto ? 1e5 : ticks);
      const view = battleView(state.battle);
      const combat = state.battle.result ? finishBattle(state, map, captureCity) : null;
      return ok({ battle: view, finished: Boolean(combat), combat });
    }
    case "battleRetreat": {
      if (!state.battle) return fail("NO_BATTLE");
      for (const r of state.battle.regiments) if (r.side === state.battle.human && r.men > 0) r.state = "fled";
      state.battle.result = { winner: state.battle.human === "a" ? "d" : "a", retreat: true };
      const view = battleView(state.battle);
      return ok({ battle: view, finished: true, combat: finishBattle(state, map, captureCity) });
    }
    case "research": {
      if (!availableTechs(state, nationId).includes(command.tech)) return fail("TECH_UNAVAILABLE");
      nation.research = command.tech;
      return ok();
    }
    case "produce": {
      const e = needCity();
      if (e) return e;
      const item = command.item;
      if (item === null || typeof item !== "object" || !["unit", "building", "dome", "project"].includes(item.kind)) return fail("ITEM_UNAVAILABLE");
      if (item.kind !== "dome" && typeof item.id !== "string") return fail("ITEM_UNAVAILABLE");
      if (city.queue.length >= 8 && command.append) return fail("QUEUE_FULL");
      if (command.append && item.kind === "building" && city.queue.some((q) => q.kind === "building" && q.id === item.id)) return fail("ITEM_UNAVAILABLE");
      const blocker = itemBlocker(state, map, city, item);
      if (blocker) return fail(blocker);
      if (command.append) city.queue.push({ kind: item.kind, id: item.id ?? null });
      else city.queue = [{ kind: item.kind, id: item.id ?? null }];
      return ok();
    }
    case "buy": {
      const e = needCity();
      if (e) return e;
      const item = city.queue[0];
      if (!item || item.kind === "dome" || item.kind === "project") return fail("ITEM_UNAVAILABLE");
      const price = buyPrice(state, map, city);
      if (nation.gold < price) return fail("NOT_ENOUGH_GOLD");
      nation.gold -= price;
      city.prod = itemCost(state, map, city, item);
      return ok({ price });
    }
    case "move": {
      const e = needUnit();
      if (e) return e;
      const to = command.to;
      if (typeof to !== "number" || !Number.isSafeInteger(to) || to < 0 || to >= map.size) return fail("NO_PATH");
      if (UNITS[unit.type].domain === "space") return fail("NO_PATH");
      if (!canEnter(state, map, unit, to)) return fail("NO_PATH");
      unit.goal = to;
      const result = advanceUnit(state, map, unit);
      if (result.error && !result.moved && !result.attacked) return fail(result.error);
      return ok({ moved: result.moved, attacked: Boolean(result.attacked), won: result.won ?? null });
    }
    case "found": {
      const e = needUnit();
      if (e) return e;
      return foundCity(state, map, nationId, unit);
    }
    case "fortify": {
      const e = needUnit();
      if (e) return e;
      unit.fortified = true;
      unit.goal = null;
      unit.moves = 0;
      return ok();
    }
    case "disband": {
      const e = needUnit();
      if (e) return e;
      removeUnit(state, unit.id);
      return ok();
    }
    case "declareWar": {
      if (!knownTarget || !targetAlive(target) || target === nationId) return fail("UNKNOWN_NATION");
      if (isMajor(state, target) && !nation.met.includes(target)) return fail("NOT_MET");
      return declareWar(state, nationId, target);
    }
    case "proposePeace": {
      if (!knownTarget || !targetAlive(target)) return fail("UNKNOWN_NATION");
      if (!atWar(state, nationId, target)) return fail("NOT_AT_WAR");
      if (isNeutralId(target) || !state.nations[target].human) {
        if (!evaluatePeace(state, target, nationId)) return fail("REJECTED");
        makePeace(state, nationId, target);
        return ok();
      }
      return queueOffer(state, nationId, target, "peace");
    }
    case "propose": {
      const type = command.treaty;
      if (!own(TREATY_RULES, type)) return fail("BAD_COMMAND");
      if (isPeople(state, target)) return proposeToNeutral(state, map, nation, target, type);
      if (!isMajor(state, target) || !targetAlive(target) || target === nationId) return fail("UNKNOWN_NATION");
      if (!nation.met.includes(target)) return fail("NOT_MET");
      if (treatyBetween(state, nationId, target, type)) return fail("TREATY_EXISTS");
      if (atWar(state, nationId, target)) return fail("ALREADY_AT_WAR");
      const cost = treatyInfluenceCost(state, nationId, type);
      if (nation.influence < cost) return fail("NOT_ENOUGH_INFLUENCE");
      if (state.nations[target].human) {
        const q = queueOffer(state, nationId, target, type);
        if (q.queued && !q.duplicate) nation.influence -= cost;
        return q;
      }
      if (!evaluateTreaty(state, target, nationId, type).accept) return fail("REJECTED");
      nation.influence -= cost;
      addTreaty(state, nationId, target, type);
      return ok();
    }
    case "cancelTreaty": {
      const type = command.treaty;
      if (!knownTarget || !targetAlive(target)) return fail("UNKNOWN_NATION");
      if (!own(TREATY_RULES, type) || !treatyBetween(state, nationId, target, type)) return fail("NO_TREATY");
      removeTreaty(state, nationId, target, type, { broken: true, by: nationId });
      return ok();
    }
    case "respond": {
      const offer = state.offers.find((o) => o.id === command.offerId && o.to === nationId);
      if (!offer || !targetAlive(offer.from)) return fail("BAD_OFFER");
      const consume = () => {
        state.offers = state.offers.filter((o) => o !== offer);
      };
      const accept = command.accept === true;
      if (offer.type === "demand") {
        if (!accept) {
          consume();
          state.pendingThreats.push({ from: offer.from, to: nationId, turn: state.turn });
          changeRelation(state, nationId, offer.from, -15);
          return ok();
        }
        const blocker = executeDeal(state, map, nationId, offer.from, { give: offer.deal.take, take: normalizeSide({}) });
        if (blocker) return fail(blocker);
        consume();
        remember(state, nationId, offer.from, "grievance", 35, "extortion");
        return ok();
      }
      if (!accept) {
        consume();
        changeRelation(state, nationId, offer.from, -3);
        return ok();
      }
      if (offer.type === "deal") {
        const blocker = executeDeal(state, map, offer.from, nationId, offer.deal);
        if (blocker) return fail(blocker);
        consume();
        return ok();
      }
      if (offer.type === "peace") {
        if (!atWar(state, nationId, offer.from)) {
          consume();
          return fail("BAD_OFFER");
        }
        makePeace(state, nationId, offer.from);
        consume();
        return ok();
      }
      if (treatyBetween(state, nationId, offer.from, offer.type) || atWar(state, nationId, offer.from)) {
        consume();
        return fail("BAD_OFFER");
      }
      if (relation(state, offer.from, nationId) < TREATY_RULES[offer.type].minRelation - 10) {
        consume();
        return fail("RELATION_TOO_LOW");
      }
      addTreaty(state, offer.from, nationId, offer.type);
      consume();
      return ok();
    }
    case "gift": {
      const gold = typeof command.gold === "number" && Number.isFinite(command.gold) ? Math.floor(command.gold) : 0;
      if (!knownTarget || !targetAlive(target) || target === nationId) return fail("UNKNOWN_NATION");
      if (gold <= 0 || gold > nation.gold) return fail("NOT_ENOUGH_GOLD");
      nation.gold -= gold;
      if (isMajor(state, target)) {
        state.nations[target].gold += gold;
        remember(state, target, nationId, "favor", Math.min(30, gold / 5), "gift");
      }
      changeRelation(state, nationId, target, Math.min(isNeutralId(target) ? 8 : 20, gold / (isNeutralId(target) ? 8 : 5)));
      return ok();
    }
    case "annex": {
      const people = isPeople(state, target) ? state.neutrals[target] : null;
      if (!people || !people.alive) return fail("UNKNOWN_NATION");
      if (relation(state, nationId, target) < ANNEX_RELATION) return fail("RELATION_TOO_LOW");
      const cities = Object.values(state.cities).filter((c) => c.owner === target);
      const cost = annexCost(cities.length, Object.values(state.cities).filter((c) => c.owner === nationId).length);
      if (nation.influence < cost) return fail("NOT_ENOUGH_INFLUENCE");
      nation.influence -= cost;
      for (const c of cities) {
        c.owner = nationId;
        c.capital = false;
        c.occupiedUntil = state.turn + INTEGRATION_TURNS;
      }
      for (let cell = 0; cell < map.size; cell += 1) if (state.owner[cell] === target) state.owner[cell] = nationId;
      people.alive = false;
      pushEvent(state, "annexed", { nation: nation.name, people: people.name });
      return ok();
    }
    case "negotiate": {
      if (!isMajor(state, target) || !targetAlive(target) || target === nationId) return fail("UNKNOWN_NATION");
      if (!nation.met.includes(target)) return fail("NOT_MET");
      const deal = normalizeDeal(command.deal);
      const blocker = dealBlocker(state, nationId, target, deal);
      if (blocker) return fail(blocker);
      if (state.nations[target].human) return queueOffer(state, nationId, target, "deal", deal);
      const verdict = evaluateDeal(state, target, nationId, deal);
      if (verdict.accept) {
        const failed = executeDeal(state, map, nationId, target, deal);
        if (failed) return fail(failed);
        return ok({ reply: say(state, target, "acceptDeal", { target: nation.name }) });
      }
      const counter = counterOffer(state, target, nationId, deal, verdict.score);
      if (counter) return { ok: false, error: "COUNTER", counter, reply: say(state, target, "counter", { target: nation.name }) };
      return { ok: false, error: "REJECTED", reply: say(state, target, "rejectDeal", { target: nation.name }) };
    }
    case "demand": {
      if (!isMajor(state, target) || !targetAlive(target) || target === nationId) return fail("UNKNOWN_NATION");
      if (!nation.met.includes(target)) return fail("NOT_MET");
      if (atWar(state, nationId, target)) return fail("ALREADY_AT_WAR");
      const demandBlocked = demandBlocker(state, nationId, target);
      if (demandBlocked) return fail(demandBlocked);
      const take = normalizeSide(command.take);
      take.treaties = [];
      take.peace = false;
      take.joinWar = null;
      if (isEmptySide(take)) return fail("EMPTY_DEAL");
      const blocker = sideBlocker(state, target, nationId, take);
      if (blocker) return fail(blocker);
      if (state.nations[target].human) {
        state.lastDemand[`${nationId}>${target}`] = state.turn;
        nation.demandLog = (nation.demandLog ?? []).filter((t) => state.turn - t < 30);
        changeReputation(state, nationId, -5 * (1 + nation.demandLog.length));
        nation.demandLog.push(state.turn);
        return queueOffer(state, nationId, target, "demand", { give: normalizeSide({}), take });
      }
      const result = makeDemand(state, map, nationId, target, take);
      return { ok: true, ...result };
    }
    case "spy": {
      if (!isMajor(state, target) || !targetAlive(target)) return fail("UNKNOWN_NATION");
      const third = typeof command.third === "string" ? command.third : null;
      return runOperation(state, map, nationId, command.op, target, third);
    }
    case "odds": {
      const e = needUnit();
      if (e) return e;
      return combatPreview(state, map, unit, command.to);
    }
    case "nuke": {
      const e = needUnit();
      if (e) return e;
      return launchNuke(state, map, nationId, unit, command.to);
    }
    case "dismantle": {
      const e = needUnit();
      if (e) return e;
      return dismantle(state, nationId, unit);
    }
    case "recon": {
      const e = needUnit();
      if (e) return e;
      return orbitalRecon(state, map, nationId, unit, command.to);
    }
    case "choosePath":
      return choosePath(state, nationId, command.path);
    case "contribute":
      return contribute(state, nationId, command);
    default:
      return fail("BAD_COMMAND");
  }
}
var NEUTRAL_TRADE_RELATION = 10;
function proposeToNeutral(state, map, nation, target, type) {
  const people = state.neutrals[target];
  if (!people?.alive) return fail("UNKNOWN_NATION");
  if (type !== "trade") return fail("REJECTED");
  const known = Object.values(state.cities).some((c) => c.owner === target && state.explored[nation.id][c.cell]);
  if (!known) return fail("NOT_MET");
  if (treatyBetween(state, nation.id, target, "trade")) return fail("TREATY_EXISTS");
  if (atWar(state, nation.id, target)) return fail("ALREADY_AT_WAR");
  if (relation(state, nation.id, target) < NEUTRAL_TRADE_RELATION) return fail("RELATION_TOO_LOW");
  const cost = treatyInfluenceCost(state, nation.id, "trade");
  if (nation.influence < cost) return fail("NOT_ENOUGH_INFLUENCE");
  nation.influence -= cost;
  addTreaty(state, nation.id, target, "trade");
  return ok();
}
var OFFER_TITLES = { peace: "\u043C\u0438\u0440", deal: "\u0441\u0434\u0435\u043B\u043A\u0443", demand: "\u0443\u043B\u044C\u0442\u0438\u043C\u0430\u0442\u0443\u043C" };
function queueOffer(state, from, to, type, deal = null) {
  if (state.offers.some((o) => o.from === from && o.to === to && o.type === type)) return ok({ queued: true, duplicate: true });
  const id = `o${state.turn}-${from}-${type}`;
  const situation = type === "demand" ? "demandMade" : "greet";
  state.offers.push({ id, from, to, type, turn: state.turn, deal, reply: say(state, from, situation, { target: nameOf(state, to) }) });
  pushEvent(state, "offer", { from: nameOf(state, from), treaty: OFFER_TITLES[type] ?? TREATY_NAMES[type] }, [to]);
  return ok({ queued: true });
}

// src/game/ai.js
var INTERCEPTORS_NEEDED = Math.ceil(INTERCEPTOR_CAP / INTERCEPTOR_POWER);
var FOCUS_TECHS = {
  defense: ["bronze", "iron", "steel", "agriculture", "massProduction"],
  economy: ["agriculture", "wheel", "seafaring", "electricity", "massProduction", "networks"],
  diplomacy: ["writing", "agriculture", "radio", "networks", "computers"],
  science: ["writing", "steam", "computers", "rocketry", "satellites", "deepRadar"]
};
var ALWAYS = ["seafaring", "satellites", "deepRadar", "heavyLift", "kinetic", "shield"];
var BUILD_ORDER = {
  defense: ["walls", "granary", "barracks", "mine", "library", "port", "factory", "university", "airfield", "research", "datacenter", "observatory"],
  economy: ["granary", "mine", "port", "library", "factory", "datacenter", "university", "walls", "research", "airfield", "observatory"],
  diplomacy: ["granary", "library", "port", "mine", "university", "datacenter", "factory", "walls", "research", "observatory"],
  science: ["library", "granary", "mine", "university", "port", "research", "factory", "datacenter", "observatory", "walls"]
};
var sorted = (obj) => Object.keys(obj).sort().map((k) => obj[k]);
var isMilitary = (u) => UNITS[u.type].str > 0;
function memory(nation) {
  nation.aiMemory ??= { lastOffer: -99, campaign: null };
  return nation.aiMemory;
}
function chooseResearch(state, id) {
  const n = state.nations[id];
  if (n.research) return;
  const options = availableTechs(state, id);
  if (!options.length) return;
  const focus = FOCUS_TECHS[n.ai.focus] ?? [];
  const urgent = state.finale.detectedTurn ? ["heavyLift", "kinetic", "shield", "satellites"] : [];
  options.sort();
  const scores = new Map(options.map((t) => [t, techCost(state, id, t) * (focus.includes(t) ? 0.6 : 1) * (ALWAYS.includes(t) ? 0.7 : 1) * (urgent.includes(t) ? 0.2 : 1) * (t === "fission" ? 1.4 - aggressionOf(state, id) : 1) * (0.9 + nextRandom(state) * 0.2)]));
  options.sort((a, b) => scores.get(a) - scores.get(b) || a.localeCompare(b));
  applyCommand(state, id, { kind: "research", tech: options[0] });
}
function siteScore(state, map, id, cell) {
  let s = 0;
  for (const c of cellsWithin(map, cell, 1)) {
    const y = cellYield(state, map, c, id);
    s += y.food * 1.3 + y.prod + y.gold * 0.5;
    if (state.resourceAt[c]) s += 1.5;
  }
  if (map.coast[cell]) s += 1.5;
  return s;
}
function findSite(state, map, id, settler, reserved, ctx = {}) {
  const reach2 = cellsWithin(map, settler.cell, 14, (c) => canEnter(state, map, settler, c));
  let best = null;
  let bestScore = -Infinity;
  for (let i = 0; i < reach2.length; i += 1) {
    const cell = reach2[i];
    if (isWater(map.terrain[cell]) || reserved.has(cell)) continue;
    if (citySiteBlocker(state, map, id, cell)) continue;
    let score = siteScore(state, map, id, cell) - i * 0.02;
    if (ctx.wantSouth && Math.abs(map.cells[cell].lat) <= 35) score += 6;
    if (score > bestScore) {
      bestScore = score;
      best = cell;
    }
  }
  return bestScore >= 8 ? best : null;
}
function bestUnit(state, map, city, domain = "land") {
  const options = Object.entries(UNITS).filter(([uid, u]) => u.domain === domain && u.str > 0 && !itemBlocker(state, map, city, { kind: "unit", id: uid })).sort((a, b) => b[1].str - a[1].str || a[0].localeCompare(b[0]));
  return options[0]?.[0] ?? null;
}
function chooseProduction(state, map, id, city, ctx) {
  if (city.queue.length && (city.queue[0].kind === "dome" || city.queue[0].kind === "project")) city.queue = [];
  if (city.queue.length) return;
  const n = state.nations[id];
  const produce = (item) => applyCommand(state, id, { kind: "produce", cityId: city.id, item }, map).ok;
  const f = state.finale;
  if (f.detectedTurn && n.finale.path === "pact") {
    if (city.buildings.includes("spaceport")) {
      if (!f.tracking && ctx.pactSatellites < 3 && produce({ kind: "unit", id: "satellite" })) {
        ctx.pactSatellites += 1;
        return;
      }
      if (ctx.pactInterceptors < INTERCEPTORS_NEEDED && produce({ kind: "unit", id: "interceptor" })) {
        ctx.pactInterceptors += 1;
        return;
      }
    } else if (ctx.spaceports < ctx.spaceportTarget && produce({ kind: "building", id: "spaceport" })) {
      ctx.spaceports += 1;
      return;
    }
    if (!f.tracking && !ctx.observatory && produce({ kind: "building", id: "observatory" })) {
      ctx.observatory = true;
      return;
    }
    if (produce({ kind: "dome" })) return;
  }
  if (f.detectedTurn && n.finale.path === "ark" && city.capital && produce({ kind: "building", id: "ark" })) return;
  const garrison = unitsAt(state, city.cell).some((uid) => state.units[uid].owner === id && isMilitary(state.units[uid]));
  if (!garrison && !ctx.garrisonQueued.has(city.id)) {
    const u = bestUnit(state, map, city);
    if (u && produce({ kind: "unit", id: u })) {
      ctx.garrisonQueued.add(city.id);
      return;
    }
  }
  if (ctx.settlerSlots > 0 && ctx.cities < ctx.cityTarget && (city.pop >= 2 || ctx.cities === 1) && produce({ kind: "unit", id: "settler" })) {
    ctx.settlerSlots -= 1;
    return;
  }
  if (ctx.military < ctx.militaryTarget) {
    const sea = map.coast[city.cell] && nextRandom(state) < 0.15 ? bestUnit(state, map, city, "sea") : null;
    const air = nextRandom(state) < 0.2 ? bestUnit(state, map, city, "air") : null;
    const u = sea ?? air ?? bestUnit(state, map, city);
    if (u && produce({ kind: "unit", id: u })) {
      ctx.military += 1;
      return;
    }
  }
  if (ctx.nukeTarget > ctx.warheads && city.capital && n.finale.path !== "pact") {
    if (!city.buildings.includes("silo")) {
      if (produce({ kind: "building", id: "silo" })) return;
    } else if (produce({ kind: "unit", id: "icbm" })) {
      ctx.warheads += 1;
      return;
    }
  }
  if (map.coast[city.cell] && ctx.ships < ctx.shipTarget) {
    const ship = bestUnit(state, map, city, "sea");
    if (ship && produce({ kind: "unit", id: ship })) {
      ctx.ships += 1;
      return;
    }
  }
  if (n.era >= 3 && Math.abs(map.cells[city.cell].lat) <= 35 && !ctx.hasSpaceport && produce({ kind: "building", id: "spaceport" })) {
    ctx.hasSpaceport = true;
    return;
  }
  if (n.era >= 3 && city.buildings.includes("spaceport") && nextRandom(state) < 0.3 && produce({ kind: "unit", id: "satellite" })) return;
  for (const b of BUILD_ORDER[n.ai.focus] ?? BUILD_ORDER.economy) {
    if (BUILDINGS[b] && produce({ kind: "building", id: b })) return;
  }
  if (ctx.military < ctx.militaryTarget * 1.5) {
    const u = bestUnit(state, map, city);
    if (u && produce({ kind: "unit", id: u })) {
      ctx.military += 1;
      return;
    }
  }
  produce({ kind: "project", id: n.ai.focus === "economy" ? "gold" : "science" });
}
function nearestEnemyCity(state, map, id, unit, enemies) {
  let best = null;
  let bestD = Infinity;
  for (const c of sorted(state.cities)) {
    if (!enemies.has(c.owner)) continue;
    const d = haversineKm(map.cells[unit.cell], map.cells[c.cell]);
    if (d < bestD && d < 2600) {
      bestD = d;
      best = c;
    }
  }
  return best;
}
function moveShip(state, map, id, unit, enemies) {
  const near = cellsWithin(map, unit.cell, 6, (c) => canEnter(state, map, unit, c) || Boolean(state.cityAt[c]));
  if (enemies.size) {
    const target = near.find((c) => c !== unit.cell && ((state.unitsByCell[c] ?? []).some((uid) => enemies.has(state.units[uid].owner)) || state.cityAt[c] && enemies.has(state.cities[state.cityAt[c]].owner)));
    if (target !== void 0 && attackOdds(state, map, unit, target) >= 0.5) {
      applyCommand(state, id, { kind: "move", unitId: unit.id, to: target }, map);
      return;
    }
  }
  const seen = state.explored[id];
  if (unit.goal !== null && unit.goal !== void 0 && !seen[unit.goal]) {
    applyCommand(state, id, { kind: "move", unitId: unit.id, to: unit.goal }, map);
    return;
  }
  const far = cellsWithin(map, unit.cell, 14, (c) => canEnter(state, map, unit, c));
  const options = far.filter((c) => !seen[c]);
  if (!options.length) {
    if (!unit.fortified) applyCommand(state, id, { kind: "fortify", unitId: unit.id }, map);
    return;
  }
  const goal = options[Math.floor(nextRandom(state) * Math.min(options.length, 20))];
  applyCommand(state, id, { kind: "move", unitId: unit.id, to: goal }, map);
}
function moveUnits(state, map, id, ctx) {
  const reserved = new Set(sorted(state.units).filter((u) => u.owner === id && u.type === "settler" && u.goal !== null).map((u) => u.goal));
  const enemies = new Set([...majorIds(state), ...Object.keys(state.neutrals)].filter((x) => x !== id && atWar(state, id, x)));
  const mem = memory(state.nations[id]);
  if (mem.campaign && enemies.size === 0) mem.campaign = null;
  const cities = sorted(state.cities).filter((c) => c.owner === id);
  for (const unit of sorted(state.units)) {
    if (!state.units[unit.id] || unit.owner !== id || unit.moves <= 0) continue;
    const def = UNITS[unit.type];
    if (def.domain === "space") continue;
    if (unit.type === "settler") {
      if (!citySiteBlocker(state, map, id, unit.cell) && siteScore(state, map, id, unit.cell) >= 8 && (unit.goal === null || unit.goal === unit.cell)) {
        applyCommand(state, id, { kind: "found", unitId: unit.id }, map);
        continue;
      }
      if (unit.goal === null || citySiteBlocker(state, map, id, unit.goal)) {
        reserved.delete(unit.goal);
        const site = findSite(state, map, id, unit, reserved, ctx);
        if (site === null) {
          if (!citySiteBlocker(state, map, id, unit.cell)) applyCommand(state, id, { kind: "found", unitId: unit.id }, map);
          else if ((unit.idle = (unit.idle ?? 0) + 1) > 8) applyCommand(state, id, { kind: "disband", unitId: unit.id }, map);
          continue;
        }
        reserved.add(site);
        if (site === unit.cell) {
          applyCommand(state, id, { kind: "found", unitId: unit.id }, map);
          continue;
        }
        applyCommand(state, id, { kind: "move", unitId: unit.id, to: site }, map);
      } else {
        applyCommand(state, id, { kind: "move", unitId: unit.id, to: unit.goal }, map);
      }
      if (state.units[unit.id] && unit.cell === unit.goal) applyCommand(state, id, { kind: "found", unitId: unit.id }, map);
      continue;
    }
    if (!isMilitary(unit)) continue;
    const inCity = state.cityAt[unit.cell] && state.cities[state.cityAt[unit.cell]].owner === id;
    const garrisonHere = inCity ? unitsAt(state, unit.cell).filter((uid) => state.units[uid].owner === id && isMilitary(state.units[uid])) : [];
    const isLastGarrison = inCity && garrisonHere.length === 1;
    if (def.domain === "sea") {
      moveShip(state, map, id, unit, enemies);
      continue;
    }
    if (enemies.size && !isLastGarrison) {
      const target = nearestEnemyCity(state, map, id, unit, enemies);
      if (target) {
        if (hopDistance(map, unit.cell, target.cell, 1) === 1) {
          if (attackOdds(state, map, unit, target.cell) >= 0.45 || unit.hp > 90) applyCommand(state, id, { kind: "move", unitId: unit.id, to: target.cell }, map);
          else applyCommand(state, id, { kind: "fortify", unitId: unit.id }, map);
        } else {
          applyCommand(state, id, { kind: "move", unitId: unit.id, to: target.cell }, map);
        }
        continue;
      }
    }
    if (inCity && garrisonHere.length <= 2) {
      if (!unit.fortified) applyCommand(state, id, { kind: "fortify", unitId: unit.id }, map);
      continue;
    }
    const empty = cities.find((c) => !unitsAt(state, c.cell).some((uid) => state.units[uid].owner === id && isMilitary(state.units[uid])));
    if (empty && def.domain === "land") applyCommand(state, id, { kind: "move", unitId: unit.id, to: empty.cell }, map);
    else if (!unit.fortified) applyCommand(state, id, { kind: "fortify", unitId: unit.id }, map);
  }
  ctx.reserved = reserved;
}
function diplomacy(state, map, id) {
  const n = state.nations[id];
  const P = n.ai;
  const mem = memory(n);
  const f = state.finale;
  for (const other of n.met) {
    const o = state.nations[other];
    if (!o.alive) continue;
    const rel = attitude(state, id, other);
    if (atWar(state, id, other)) {
      const turns = state.turn - (state.warSince[pairKey(id, other)] ?? state.turn);
      const losing = militaryPower(state, id) < militaryPower(state, other);
      considerNuke(state, map, id, other);
      if (turns >= 8 && (losing || rel > -40) || f.detectedTurn) {
        if (!o.human || state.turn - mem.lastOffer >= 5) {
          const r = applyCommand(state, id, { kind: "proposePeace", target: other }, map);
          if (r.queued) mem.lastOffer = state.turn;
        }
      }
      continue;
    }
    const wants = [];
    const sore = memoryOf(state, id, other).log.some((e) => e.kind === "grievance" && e.amount >= 10 && state.turn - e.turn < 20);
    if (rel >= -10 && !treatyBetween(state, id, other, "trade")) wants.push("trade");
    if (rel >= 10 && !treatyBetween(state, id, other, "nap")) wants.push("nap");
    if (rel >= 25 && !treatyBetween(state, id, other, "research")) wants.push("research");
    if (rel >= 50 && !treatyBetween(state, id, other, "alliance")) wants.push("alliance");
    if (sore) wants.length = 0;
    for (const type of wants) {
      if (n.influence < treatyInfluenceCost(state, id, type)) break;
      if (o.human && state.turn - mem.lastOffer < 6) break;
      const r = applyCommand(state, id, { kind: "propose", target: other, treaty: type }, map);
      if (r.queued) {
        mem.lastOffer = state.turn;
        break;
      }
    }
    const strong = militaryPower(state, id) > militaryPower(state, other) * 1.4 + 10;
    const justified = hasCasusBelli(state, id, other);
    if (!f.detectedTurn && (rel < -45 || justified) && strong && (justified || !treatyBetween(state, id, other, "nap")) && nextRandom(state) < aggressionOf(state, id) * (justified ? 0.2 : 0.15) * (warheads(state, other) > warheads(state, id) ? 0.3 : 1)) {
      applyCommand(state, id, { kind: "declareWar", target: other }, map);
      continue;
    }
    if (tradeTechs(state, map, id, other, mem)) continue;
    if (!f.detectedTurn) maybeDemand(state, map, id, other, mem);
  }
  followThroughThreats(state, map, id);
  plot(state, map, id);
  const neighbors = /* @__PURE__ */ new Set();
  for (let cell = 0; cell < map.size; cell += 1) {
    if (state.owner[cell] !== id) continue;
    for (const nb of map.neighbors[cell]) {
      const o = state.owner[nb];
      if (o && isNeutralId(o) && state.neutrals[o].alive) neighbors.add(o);
    }
  }
  for (const pid of [...neighbors].sort()) {
    if (atWar(state, id, pid)) continue;
    if (relation(state, id, pid) >= 60) {
      applyCommand(state, id, { kind: "annex", target: pid }, map);
      continue;
    }
    if (n.gold > 200 && nextRandom(state) < 0.3) applyCommand(state, id, { kind: "gift", target: pid, gold: 40 }, map);
  }
  if (n.era >= 3) {
    const sellers = [...new Set(state.resourceCells.rare.map((c) => state.owner[c]).filter((o) => o && isNeutralId(o) && state.neutrals[o].alive))].sort();
    for (const pid of sellers) {
      if (atWar(state, id, pid) || treatyBetween(state, id, pid, "trade")) continue;
      if (!Object.values(state.cities).some((c) => c.owner === pid && state.explored[id][c.cell])) continue;
      if (relation(state, id, pid) < 10) {
        if (n.gold > 60) applyCommand(state, id, { kind: "gift", target: pid, gold: 40 }, map);
      } else applyCommand(state, id, { kind: "propose", target: pid, treaty: "trade" }, map);
      break;
    }
  }
  const mem2 = memory(n);
  if (!mem2.campaign && !f.detectedTurn && neighbors.size && nextRandom(state) < P.aggression * 0.04) {
    const target = [...neighbors].sort()[0];
    if (!atWar(state, id, target) && relation(state, id, target) < 30) {
      applyCommand(state, id, { kind: "declareWar", target }, map);
      mem2.campaign = target;
    }
  }
}
function tradeTechs(state, map, id, other, mem) {
  const n = state.nations[id];
  const o = state.nations[other];
  if (state.turn % 12 !== (id.length * 3 + other.length) % 12) return false;
  if (attitude(state, id, other) < 15) return false;
  if (o.human && state.turn - mem.lastOffer < 6) return false;
  const mine = n.techs.filter((t) => !o.techs.includes(t) && TECHS[t].era < 3 && techLearnable(o, t)).sort((a, b) => techCost(state, other, a) - techCost(state, other, b) || a.localeCompare(b));
  const theirs = o.techs.filter((t) => !n.techs.includes(t) && techLearnable(n, t)).sort((a, b) => techCost(state, id, b) - techCost(state, id, a) || a.localeCompare(b));
  if (!mine.length || !theirs.length) return false;
  const deal = { give: { techs: [mine[0]] }, take: { techs: [theirs[0]] } };
  const r = applyCommand(state, id, { kind: "negotiate", target: other, deal }, map);
  if (r.queued) mem.lastOffer = state.turn;
  if (!r.ok && r.error === "COUNTER" && r.counter.give.gold <= n.gold * 0.5 && !r.counter.give.techs.some((t) => t !== mine[0])) {
    applyCommand(state, id, { kind: "negotiate", target: other, deal: r.counter }, map);
  }
  return r.ok;
}
function maybeDemand(state, map, id, other, mem) {
  const n = state.nations[id];
  const o = state.nations[other];
  const t = traits(state, id);
  if (attitude(state, id, other) > 10) return;
  if (militaryPower(state, id) < militaryPower(state, other) * 2 + 20) return;
  if (nextRandom(state) >= aggressionOf(state, id) * 0.04 * (0.5 + t.pride)) return;
  if (demandBlocker(state, id, other)) return;
  if (o.human && state.turn - mem.lastOffer < 8) return;
  const tech = o.techs.find((x) => techLearnable(n, x));
  const take = o.gold >= 60 ? { gold: Math.min(200, Math.floor(o.gold * 0.5)) } : tech ? { techs: [tech] } : null;
  if (!take) return;
  if (!o.human && !evaluateDemand(state, other, id, take).accept && t.caution > 0.6) return;
  const r = applyCommand(state, id, { kind: "demand", target: other, take }, map);
  if (r.queued) mem.lastOffer = state.turn;
}
function followThroughThreats(state, map, id) {
  const t = traits(state, id);
  for (const th of state.pendingThreats ?? []) {
    if (th.from !== id || atWar(state, id, th.to) || state.turn - th.turn < 1) continue;
    const ratio = (militaryPower(state, id) + 1) / (militaryPower(state, th.to) + 1);
    if (ratio >= 1.5 && nextRandom(state) < 0.25 + t.pride * 0.35 + t.honor * 0.25) {
      applyCommand(state, id, { kind: "declareWar", target: th.to }, map);
    }
  }
}
function plot(state, map, id) {
  const n = state.nations[id];
  const t = traits(state, id);
  if (nextRandom(state) >= t.cunning * 0.04) return;
  const rivals = n.met.filter((x) => state.nations[x].alive && !treatyBetween(state, id, x, "alliance") && !treatyBetween(state, id, x, "research") && (t.cunning > 0.7 || !treatyBetween(state, id, x, "nap"))).sort((a, b) => {
    const score = (x) => state.nations[x].techs.length * 10 + state.nations[x].finale.contribution / 100 - attitude(state, id, x);
    return score(b) - score(a) || a.localeCompare(b);
  });
  const target = rivals[0];
  if (!target) return;
  const tgt = state.nations[target];
  const f = state.finale;
  const options = [];
  if (tgt.techs.some((x) => !n.techs.includes(x))) options.push(["stealTech", null]);
  if (f.detectedTurn && tgt.finale.path === "pact" && n.finale.path === "pact" && t.honor < 0.6) options.push(["sabotage", null]);
  if (!f.detectedTurn) options.push(["sabotage", null]);
  options.push(["smear", null]);
  const borderPeople = Object.values(state.neutrals).filter((p) => p.alive && (p.relations[target] ?? 0) > -60 && Object.values(state.cities).some((c) => c.owner === p.id && state.explored[id][c.cell])).map((p) => p.id).sort();
  if (borderPeople.length && f.detectedTurn === null) options.push(["incite", borderPeople[0]]);
  const third = rivals.find((x) => x !== target);
  if (third && t.cunning > 0.6) options.push(["falseFlag", third]);
  const usable = options.filter(([op2, extra2]) => !opBlocker(state, id, op2, target, extra2) && opChances(state, id, target, op2).exposure < 0.5 + t.cunning * 0.2);
  if (!usable.length) return;
  const [op, extra] = usable[Math.floor(nextRandom(state) * usable.length)];
  applyCommand(state, id, { kind: "spy", op, target, third: extra }, map);
}
function considerNuke(state, map, id, other) {
  const mine = sorted(state.units).filter((u) => u.owner === id && u.type === "icbm");
  if (!mine.length) return;
  const strikes = state.nuclear?.strikes ?? [];
  const revenge = strikes.some((x) => x.from === other && x.to === id && state.turn - x.turn <= 3);
  const turns = state.turn - (state.warSince[pairKey(id, other)] ?? state.turn);
  const desperate = militaryPower(state, id) * 1.5 < militaryPower(state, other) && turns >= 6 && memoryOf(state, id, other).log.some((e) => e.reason === "cityLost" && state.turn - e.turn <= 15);
  const aggr = aggressionOf(state, id);
  const firstStrike = desperate && aggr > 0.4 && interceptChance(state, other) < 0.3 && nextRandom(state) < 0.4 * aggr;
  if (!revenge && !firstStrike) return;
  const target = Object.values(state.cities).filter((c) => c.owner === other && state.explored[id][c.cell]).sort((a, b) => b.pop - a.pop || a.id.localeCompare(b.id))[0];
  if (!target) return;
  applyCommand(state, id, { kind: "nuke", unitId: mine[0].id, to: target.cell }, map);
}
function finaleDecisions(state, map, id) {
  const n = state.nations[id];
  const f = state.finale;
  if (!f.detectedTurn) return;
  if (!n.finale.path) {
    const others = majorIds(state).filter((x) => x !== id && state.nations[x].alive);
    const avg = others.length ? others.reduce((s, x) => s + relation(state, id, x), 0) / others.length : 0;
    const spacePower = Object.values(state.cities).some((c) => c.owner === id && c.buildings.includes("spaceport")) ? 0.15 : 0;
    const score = n.ai.coop + avg / 400 + (n.reputation - 50) / 400 + traits(state, id).honor * 0.1 + spacePower;
    applyCommand(state, id, { kind: "choosePath", path: score >= 0.45 && canJoinPact(state) ? "pact" : "ark" }, map);
  }
  if (n.finale.path !== "pact") return;
  for (const u of sorted(state.units)) if (u.owner === id && u.type === "icbm") applyCommand(state, id, { kind: "dismantle", unitId: u.id }, map);
  const projected = projectedDefense(state, id);
  const t = traits(state, id);
  const capital = Object.values(state.cities).some((c) => c.owner === id && c.capital);
  if (state.turn === f.detectedTurn + PATH_LOCK - 1 && projected < 0.4 && capital && n.techs.includes("heavyLift") && (n.ai.coop < 0.5 || t.pride > 0.75)) {
    applyCommand(state, id, { kind: "choosePath", path: "ark" }, map);
    return;
  }
  if (projected >= 1.1) return;
  const reserve = 60 + 5 * Object.values(state.cities).filter((c) => c.owner === id).length;
  if (n.gold > reserve + 20) applyCommand(state, id, { kind: "contribute", gold: Math.floor((n.gold - reserve) * 0.6) }, map);
  if (!n.research && n.sciencePool > 50) applyCommand(state, id, { kind: "contribute", science: Math.floor(n.sciencePool * 0.8) }, map);
}
function projectedDefense(state, id) {
  const f = state.finale;
  const mem = memory(state.nations[id]);
  if (!mem.shieldMark || mem.shieldMark.since !== f.detectedTurn) mem.shieldMark = { since: f.detectedTurn, turn: state.turn, shield: f.shield };
  const elapsed = Math.max(1, state.turn - mem.shieldMark.turn);
  const rate = Math.max(0, (f.shield - mem.shieldMark.shield) / elapsed);
  const shield = f.shield + rate * Math.max(0, f.impactTurn - state.turn);
  const level = defenseLevel(state);
  return level.tracking * (level.intercept + Math.min(SHIELD_CAP, shield / SHIELD_TARGET * SHIELD_CAP));
}
function runAi(state, map, id) {
  const n = state.nations[id];
  if (!n?.alive || n.human) return;
  chooseResearch(state, id);
  finaleDecisions(state, map, id);
  diplomacy(state, map, id);
  const cities = sorted(state.cities).filter((c) => c.owner === id);
  const units = sorted(state.units).filter((u) => u.owner === id);
  const settlers = units.filter((u) => u.type === "settler").length + cities.filter((c) => c.queue[0]?.id === "settler").length;
  const atWarAny = [...majorIds(state), ...Object.keys(state.neutrals)].some((x) => x !== id && atWar(state, id, x));
  const members = majorIds(state).filter((x) => state.nations[x].finale.path === "pact");
  const ctx = {
    cities: cities.length,
    cityTarget: Math.min(16, 6 + 2 * n.era),
    settlerSlots: Math.max(0, 1 + Math.floor(cities.length / 4) - settlers),
    military: units.filter(isMilitary).length,
    militaryTarget: Math.ceil(cities.length * (atWarAny ? 2.2 : 1.3)) + 1,
    garrisonQueued: /* @__PURE__ */ new Set(),
    ships: units.filter((u) => UNITS[u.type].domain === "sea").length + cities.filter((c) => c.queue[0] && UNITS[c.queue[0].id]?.domain === "sea").length,
    shipTarget: Math.ceil(cities.filter((c) => map.coast[c.cell]).length / 4) + (atWarAny ? 1 : 0),
    spaceports: cities.filter((c) => c.buildings.includes("spaceport") || c.queue[0]?.id === "spaceport").length,
    spaceportTarget: 2 + Math.floor(cities.length / 5),
    pactInterceptors: Object.values(state.units).filter((u) => u.type === "interceptor" && members.includes(u.owner)).length + Object.values(state.cities).filter((c) => members.includes(c.owner) && c.queue[0]?.id === "interceptor").length,
    hasSpaceport: cities.some((c) => c.buildings.includes("spaceport") || c.queue[0]?.id === "spaceport"),
    pactSatellites: Object.values(state.units).filter((u) => u.type === "satellite" && members.includes(u.owner)).length,
    observatory: Object.values(state.cities).some((c) => members.includes(c.owner) && (c.buildings.includes("observatory") || c.queue[0]?.id === "observatory"))
  };
  ctx.warheads = warheads(state, id) + cities.filter((c) => c.queue[0]?.id === "icbm").length;
  const nuked = (state.nuclear?.strikes ?? []).some((x) => x.to === id);
  const rivalNukes = n.met.some((o) => state.nations[o].alive && warheads(state, o) > 0 && (atWar(state, id, o) || relation(state, id, o) < -30));
  const aggr = aggressionOf(state, id);
  ctx.nukeTarget = !n.techs.includes("fission") || state.finale.detectedTurn ? 0 : (aggr >= 0.45 ? 2 : 0) + (aggr >= 0.6 ? 1 : 0) + (nuked || rivalNukes ? 1 : 0);
  ctx.wantSouth = n.era >= 1 && !cities.some((c) => Math.abs(map.cells[c.cell].lat) <= 35);
  for (const city of cities) chooseProduction(state, map, id, city, ctx);
  const reserve = 60 + cities.length * 5;
  const buyOrder = [...cities].sort((a, b) => buyPrice(state, map, a) - buyPrice(state, map, b) || a.id.localeCompare(b.id));
  for (const city of buyOrder) {
    const price = buyPrice(state, map, city);
    if (Number.isFinite(price) && price > 0 && n.gold - price >= reserve) applyCommand(state, id, { kind: "buy", cityId: city.id }, map);
  }
  moveUnits(state, map, id, ctx);
  orbitalScouting(state, map, id);
}
function orbitalScouting(state, map, id) {
  const enemies = state.nations[id].met.filter((o) => state.nations[o].alive && atWar(state, id, o)).sort();
  if (!enemies.length) return;
  const targets = Object.values(state.cities).filter((c) => enemies.includes(c.owner)).sort((a, b) => Number(Boolean(state.explored[id][a.cell])) - Number(Boolean(state.explored[id][b.cell])) || b.pop - a.pop || a.id.localeCompare(b.id));
  let i = 0;
  for (const u of sorted(state.units)) {
    if (u.owner !== id || u.type !== "satellite" || (u.reconReady ?? 0) > state.turn || i >= targets.length) continue;
    applyCommand(state, id, { kind: "recon", unitId: u.id, to: targets[i].cell }, map);
    i += 1;
  }
}

// src/game/turn.js
var MAX_TURNS = 230;
var SHIELD_TECH_BONUS = 0.5;
var UNIT_UPKEEP_FREE_PER_CITY = 2;
var AI_DIFFICULTY_MULTIPLIER = Object.freeze({ easy: 0.85, normal: 1, hard: 1.2 });
function aiMultiplier(state, nation) {
  return nation.human ? 1 : AI_DIFFICULTY_MULTIPLIER[state.difficulty] ?? 1;
}
var sortedValues = (obj) => Object.keys(obj).sort().map((k) => obj[k]);
function citiesOf(state, owner) {
  return sortedValues(state.cities).filter((c) => c.owner === owner);
}
function spawnCell(state, map, city, unitType) {
  const domain = UNITS[unitType].domain;
  const options = [city.cell, ...map.neighbors[city.cell]];
  for (const cell of options) {
    const water = isWater(map.terrain[cell]);
    if (domain === "sea" && !water && cell !== city.cell) continue;
    if (domain === "land" && water) continue;
    const occupants = (state.unitsByCell[cell] ?? []).map((id) => state.units[id]);
    if (occupants.some((u) => u.owner !== city.owner)) continue;
    const civilian = UNITS[unitType].civilian;
    if (occupants.filter((u) => Boolean(UNITS[u.type].civilian) === Boolean(civilian)).length === 0 || domain === "space") return cell;
  }
  return null;
}
function processCity(state, map, city, nation, totals) {
  const y = cityYield(state, map, city);
  const aiMult = aiMultiplier(state, nation);
  totals.gold += Math.round(y.gold * aiMult);
  totals.science += Math.round(y.science * aiMult);
  totals.influence += 1;
  if (isOccupied(state, city)) city.food = Math.min(city.food, growthThreshold(city.pop) - 1);
  else city.food += y.food - y.upkeep;
  if (city.food >= growthThreshold(city.pop)) {
    city.food -= growthThreshold(city.pop);
    city.pop = Math.min(20, city.pop + 1);
    if (city.pop === 5) claimAround(state, map, city.cell, city.owner, 2);
    else claimAround(state, map, city.cell, city.owner, city.pop >= 5 ? 2 : 1);
  } else if (city.food < 0) {
    if (city.pop > 1) city.pop -= 1;
    city.food = 0;
  }
  city.hp = Math.min(100, city.hp + 10);
  const item = city.queue[0];
  if (!item) return;
  if (itemBlocker(state, map, city, item)) {
    city.queue.shift();
    return;
  }
  if (item.kind === "dome") {
    const shieldTech = nation.techs.includes("shield") ? SHIELD_TECH_BONUS : 0;
    addShield(state, city.owner, y.prod * (1 + (DOCTRINES[nation.doctrine].domeBonus ?? 0) + shieldTech));
    return;
  }
  if (item.kind === "project") {
    if (item.id === "science") totals.science += y.prod * PROJECTS.science.rate;
    else totals.gold += y.prod * PROJECTS.gold.rate;
    return;
  }
  city.prod += Math.round(y.prod * aiMult);
  const cost = itemCost(state, map, city, item);
  if (city.prod < cost) return;
  if (item.kind === "unit") {
    const cell = spawnCell(state, map, city, item.id);
    if (cell === null) return;
    const unit = addUnit(state, city.owner, item.id, cell);
    if (city.buildings.includes("barracks") && UNITS[item.id].str > 0) unit.vet = 1;
    if (state.finale.detectedTurn && nation.finale.path === "pact" && (item.id === "interceptor" || item.id === "satellite")) {
      addContribution(state, city.owner, (UNITS[item.id].cost + cost) / 2, "launches");
    }
    if (item.id === "settler" && city.pop > 1) city.pop -= 1;
  } else {
    city.buildings.push(item.id);
    pushEvent(state, "built", { city: city.name, item: BUILDINGS[item.id].name }, [city.owner]);
  }
  city.prod -= cost;
  city.queue.shift();
}
function processNation(state, map, nation) {
  const totals = { gold: 0, science: 0, influence: 0 };
  for (const city of citiesOf(state, nation.id)) processCity(state, map, city, nation, totals);
  const doctrine = DOCTRINES[nation.doctrine];
  totals.influence += doctrine.influence ?? 0;
  for (const t of state.treaties) {
    if (t.type !== "trade" || t.a !== nation.id && t.b !== nation.id) continue;
    const partner = t.a === nation.id ? t.b : t.a;
    totals.gold += Math.min(6 + (doctrine.tradeRoutes ?? 0), citiesOf(state, partner).length);
  }
  const units = Object.values(state.units).filter((u) => u.owner === nation.id && UNITS[u.type].domain !== "space").length;
  const upkeep = Math.max(0, units - citiesOf(state, nation.id).length * UNIT_UPKEEP_FREE_PER_CITY);
  nation.gold = Math.max(0, nation.gold + totals.gold - upkeep);
  nation.influence += totals.influence;
  nation.sciencePool += totals.science;
  if (nation.research) {
    const cost = techCost(state, nation.id, nation.research);
    if (nation.sciencePool >= cost) {
      nation.sciencePool -= cost;
      const tech = nation.research;
      pushEvent(state, "techLearned", { nation: nation.name, tech: TECHS[tech].name }, nation.human ? [nation.id] : "all");
      grantTech(state, nation, tech);
    }
  }
}
function refreshUnits(state, map) {
  for (const unit of sortedValues(state.units)) {
    const def = UNITS[unit.type];
    unit.moves = def.moves;
    const home = state.owner[unit.cell] === unit.owner;
    unit.hp = Math.min(100, unit.hp + (home ? 20 : 10));
  }
  for (const unit of sortedValues(state.units)) {
    if (state.units[unit.id] && unit.goal !== null && unit.goal !== void 0) advanceUnit(state, map, unit);
  }
}
function updateContacts(state, map) {
  const ids = majorIds(state).filter((id) => state.nations[id].alive);
  for (const id of ids) {
    const seen = visibleCells(state, map, id);
    for (const other of ids) {
      if (other === id || state.nations[id].met.includes(other)) continue;
      let contact = false;
      for (const cell of seen) {
        if (state.owner[cell] === other || (state.unitsByCell[cell] ?? []).some((u) => state.units[u].owner === other)) {
          contact = true;
          break;
        }
      }
      if (contact) {
        state.nations[id].met.push(other);
        state.nations[id].met.sort();
        if (!state.nations[other].met.includes(id)) {
          state.nations[other].met.push(id);
          state.nations[other].met.sort();
        }
        pushEvent(state, "met", { a: state.nations[id].name, b: state.nations[other].name }, [id, other]);
      }
    }
  }
}
function checkVictory(state) {
  if (state.status !== "running") return;
  const ids = majorIds(state);
  const player = state.nations[state.player];
  if (!player.alive) {
    state.status = "over";
    state.result = { ending: "defeat", winner: null };
    return;
  }
  for (const id of ids) {
    const n = state.nations[id];
    if (!n.alive) continue;
    const rivals = ids.filter((x) => x !== id);
    const allTaken = rivals.every((x) => {
      const capId = state.nations[x].originalCapital;
      return !state.nations[x].alive || capId && state.cities[capId]?.owner === id;
    });
    if (allTaken && rivals.some((x) => state.nations[x].originalCapital)) {
      state.status = "over";
      state.result = { ending: id === state.player ? "conquest" : "defeat", winner: id };
      pushEvent(state, "conquest", { nation: n.name });
      return;
    }
  }
}
function endTurn(state, map = loadMap()) {
  if (state.battle) return { ok: false, error: "BATTLE_ACTIVE", state };
  if (state.status !== "running") return state;
  for (const id of majorIds(state)) {
    const n = state.nations[id];
    if (n.alive && !n.human) runAi(state, map, id);
  }
  for (const id of majorIds(state)) {
    const n = state.nations[id];
    if (n.alive) processNation(state, map, n);
  }
  for (const city of sortedValues(state.cities)) {
    if (!isNeutralId(city.owner)) continue;
    city.hp = Math.min(100, city.hp + 15);
    if (state.turn % 30 === 0 && city.pop < 8) city.pop += 1;
  }
  refreshUnits(state, map);
  updateContacts(state, map);
  diplomacyTick(state, map);
  memoryTick(state);
  threatTick(state);
  nuclearTick(state);
  maybeDetect(state, map);
  finaleTick(state);
  updateExplored(state, map);
  const impact = resolveImpact(state, map);
  if (impact) {
    state.status = "over";
    state.result = { ending: impact.ending, outcome: impact.outcome, winner: impact.winner, defense: impact.defense, contributions: impact.contributions };
    return state;
  }
  checkVictory(state);
  state.turn += 1;
  if (state.status === "running" && state.turn > MAX_TURNS) {
    state.status = "over";
    state.result = { ending: "silence", winner: null };
  }
  return state;
}

// src/game/session.js
var BATTLE_FRAME_MS = 100;
var BATTLE_SPEEDS = [0, 1, 2, 4];
function createGameSession({ send: send2, now = () => Date.now(), map = loadMap(), timers = { setInterval, clearInterval }, onNewGame = null, onGameNew = null } = {}) {
  if (typeof send2 !== "function") throw new TypeError("send is required");
  let game = null;
  let lastEventSeq = 0;
  let attached = true;
  let sendTarget = send2;
  const clock = { timer: null, accMs: 0, speed: 1 };
  const quietSend = () => {
  };
  function sendNow(payload) {
    sendTarget(payload);
  }
  function stopClock() {
    if (clock.timer) timers.clearInterval(clock.timer);
    clock.timer = null;
  }
  function startClock() {
    if (!attached || clock.timer) return;
    clock.timer = timers.setInterval(battleFrame, BATTLE_FRAME_MS);
  }
  function battleFrame() {
    if (!game?.battle) {
      stopClock();
      return;
    }
    clock.accMs += clock.speed * BATTLE_FRAME_MS;
    const tickMs = TICK * 1e3;
    const ticks = Math.floor(clock.accMs / tickMs);
    if (ticks <= 0) return;
    clock.accMs -= ticks * tickMs;
    pushFrame(applyCommand(game, game.player, { kind: "battleAdvance", ticks }, map));
  }
  function pushFrame(result) {
    sendNow({ type: "game:battle", ...result, speed: clock.speed });
    if (result.finished) {
      stopClock();
      broadcast();
    }
  }
  function broadcast() {
    const state = snapshot(game, game.player, { sinceSeq: lastEventSeq, map });
    if (state.events.length) lastEventSeq = state.events[state.events.length - 1].seq;
    sendNow({ type: "game:state", state });
  }
  function requestIdOf(message) {
    try {
      if (message === null || typeof message !== "object") return null;
      const id = message.requestId;
      if (typeof id === "string") return id.slice(0, 64);
      return typeof id === "number" && Number.isFinite(id) ? id : null;
    } catch {
      return null;
    }
  }
  function handle2(message) {
    try {
      return route(message);
    } catch (error) {
      if (process.env.KUPOL_DEBUG) console.error(error);
      sendNow({ type: "game:error", requestId: requestIdOf(message), error: "INTERNAL", message: errorText("INTERNAL") });
      return true;
    }
  }
  const MAX_MESSAGE_BYTES = 16384;
  const MAX_COMMANDS_PER_SECOND = 40;
  let windowStart = 0;
  let windowCount = 0;
  function tooLarge(message) {
    try {
      return Buffer.byteLength(JSON.stringify(message), "utf8") > MAX_MESSAGE_BYTES;
    } catch {
      return true;
    }
  }
  function route(message) {
    if (message === null || typeof message !== "object") return false;
    if (tooLarge(message)) {
      sendNow({ type: "game:error", requestId: null, error: "TOO_LARGE", message: errorText("TOO_LARGE") });
      return true;
    }
    const t = now();
    if (t - windowStart >= 1e3) {
      windowStart = t;
      windowCount = 0;
    }
    windowCount += 1;
    if (windowCount > MAX_COMMANDS_PER_SECOND) {
      sendNow({ type: "game:error", requestId: requestIdOf(message), error: "RATE_LIMIT", message: errorText("RATE_LIMIT") });
      return true;
    }
    switch (message.type) {
      case "game:new": {
        stopClock();
        clock.accMs = 0;
        clock.speed = 1;
        const seed = Number.isInteger(message.seed) ? message.seed : now() % 2147483647;
        try {
          game = createGame({ seed, setup: message.setup ?? {}, map });
        } catch (error) {
          sendNow({ type: "game:error", error: "BAD_SETUP", message: errorText("BAD_SETUP") });
          return true;
        }
        lastEventSeq = 0;
        if (onNewGame) onNewGame(game, map);
        if (onGameNew) onGameNew(game);
        broadcast();
        return true;
      }
      case "game:command": {
        const requestId = requestIdOf(message);
        const result = game ? applyCommand(game, game.player, message.command, map) : { ok: false, error: "NO_GAME" };
        sendNow({ type: "game:command:result", requestId, ...result, ...result.ok ? {} : { message: errorText(result.error) } });
        const kind = message.command?.kind;
        const quiet = kind === "odds" || (kind === "battleOrder" || kind === "battleAdvance" || kind === "battle") && !result.finished;
        if (game && result.ok && !quiet) broadcast();
        if (result.ok && kind === "battle") {
          clock.accMs = 0;
          clock.speed = 1;
          startClock();
        }
        if (result.finished) stopClock();
        return true;
      }
      case "game:endTurn": {
        const requestId = requestIdOf(message);
        if (!game) {
          sendNow({ type: "game:command:result", requestId, ok: false, error: "NO_GAME", message: errorText("NO_GAME") });
          return true;
        }
        if (game.status !== "running") {
          sendNow({ type: "game:command:result", requestId, ok: false, error: "GAME_OVER", message: errorText("GAME_OVER") });
          return true;
        }
        if (game.battle) {
          sendNow({ type: "game:command:result", requestId, ok: false, error: "BATTLE_ACTIVE", message: errorText("BATTLE_ACTIVE") });
          return true;
        }
        endTurn(game, map);
        sendNow({ type: "game:command:result", requestId, ok: true, turn: game.turn });
        broadcast();
        return true;
      }
      case "game:battleSpeed": {
        const requestId = requestIdOf(message);
        const speed = BATTLE_SPEEDS.includes(message.speed) ? message.speed : 1;
        if (!game?.battle) {
          sendNow({ type: "game:command:result", requestId, ok: false, error: "NO_BATTLE", message: errorText("NO_BATTLE") });
          return true;
        }
        clock.speed = speed;
        sendNow({ type: "game:command:result", requestId, ok: true, speed });
        return true;
      }
      case "game:stop": {
        stopClock();
        game = null;
        sendNow({ type: "game:stopped" });
        return true;
      }
      default:
        return false;
    }
  }
  return {
    handle: handle2,
    setSend(next) {
      if (typeof next !== "function") throw new TypeError("send is required");
      sendTarget = next;
    },
    detach() {
      attached = false;
      stopClock();
    },
    resume() {
      attached = true;
      if (game?.battle) startClock();
    },
    sendResume() {
      if (!game) return;
      lastEventSeq = 0;
      broadcast();
      if (game.battle) sendNow({ type: "game:battle", battle: battleView(game.battle, { terrain: true }), speed: clock.speed });
    },
    dispose() {
      attached = false;
      stopClock();
      game = null;
      sendTarget = quietSend;
    },
    get game() {
      return game;
    },
    get map() {
      return map;
    }
  };
}

// src/game/sessions.js
var noop = () => {
};
var defaultTimers = { setTimeout, clearTimeout };
function defaultSessionToken() {
  return randomBytes(16).toString("hex");
}
function createSessionRegistry({
  ttlMs = 10 * 60 * 1e3,
  max = 200,
  now = () => Date.now(),
  timers = defaultTimers,
  makeToken = defaultSessionToken
} = {}) {
  if (!Number.isFinite(ttlMs) || ttlMs <= 0) throw new TypeError("ttlMs must be positive");
  if (!Number.isInteger(max) || max <= 0) throw new TypeError("max must be positive");
  const records = /* @__PURE__ */ new Map();
  function clearExpiry(record) {
    if (record.expiry !== null) timers.clearTimeout(record.expiry);
    record.expiry = null;
  }
  function disposeRecord(record) {
    clearExpiry(record);
    records.delete(record.token);
    record.session.dispose();
  }
  function expire(record) {
    if (records.get(record.token) !== record || record.socket) return;
    disposeRecord(record);
  }
  function scheduleExpiry(record) {
    clearExpiry(record);
    record.detachedAt = now();
    record.expiry = timers.setTimeout(() => expire(record), ttlMs);
  }
  function evictDetached() {
    while (records.size > max) {
      const oldest = [...records.values()].filter((record) => !record.socket).sort((a, b) => a.detachedAt - b.detachedAt || a.order - b.order)[0];
      if (!oldest) break;
      disposeRecord(oldest);
    }
  }
  function tokenFor() {
    let token;
    do
      token = makeToken();
    while (typeof token !== "string" || !token || records.has(token));
    return token;
  }
  function register({ session, socket = null, send: send2 = noop } = {}) {
    if (!session || typeof session.setSend !== "function" || typeof session.detach !== "function") throw new TypeError("session is required");
    const token = tokenFor();
    const record = { token, session, socket, send: send2, expiry: null, detachedAt: null, order: records.size + 1 };
    records.set(token, record);
    session.setSend(send2);
    if (!socket) {
      session.detach();
      scheduleExpiry(record);
    }
    evictDetached();
    return record;
  }
  function attach(token, { socket = null, send: send2 = noop } = {}) {
    const record = records.get(token);
    if (!record) return null;
    if (record.socket && record.socket !== socket && typeof record.socket.close === "function") {
      try {
        record.socket.close(4001, "session resumed elsewhere");
      } catch {
      }
    }
    clearExpiry(record);
    record.socket = socket;
    record.send = send2;
    record.session.setSend(send2);
    record.session.resume();
    return record;
  }
  function detach(token, socket = null) {
    const record = records.get(token);
    if (!record || socket && record.socket !== socket) return false;
    record.socket = null;
    record.session.detach();
    scheduleExpiry(record);
    return true;
  }
  function remove(token) {
    const record = records.get(token);
    if (!record) return false;
    disposeRecord(record);
    return true;
  }
  return {
    register,
    createSession: register,
    attach,
    detach,
    remove,
    get(token) {
      return records.get(token) ?? null;
    },
    get size() {
      return records.size;
    },
    dispose() {
      for (const record of [...records.values()]) disposeRecord(record);
    }
  };
}
function createSessionConnection({ socket, registry, sessionOptions = {}, onGameNew = null, onInvalidJson = null, onBinary = null, onUnknown = null } = {}) {
  if (!socket || !registry) throw new TypeError("socket and registry are required");
  const send2 = (payload) => {
    if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(payload));
  };
  let record = null;
  let session = createGameSession({
    ...sessionOptions,
    send: send2,
    onGameNew: (game) => {
      if (!record) record = registry.register({ session, socket, send: send2 });
      send2({ type: "game:session", token: record.token });
      if (onGameNew) onGameNew(game);
    }
  });
  function handleResume(message2) {
    const next = registry.attach(message2.token, { socket, send: send2 });
    if (!next) {
      send2({ type: "game:resumed", ok: false });
      return true;
    }
    record = next;
    session = next.session;
    send2({ type: "game:session", token: record.token });
    send2({ type: "game:resumed", ok: true });
    session.sendResume();
    return true;
  }
  function message(raw, isBinary = false) {
    if (isBinary) {
      if (onBinary) onBinary();
      return;
    }
    let parsed;
    try {
      parsed = JSON.parse(raw.toString());
    } catch {
      if (onInvalidJson) onInvalidJson();
      return;
    }
    if (!parsed || typeof parsed.type !== "string" || !parsed.type.startsWith("game:")) {
      if (onUnknown) onUnknown(parsed);
      return;
    }
    if (parsed.type === "game:resume") {
      handleResume(parsed);
      return;
    }
    if (!session.handle(parsed) && onUnknown) onUnknown(parsed);
  }
  function close() {
    if (record) registry.detach(record.token, socket);
    else session.dispose();
  }
  return { message, close, get session() {
    return session;
  }, get token() {
    return record?.token ?? null;
  } };
}

// server.js
var gameSessions = createSessionRegistry();
var __dirname = path.dirname(fileURLToPath2(import.meta.url));
var port = Number(process.env.PORT || 4173);
var host = process.env.HOST || "127.0.0.1";
var dist2 = path.join(__dirname, "dist");
var indexHtml = path.join(dist2, "index.html");
var WS_PATH = "/ws";
var WS_MAX_PAYLOAD = 64 * 1024;
var WS_HEARTBEAT_MS = 3e4;
var MAX_MESSAGE_TYPE_LENGTH = 64;
var apiProxiesEnabled = process.env.GEV_API_PROXIES !== "0";
var allowedOrigins = new Set(
  (process.env.GEV_ALLOWED_ORIGINS || "").split(",").map((value) => value.trim()).filter(Boolean)
);
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".map": "application/json; charset=utf-8",
  ".geojson": "application/geo+json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".csv": "text/csv; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".wasm": "application/wasm",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".ktx2": "image/ktx2",
  ".glb": "model/gltf-binary",
  ".gltf": "model/gltf+json",
  ".pbf": "application/x-protobuf",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
  ".ogg": "audio/ogg",
  ".mp4": "video/mp4",
  ".webm": "video/webm"
};
if (!fs.existsSync(indexHtml)) {
  console.error('[nuclear-gods-eye] dist/index.html not found. Run "npm run build" first.');
  process.exit(1);
}
var server = createServer((req, res) => {
  handle(req, res).catch((error) => {
    console.error("[nuclear-gods-eye] request failed:", error);
    if (!res.headersSent) {
      sendJson(res, 500, { ok: false, error: "INTERNAL_ERROR" });
    } else {
      res.destroy();
    }
  });
});
var wss = new import_websocket_server.default({ noServer: true, maxPayload: WS_MAX_PAYLOAD });
var vite = null;
if (apiProxiesEnabled) {
  const { createServer: createViteServer } = await import("vite");
  vite = await createViteServer({
    root: __dirname,
    configFile: path.join(__dirname, "vite.config.js"),
    mode: process.env.GEV_MODE || void 0,
    appType: "custom",
    clearScreen: false,
    server: { middlewareMode: true, hmr: false, watch: null, host, port },
    optimizeDeps: { noDiscovery: true, include: [] },
    plugins: [
      {
        // Plugins that hook server.httpServer (upgrade/listening) get the real
        // production HTTP server instead of null in middleware mode.
        name: "gev-production-http-server",
        enforce: "pre",
        configureServer(viteServer) {
          viteServer.httpServer = server;
        }
      }
    ]
  });
}
function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store"
  });
  res.end(body);
}
function sendStatus(res, status, headers = {}) {
  res.writeHead(status, { "Content-Length": 0, ...headers });
  res.end();
}
async function sendFile(req, res, filePath, stat, cacheControl) {
  res.writeHead(200, {
    "Content-Type": MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream",
    "Content-Length": stat.size,
    "Last-Modified": stat.mtime.toUTCString(),
    "Cache-Control": cacheControl,
    "X-Content-Type-Options": "nosniff"
  });
  if (req.method === "HEAD") {
    res.end();
    return;
  }
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(filePath);
    stream.on("error", reject);
    res.on("close", resolve);
    stream.pipe(res);
  });
}
async function statFile(filePath) {
  try {
    const stat = await fs.promises.stat(filePath);
    return stat.isFile() ? stat : null;
  } catch {
    return null;
  }
}
async function handle(req, res) {
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
  } catch {
    sendStatus(res, 400);
    return;
  }
  if (pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      service: "nuclear-gods-eye",
      apiProxies: Boolean(vite),
      websocket: wss.clients.size,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    return;
  }
  if (pathname === "/api" || pathname.startsWith("/api/")) {
    const notFound = () => sendJson(res, 404, { ok: false, error: "NOT_FOUND" });
    if (!vite) {
      notFound();
      return;
    }
    vite.middlewares(req, res, (error) => {
      if (error) {
        console.error("[nuclear-gods-eye] api proxy error:", error);
        if (!res.headersSent) sendJson(res, 502, { ok: false, error: "PROXY_ERROR" });
        return;
      }
      notFound();
    });
    return;
  }
  if (req.method !== "GET" && req.method !== "HEAD") {
    sendStatus(res, 405, { Allow: "GET, HEAD" });
    return;
  }
  const filePath = path.join(dist2, path.normalize(pathname));
  if (filePath !== dist2 && !filePath.startsWith(dist2 + path.sep)) {
    sendStatus(res, 403);
    return;
  }
  const stat = await statFile(filePath);
  if (stat) {
    const hashed = pathname.startsWith("/assets/");
    await sendFile(req, res, filePath, stat, hashed ? "public, max-age=31536000, immutable" : "no-cache");
    return;
  }
  if (path.extname(pathname)) {
    sendStatus(res, 404);
    return;
  }
  const indexStat = await statFile(indexHtml);
  await sendFile(req, res, indexHtml, indexStat, "no-cache");
}
function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (allowedOrigins.has(origin)) return true;
  try {
    return new URL(origin).host === req.headers.host;
  } catch {
    return false;
  }
}
server.on("upgrade", (req, socket, head) => {
  let pathname;
  try {
    pathname = new URL(req.url, "http://localhost").pathname;
  } catch {
    return;
  }
  if (pathname !== WS_PATH) return;
  if (!originAllowed(req)) {
    socket.write("HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n");
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
});
function send(socket, payload) {
  if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(payload));
}
wss.on("connection", (socket) => {
  socket.isAlive = true;
  socket.on("pong", () => {
    socket.isAlive = true;
  });
  socket.on("error", (error) => {
    console.warn("[nuclear-gods-eye] websocket error:", error.message);
  });
  send(socket, { type: "runtime:ready", version: 1 });
  const game = createSessionConnection({
    socket,
    registry: gameSessions,
    onUnknown: () => send(socket, { type: "error", code: "UNKNOWN_GAME_MESSAGE" })
  });
  socket.on("close", () => game.close());
  socket.on("message", (raw, isBinary) => {
    if (isBinary) {
      send(socket, { type: "error", code: "BINARY_NOT_SUPPORTED" });
      return;
    }
    let message;
    try {
      message = JSON.parse(raw.toString());
    } catch {
      send(socket, { type: "error", code: "INVALID_JSON" });
      return;
    }
    if (!message || typeof message.type !== "string" || message.type.length === 0 || message.type.length > MAX_MESSAGE_TYPE_LENGTH) {
      send(socket, { type: "error", code: "INVALID_MESSAGE" });
      return;
    }
    if (message.type.startsWith("game:")) {
      game.message(raw, false);
      return;
    }
    send(socket, { type: "runtime:ack", messageType: message.type });
  });
});
var heartbeat = setInterval(() => {
  for (const socket of wss.clients) {
    if (!socket.isAlive) {
      socket.terminate();
      continue;
    }
    socket.isAlive = false;
    socket.ping();
  }
}, WS_HEARTBEAT_MS);
heartbeat.unref();
server.on("error", (error) => {
  console.error("[nuclear-gods-eye] server error:", error.message);
  process.exit(1);
});
var shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[nuclear-gods-eye] ${signal} received, shutting down`);
  clearInterval(heartbeat);
  gameSessions.dispose();
  for (const socket of wss.clients) socket.terminate();
  wss.close();
  Promise.resolve(vite?.close()).catch(() => {
  }).finally(() => server.close(() => process.exit(0)));
  setTimeout(() => process.exit(0), 5e3).unref();
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
server.listen(port, host, () => {
  console.log(`[nuclear-gods-eye] open in browser: http://${host === "0.0.0.0" ? "localhost" : host}:${port}`);
  console.log(`[nuclear-gods-eye] websocket endpoint: ${WS_PATH}`);
  console.log(`[nuclear-gods-eye] API proxies: ${vite ? "enabled" : "disabled"}`);
});
