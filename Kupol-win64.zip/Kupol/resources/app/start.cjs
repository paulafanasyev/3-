'use strict';
// Загружается из Kupol.exe: подключает сервер игры (ESM) с диска.
const path = require('node:path');
const { pathToFileURL } = require('node:url');
module.exports = () => import(pathToFileURL(path.join(__dirname, 'kupol-server.mjs')).href);
